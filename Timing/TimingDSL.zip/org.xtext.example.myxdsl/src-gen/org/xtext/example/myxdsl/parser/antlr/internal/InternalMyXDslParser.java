package org.xtext.example.myxdsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.myxdsl.services.MyXDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyXDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Top-Package {'", "'UUID:'", "'SHORT-NAME:'", "'CATEGORY:'", "'NAME:'", "'}'", "'Sub-Package {'", "'Package {'", "'Element {'", "'Timing {'", "'TRACEABLE-SPECIFICATION-REFS:'", "'Constraints {'", "'Reaction-Constraint {'", "'SCOPE:'", "'Timing Expression {'", "'TYPE:'", "'Value:'", "'Pattern-Constraint {'", "'EVENT:'", "'Order-Constraint {'", "'TARGET:'", "'SOURCE:'", "'Execution-Time-Constraint {'", "'RESUME-REFS:'", "'PREEMPTION-REFS:'", "'START:'", "'STOP:'", "'Age-Constraint {'", "'Delay-Constraint {'", "'Periodic-Constraint {'", "'Events {'", "'Event-Chain {'", "'SEGMENT-REFS:'", "'STIMULUS:'", "'RESPONSE:'", "'Event-Function-Flow-Port {'", "'FUNCTION-TYPE:'", "'FUNCTION-VALUE:'", "'FUNCTION-PROTOTYPE:'", "'FUNCTION-FLOW-PORT:'", "'Event-Function {'", "'FFUNCTION-PROTOTYPE-TARGET:'", "'FUNCTION-PROTOTYPE-CONTEXT:'", "'Unit {'", "'FACTOR:'", "'SYMBOL:'", "'OFFSET:'", "'QUNATITY:'", "'Quantity {'", "'AMOUNT-OF-SUBSTANCE-EXP:'", "'ELECTRIC-CURRENT-EXP:'", "'LENGTH-EXP:'", "'LUMINOUS-INTENSITY-EXP:'", "'MASS-EXP:'", "'THERMODYNAMIC-TEMPERATURE-EXP:'", "'TIME-EXP:'", "'EA_Numerical {'", "'TEXT:'", "'MAX:'", "'MIN:'", "'UNIT-OF-DATA:'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyXDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyXDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyXDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyXDsl.g"; }



     	private MyXDslGrammarAccess grammarAccess;

        public InternalMyXDslParser(TokenStream input, MyXDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected MyXDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalMyXDsl.g:64:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalMyXDsl.g:64:45: (iv_ruleFile= ruleFile EOF )
            // InternalMyXDsl.g:65:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalMyXDsl.g:71:1: ruleFile returns [EObject current=null] : ( (lv_ea_package_0_0= ruleEA_Package ) )* ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_ea_package_0_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:77:2: ( ( (lv_ea_package_0_0= ruleEA_Package ) )* )
            // InternalMyXDsl.g:78:2: ( (lv_ea_package_0_0= ruleEA_Package ) )*
            {
            // InternalMyXDsl.g:78:2: ( (lv_ea_package_0_0= ruleEA_Package ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_ID) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyXDsl.g:79:3: (lv_ea_package_0_0= ruleEA_Package )
            	    {
            	    // InternalMyXDsl.g:79:3: (lv_ea_package_0_0= ruleEA_Package )
            	    // InternalMyXDsl.g:80:4: lv_ea_package_0_0= ruleEA_Package
            	    {

            	    				newCompositeNode(grammarAccess.getFileAccess().getEa_packageEA_PackageParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_ea_package_0_0=ruleEA_Package();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getFileRule());
            	    				}
            	    				add(
            	    					current,
            	    					"ea_package",
            	    					lv_ea_package_0_0,
            	    					"org.xtext.example.myxdsl.MyXDsl.EA_Package");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleEA_Package"
    // InternalMyXDsl.g:100:1: entryRuleEA_Package returns [EObject current=null] : iv_ruleEA_Package= ruleEA_Package EOF ;
    public final EObject entryRuleEA_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEA_Package = null;


        try {
            // InternalMyXDsl.g:100:51: (iv_ruleEA_Package= ruleEA_Package EOF )
            // InternalMyXDsl.g:101:2: iv_ruleEA_Package= ruleEA_Package EOF
            {
             newCompositeNode(grammarAccess.getEA_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEA_Package=ruleEA_Package();

            state._fsp--;

             current =iv_ruleEA_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEA_Package"


    // $ANTLR start "ruleEA_Package"
    // InternalMyXDsl.g:107:1: ruleEA_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' ) ;
    public final EObject ruleEA_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_12=null;
        EObject lv_subpackages_10_0 = null;

        EObject lv_elements_11_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:113:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' ) )
            // InternalMyXDsl.g:114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' )
            {
            // InternalMyXDsl.g:114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' )
            // InternalMyXDsl.g:115:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}'
            {
            // InternalMyXDsl.g:115:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:116:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:116:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:117:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEA_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,11,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEA_PackageAccess().getTopPackageKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEA_PackageAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:141:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:142:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:142:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:143:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEA_PackageAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEA_PackageAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:163:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:164:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:164:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:165:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEA_PackageAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEA_PackageAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:185:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:186:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:186:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:187:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEA_PackageAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEA_PackageAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:207:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:208:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:208:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:209:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEA_PackageAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:225:3: ( (lv_subpackages_10_0= ruleSub_Package ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_ID) ) {
                    int LA2_1 = input.LA(2);

                    if ( (LA2_1==17) ) {
                        alt2=1;
                    }


                }


                switch (alt2) {
            	case 1 :
            	    // InternalMyXDsl.g:226:4: (lv_subpackages_10_0= ruleSub_Package )
            	    {
            	    // InternalMyXDsl.g:226:4: (lv_subpackages_10_0= ruleSub_Package )
            	    // InternalMyXDsl.g:227:5: lv_subpackages_10_0= ruleSub_Package
            	    {

            	    					newCompositeNode(grammarAccess.getEA_PackageAccess().getSubpackagesSub_PackageParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_subpackages_10_0=ruleSub_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEA_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subpackages",
            	    						lv_subpackages_10_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Sub_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalMyXDsl.g:244:3: ( (lv_elements_11_0= ruleElements ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyXDsl.g:245:4: (lv_elements_11_0= ruleElements )
            	    {
            	    // InternalMyXDsl.g:245:4: (lv_elements_11_0= ruleElements )
            	    // InternalMyXDsl.g:246:5: lv_elements_11_0= ruleElements
            	    {

            	    					newCompositeNode(grammarAccess.getEA_PackageAccess().getElementsElementsParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_elements_11_0=ruleElements();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEA_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_11_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Elements");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getEA_PackageAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEA_Package"


    // $ANTLR start "entryRuleSub_Package"
    // InternalMyXDsl.g:271:1: entryRuleSub_Package returns [EObject current=null] : iv_ruleSub_Package= ruleSub_Package EOF ;
    public final EObject entryRuleSub_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSub_Package = null;


        try {
            // InternalMyXDsl.g:271:52: (iv_ruleSub_Package= ruleSub_Package EOF )
            // InternalMyXDsl.g:272:2: iv_ruleSub_Package= ruleSub_Package EOF
            {
             newCompositeNode(grammarAccess.getSub_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSub_Package=ruleSub_Package();

            state._fsp--;

             current =iv_ruleSub_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSub_Package"


    // $ANTLR start "ruleSub_Package"
    // InternalMyXDsl.g:278:1: ruleSub_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' ) ;
    public final EObject ruleSub_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_nested_package_2_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:284:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' ) )
            // InternalMyXDsl.g:285:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' )
            {
            // InternalMyXDsl.g:285:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' )
            // InternalMyXDsl.g:286:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}'
            {
            // InternalMyXDsl.g:286:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:287:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:287:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:288:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_define_0_0, grammarAccess.getSub_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSub_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,17,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getSub_PackageAccess().getSubPackageKeyword_1());
            		
            // InternalMyXDsl.g:308:3: ( (lv_nested_package_2_0= ruleNested_Package ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMyXDsl.g:309:4: (lv_nested_package_2_0= ruleNested_Package )
            	    {
            	    // InternalMyXDsl.g:309:4: (lv_nested_package_2_0= ruleNested_Package )
            	    // InternalMyXDsl.g:310:5: lv_nested_package_2_0= ruleNested_Package
            	    {

            	    					newCompositeNode(grammarAccess.getSub_PackageAccess().getNested_packageNested_PackageParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_nested_package_2_0=ruleNested_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSub_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"nested_package",
            	    						lv_nested_package_2_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Nested_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_3=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getSub_PackageAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSub_Package"


    // $ANTLR start "entryRuleNested_Package"
    // InternalMyXDsl.g:335:1: entryRuleNested_Package returns [EObject current=null] : iv_ruleNested_Package= ruleNested_Package EOF ;
    public final EObject entryRuleNested_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNested_Package = null;


        try {
            // InternalMyXDsl.g:335:55: (iv_ruleNested_Package= ruleNested_Package EOF )
            // InternalMyXDsl.g:336:2: iv_ruleNested_Package= ruleNested_Package EOF
            {
             newCompositeNode(grammarAccess.getNested_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNested_Package=ruleNested_Package();

            state._fsp--;

             current =iv_ruleNested_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNested_Package"


    // $ANTLR start "ruleNested_Package"
    // InternalMyXDsl.g:342:1: ruleNested_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' ) ;
    public final EObject ruleNested_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_12=null;
        EObject lv_subpackages_10_0 = null;

        EObject lv_element_11_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:348:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' ) )
            // InternalMyXDsl.g:349:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' )
            {
            // InternalMyXDsl.g:349:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' )
            // InternalMyXDsl.g:350:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}'
            {
            // InternalMyXDsl.g:350:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:351:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:351:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:352:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(lv_define_0_0, grammarAccess.getNested_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,18,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getNested_PackageAccess().getPackageKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getNested_PackageAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:376:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:377:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:377:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:378:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getNested_PackageAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getNested_PackageAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:398:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:399:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:399:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:400:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getNested_PackageAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getNested_PackageAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:420:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:421:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:421:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:422:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getNested_PackageAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getNested_PackageAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:442:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:443:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:443:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:444:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_name_9_0, grammarAccess.getNested_PackageAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:460:3: ( (lv_subpackages_10_0= ruleSub_Package ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID) ) {
                    int LA5_1 = input.LA(2);

                    if ( (LA5_1==17) ) {
                        alt5=1;
                    }


                }


                switch (alt5) {
            	case 1 :
            	    // InternalMyXDsl.g:461:4: (lv_subpackages_10_0= ruleSub_Package )
            	    {
            	    // InternalMyXDsl.g:461:4: (lv_subpackages_10_0= ruleSub_Package )
            	    // InternalMyXDsl.g:462:5: lv_subpackages_10_0= ruleSub_Package
            	    {

            	    					newCompositeNode(grammarAccess.getNested_PackageAccess().getSubpackagesSub_PackageParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_subpackages_10_0=ruleSub_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNested_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subpackages",
            	    						lv_subpackages_10_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Sub_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalMyXDsl.g:479:3: ( (lv_element_11_0= ruleElement ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMyXDsl.g:480:4: (lv_element_11_0= ruleElement )
            	    {
            	    // InternalMyXDsl.g:480:4: (lv_element_11_0= ruleElement )
            	    // InternalMyXDsl.g:481:5: lv_element_11_0= ruleElement
            	    {

            	    					newCompositeNode(grammarAccess.getNested_PackageAccess().getElementElementParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_element_11_0=ruleElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNested_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"element",
            	    						lv_element_11_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getNested_PackageAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNested_Package"


    // $ANTLR start "entryRuleElement"
    // InternalMyXDsl.g:506:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalMyXDsl.g:506:48: (iv_ruleElement= ruleElement EOF )
            // InternalMyXDsl.g:507:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalMyXDsl.g:513:1: ruleElement returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_6=null;
        EObject lv_ea_numerical_2_0 = null;

        EObject lv_unit_3_0 = null;

        EObject lv_qunatity_4_0 = null;

        EObject lv_timing_5_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:519:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' ) )
            // InternalMyXDsl.g:520:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' )
            {
            // InternalMyXDsl.g:520:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' )
            // InternalMyXDsl.g:521:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}'
            {
            // InternalMyXDsl.g:521:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:522:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:522:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:523:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_define_0_0, grammarAccess.getElementAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,19,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getElementAccess().getElementKeyword_1());
            		
            // InternalMyXDsl.g:543:3: ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    int LA7_1 = input.LA(2);

                    if ( (LA7_1==67) ) {
                        alt7=1;
                    }


                }


                switch (alt7) {
            	case 1 :
            	    // InternalMyXDsl.g:544:4: (lv_ea_numerical_2_0= ruleEA_Numerical )
            	    {
            	    // InternalMyXDsl.g:544:4: (lv_ea_numerical_2_0= ruleEA_Numerical )
            	    // InternalMyXDsl.g:545:5: lv_ea_numerical_2_0= ruleEA_Numerical
            	    {

            	    					newCompositeNode(grammarAccess.getElementAccess().getEa_numericalEA_NumericalParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_ea_numerical_2_0=ruleEA_Numerical();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementRule());
            	    					}
            	    					add(
            	    						current,
            	    						"ea_numerical",
            	    						lv_ea_numerical_2_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.EA_Numerical");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            // InternalMyXDsl.g:562:3: ( (lv_unit_3_0= ruleUnit ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID) ) {
                    int LA8_1 = input.LA(2);

                    if ( (LA8_1==54) ) {
                        alt8=1;
                    }


                }


                switch (alt8) {
            	case 1 :
            	    // InternalMyXDsl.g:563:4: (lv_unit_3_0= ruleUnit )
            	    {
            	    // InternalMyXDsl.g:563:4: (lv_unit_3_0= ruleUnit )
            	    // InternalMyXDsl.g:564:5: lv_unit_3_0= ruleUnit
            	    {

            	    					newCompositeNode(grammarAccess.getElementAccess().getUnitUnitParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_unit_3_0=ruleUnit();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementRule());
            	    					}
            	    					add(
            	    						current,
            	    						"unit",
            	    						lv_unit_3_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Unit");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalMyXDsl.g:581:3: ( (lv_qunatity_4_0= ruleQuantity ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==RULE_ID) ) {
                    int LA9_1 = input.LA(2);

                    if ( (LA9_1==59) ) {
                        alt9=1;
                    }


                }


                switch (alt9) {
            	case 1 :
            	    // InternalMyXDsl.g:582:4: (lv_qunatity_4_0= ruleQuantity )
            	    {
            	    // InternalMyXDsl.g:582:4: (lv_qunatity_4_0= ruleQuantity )
            	    // InternalMyXDsl.g:583:5: lv_qunatity_4_0= ruleQuantity
            	    {

            	    					newCompositeNode(grammarAccess.getElementAccess().getQunatityQuantityParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_qunatity_4_0=ruleQuantity();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementRule());
            	    					}
            	    					add(
            	    						current,
            	    						"qunatity",
            	    						lv_qunatity_4_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Quantity");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            // InternalMyXDsl.g:600:3: ( (lv_timing_5_0= ruleTiming ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==RULE_ID) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalMyXDsl.g:601:4: (lv_timing_5_0= ruleTiming )
            	    {
            	    // InternalMyXDsl.g:601:4: (lv_timing_5_0= ruleTiming )
            	    // InternalMyXDsl.g:602:5: lv_timing_5_0= ruleTiming
            	    {

            	    					newCompositeNode(grammarAccess.getElementAccess().getTimingTimingParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timing_5_0=ruleTiming();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timing",
            	    						lv_timing_5_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Timing");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getElementAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleElements"
    // InternalMyXDsl.g:627:1: entryRuleElements returns [EObject current=null] : iv_ruleElements= ruleElements EOF ;
    public final EObject entryRuleElements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElements = null;


        try {
            // InternalMyXDsl.g:627:49: (iv_ruleElements= ruleElements EOF )
            // InternalMyXDsl.g:628:2: iv_ruleElements= ruleElements EOF
            {
             newCompositeNode(grammarAccess.getElementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElements=ruleElements();

            state._fsp--;

             current =iv_ruleElements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElements"


    // $ANTLR start "ruleElements"
    // InternalMyXDsl.g:634:1: ruleElements returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' ) ;
    public final EObject ruleElements() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_6=null;
        EObject lv_ea_numerical_2_0 = null;

        EObject lv_unit_3_0 = null;

        EObject lv_qunatity_4_0 = null;

        EObject lv_timing_5_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:640:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' ) )
            // InternalMyXDsl.g:641:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' )
            {
            // InternalMyXDsl.g:641:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}' )
            // InternalMyXDsl.g:642:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )* ( (lv_unit_3_0= ruleUnit ) )* ( (lv_qunatity_4_0= ruleQuantity ) )* ( (lv_timing_5_0= ruleTiming ) )* otherlv_6= '}'
            {
            // InternalMyXDsl.g:642:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:643:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:643:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:644:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_define_0_0, grammarAccess.getElementsAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getElementsRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,19,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getElementsAccess().getElementKeyword_1());
            		
            // InternalMyXDsl.g:664:3: ( (lv_ea_numerical_2_0= ruleEA_Numerical ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    int LA11_1 = input.LA(2);

                    if ( (LA11_1==67) ) {
                        alt11=1;
                    }


                }


                switch (alt11) {
            	case 1 :
            	    // InternalMyXDsl.g:665:4: (lv_ea_numerical_2_0= ruleEA_Numerical )
            	    {
            	    // InternalMyXDsl.g:665:4: (lv_ea_numerical_2_0= ruleEA_Numerical )
            	    // InternalMyXDsl.g:666:5: lv_ea_numerical_2_0= ruleEA_Numerical
            	    {

            	    					newCompositeNode(grammarAccess.getElementsAccess().getEa_numericalEA_NumericalParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_ea_numerical_2_0=ruleEA_Numerical();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"ea_numerical",
            	    						lv_ea_numerical_2_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.EA_Numerical");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            // InternalMyXDsl.g:683:3: ( (lv_unit_3_0= ruleUnit ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_ID) ) {
                    int LA12_1 = input.LA(2);

                    if ( (LA12_1==54) ) {
                        alt12=1;
                    }


                }


                switch (alt12) {
            	case 1 :
            	    // InternalMyXDsl.g:684:4: (lv_unit_3_0= ruleUnit )
            	    {
            	    // InternalMyXDsl.g:684:4: (lv_unit_3_0= ruleUnit )
            	    // InternalMyXDsl.g:685:5: lv_unit_3_0= ruleUnit
            	    {

            	    					newCompositeNode(grammarAccess.getElementsAccess().getUnitUnitParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_unit_3_0=ruleUnit();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"unit",
            	    						lv_unit_3_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Unit");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            // InternalMyXDsl.g:702:3: ( (lv_qunatity_4_0= ruleQuantity ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==RULE_ID) ) {
                    int LA13_1 = input.LA(2);

                    if ( (LA13_1==59) ) {
                        alt13=1;
                    }


                }


                switch (alt13) {
            	case 1 :
            	    // InternalMyXDsl.g:703:4: (lv_qunatity_4_0= ruleQuantity )
            	    {
            	    // InternalMyXDsl.g:703:4: (lv_qunatity_4_0= ruleQuantity )
            	    // InternalMyXDsl.g:704:5: lv_qunatity_4_0= ruleQuantity
            	    {

            	    					newCompositeNode(grammarAccess.getElementsAccess().getQunatityQuantityParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_qunatity_4_0=ruleQuantity();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"qunatity",
            	    						lv_qunatity_4_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Quantity");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalMyXDsl.g:721:3: ( (lv_timing_5_0= ruleTiming ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==RULE_ID) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalMyXDsl.g:722:4: (lv_timing_5_0= ruleTiming )
            	    {
            	    // InternalMyXDsl.g:722:4: (lv_timing_5_0= ruleTiming )
            	    // InternalMyXDsl.g:723:5: lv_timing_5_0= ruleTiming
            	    {

            	    					newCompositeNode(grammarAccess.getElementsAccess().getTimingTimingParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timing_5_0=ruleTiming();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timing",
            	    						lv_timing_5_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Timing");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getElementsAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElements"


    // $ANTLR start "entryRuleTiming"
    // InternalMyXDsl.g:748:1: entryRuleTiming returns [EObject current=null] : iv_ruleTiming= ruleTiming EOF ;
    public final EObject entryRuleTiming() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTiming = null;


        try {
            // InternalMyXDsl.g:748:47: (iv_ruleTiming= ruleTiming EOF )
            // InternalMyXDsl.g:749:2: iv_ruleTiming= ruleTiming EOF
            {
             newCompositeNode(grammarAccess.getTimingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTiming=ruleTiming();

            state._fsp--;

             current =iv_ruleTiming; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTiming"


    // $ANTLR start "ruleTiming"
    // InternalMyXDsl.g:755:1: ruleTiming returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_descriptions_12_0= ruleDescriptions ) )* ( (lv_constraints_13_0= ruleConstraints ) )* otherlv_14= '}' ) ;
    public final EObject ruleTiming() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_14=null;
        EObject lv_descriptions_12_0 = null;

        EObject lv_constraints_13_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:761:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_descriptions_12_0= ruleDescriptions ) )* ( (lv_constraints_13_0= ruleConstraints ) )* otherlv_14= '}' ) )
            // InternalMyXDsl.g:762:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_descriptions_12_0= ruleDescriptions ) )* ( (lv_constraints_13_0= ruleConstraints ) )* otherlv_14= '}' )
            {
            // InternalMyXDsl.g:762:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_descriptions_12_0= ruleDescriptions ) )* ( (lv_constraints_13_0= ruleConstraints ) )* otherlv_14= '}' )
            // InternalMyXDsl.g:763:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_descriptions_12_0= ruleDescriptions ) )* ( (lv_constraints_13_0= ruleConstraints ) )* otherlv_14= '}'
            {
            // InternalMyXDsl.g:763:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:764:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:764:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:765:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_define_0_0, grammarAccess.getTimingAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,20,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getTimingAccess().getTimingKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getTimingAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:789:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:790:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:790:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:791:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getTimingAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getTimingAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:811:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:812:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:812:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:813:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getTimingAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getTimingAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:833:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:834:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:834:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:835:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getTimingAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getTimingAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:855:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:856:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:856:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:857:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_15); 

            					newLeafNode(lv_name_9_0, grammarAccess.getTimingAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:873:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==21) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyXDsl.g:874:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,21,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getTimingAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
                    			
                    // InternalMyXDsl.g:878:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
                    // InternalMyXDsl.g:879:5: (lv_traceable_specification_11_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:879:5: (lv_traceable_specification_11_0= RULE_STRING )
                    // InternalMyXDsl.g:880:6: lv_traceable_specification_11_0= RULE_STRING
                    {
                    lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getTimingAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTimingRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"traceable_specification",
                    							lv_traceable_specification_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:897:3: ( (lv_descriptions_12_0= ruleDescriptions ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==RULE_ID) ) {
                    int LA16_1 = input.LA(2);

                    if ( (LA16_1==41) ) {
                        alt16=1;
                    }


                }


                switch (alt16) {
            	case 1 :
            	    // InternalMyXDsl.g:898:4: (lv_descriptions_12_0= ruleDescriptions )
            	    {
            	    // InternalMyXDsl.g:898:4: (lv_descriptions_12_0= ruleDescriptions )
            	    // InternalMyXDsl.g:899:5: lv_descriptions_12_0= ruleDescriptions
            	    {

            	    					newCompositeNode(grammarAccess.getTimingAccess().getDescriptionsDescriptionsParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_descriptions_12_0=ruleDescriptions();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTimingRule());
            	    					}
            	    					add(
            	    						current,
            	    						"descriptions",
            	    						lv_descriptions_12_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Descriptions");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            // InternalMyXDsl.g:916:3: ( (lv_constraints_13_0= ruleConstraints ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==RULE_ID) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalMyXDsl.g:917:4: (lv_constraints_13_0= ruleConstraints )
            	    {
            	    // InternalMyXDsl.g:917:4: (lv_constraints_13_0= ruleConstraints )
            	    // InternalMyXDsl.g:918:5: lv_constraints_13_0= ruleConstraints
            	    {

            	    					newCompositeNode(grammarAccess.getTimingAccess().getConstraintsConstraintsParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_constraints_13_0=ruleConstraints();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTimingRule());
            	    					}
            	    					add(
            	    						current,
            	    						"constraints",
            	    						lv_constraints_13_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Constraints");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            otherlv_14=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getTimingAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTiming"


    // $ANTLR start "entryRuleConstraints"
    // InternalMyXDsl.g:943:1: entryRuleConstraints returns [EObject current=null] : iv_ruleConstraints= ruleConstraints EOF ;
    public final EObject entryRuleConstraints() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstraints = null;


        try {
            // InternalMyXDsl.g:943:52: (iv_ruleConstraints= ruleConstraints EOF )
            // InternalMyXDsl.g:944:2: iv_ruleConstraints= ruleConstraints EOF
            {
             newCompositeNode(grammarAccess.getConstraintsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstraints=ruleConstraints();

            state._fsp--;

             current =iv_ruleConstraints; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstraints"


    // $ANTLR start "ruleConstraints"
    // InternalMyXDsl.g:950:1: ruleConstraints returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Constraints {' ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )* ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )* ( (lv_age_constraint_4_0= ruleAge_Constraint ) )* ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )* ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )* ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )* ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )* otherlv_9= '}' ) ;
    public final EObject ruleConstraints() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_9=null;
        EObject lv_periodic_constraint_2_0 = null;

        EObject lv_delay_constraint_3_0 = null;

        EObject lv_age_constraint_4_0 = null;

        EObject lv_execution_time_constraint_5_0 = null;

        EObject lv_order_constraint_6_0 = null;

        EObject lv_pattern_constraint_7_0 = null;

        EObject lv_reaction_constraint_8_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:956:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Constraints {' ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )* ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )* ( (lv_age_constraint_4_0= ruleAge_Constraint ) )* ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )* ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )* ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )* ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )* otherlv_9= '}' ) )
            // InternalMyXDsl.g:957:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Constraints {' ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )* ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )* ( (lv_age_constraint_4_0= ruleAge_Constraint ) )* ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )* ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )* ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )* ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )* otherlv_9= '}' )
            {
            // InternalMyXDsl.g:957:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Constraints {' ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )* ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )* ( (lv_age_constraint_4_0= ruleAge_Constraint ) )* ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )* ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )* ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )* ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )* otherlv_9= '}' )
            // InternalMyXDsl.g:958:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Constraints {' ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )* ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )* ( (lv_age_constraint_4_0= ruleAge_Constraint ) )* ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )* ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )* ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )* ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )* otherlv_9= '}'
            {
            // InternalMyXDsl.g:958:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:959:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:959:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:960:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_define_0_0, grammarAccess.getConstraintsAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConstraintsRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,22,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getConstraintsAccess().getConstraintsKeyword_1());
            		
            // InternalMyXDsl.g:980:3: ( (lv_periodic_constraint_2_0= rulePeriodic_Constraint ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==RULE_ID) ) {
                    int LA18_1 = input.LA(2);

                    if ( (LA18_1==40) ) {
                        alt18=1;
                    }


                }


                switch (alt18) {
            	case 1 :
            	    // InternalMyXDsl.g:981:4: (lv_periodic_constraint_2_0= rulePeriodic_Constraint )
            	    {
            	    // InternalMyXDsl.g:981:4: (lv_periodic_constraint_2_0= rulePeriodic_Constraint )
            	    // InternalMyXDsl.g:982:5: lv_periodic_constraint_2_0= rulePeriodic_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getPeriodic_constraintPeriodic_ConstraintParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_periodic_constraint_2_0=rulePeriodic_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"periodic_constraint",
            	    						lv_periodic_constraint_2_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Periodic_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            // InternalMyXDsl.g:999:3: ( (lv_delay_constraint_3_0= ruleDelay_Constraint ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_ID) ) {
                    int LA19_1 = input.LA(2);

                    if ( (LA19_1==39) ) {
                        alt19=1;
                    }


                }


                switch (alt19) {
            	case 1 :
            	    // InternalMyXDsl.g:1000:4: (lv_delay_constraint_3_0= ruleDelay_Constraint )
            	    {
            	    // InternalMyXDsl.g:1000:4: (lv_delay_constraint_3_0= ruleDelay_Constraint )
            	    // InternalMyXDsl.g:1001:5: lv_delay_constraint_3_0= ruleDelay_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getDelay_constraintDelay_ConstraintParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_delay_constraint_3_0=ruleDelay_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"delay_constraint",
            	    						lv_delay_constraint_3_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Delay_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            // InternalMyXDsl.g:1018:3: ( (lv_age_constraint_4_0= ruleAge_Constraint ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_ID) ) {
                    int LA20_1 = input.LA(2);

                    if ( (LA20_1==38) ) {
                        alt20=1;
                    }


                }


                switch (alt20) {
            	case 1 :
            	    // InternalMyXDsl.g:1019:4: (lv_age_constraint_4_0= ruleAge_Constraint )
            	    {
            	    // InternalMyXDsl.g:1019:4: (lv_age_constraint_4_0= ruleAge_Constraint )
            	    // InternalMyXDsl.g:1020:5: lv_age_constraint_4_0= ruleAge_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getAge_constraintAge_ConstraintParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_age_constraint_4_0=ruleAge_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"age_constraint",
            	    						lv_age_constraint_4_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Age_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            // InternalMyXDsl.g:1037:3: ( (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==RULE_ID) ) {
                    int LA21_1 = input.LA(2);

                    if ( (LA21_1==33) ) {
                        alt21=1;
                    }


                }


                switch (alt21) {
            	case 1 :
            	    // InternalMyXDsl.g:1038:4: (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint )
            	    {
            	    // InternalMyXDsl.g:1038:4: (lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint )
            	    // InternalMyXDsl.g:1039:5: lv_execution_time_constraint_5_0= ruleExecution_Time_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getExecution_time_constraintExecution_Time_ConstraintParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_execution_time_constraint_5_0=ruleExecution_Time_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"execution_time_constraint",
            	    						lv_execution_time_constraint_5_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Execution_Time_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            // InternalMyXDsl.g:1056:3: ( (lv_order_constraint_6_0= ruleOrder_Constraint ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==RULE_ID) ) {
                    int LA22_1 = input.LA(2);

                    if ( (LA22_1==30) ) {
                        alt22=1;
                    }


                }


                switch (alt22) {
            	case 1 :
            	    // InternalMyXDsl.g:1057:4: (lv_order_constraint_6_0= ruleOrder_Constraint )
            	    {
            	    // InternalMyXDsl.g:1057:4: (lv_order_constraint_6_0= ruleOrder_Constraint )
            	    // InternalMyXDsl.g:1058:5: lv_order_constraint_6_0= ruleOrder_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getOrder_constraintOrder_ConstraintParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_order_constraint_6_0=ruleOrder_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"order_constraint",
            	    						lv_order_constraint_6_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Order_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            // InternalMyXDsl.g:1075:3: ( (lv_pattern_constraint_7_0= rulePattern_Constraint ) )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==RULE_ID) ) {
                    int LA23_1 = input.LA(2);

                    if ( (LA23_1==28) ) {
                        alt23=1;
                    }


                }


                switch (alt23) {
            	case 1 :
            	    // InternalMyXDsl.g:1076:4: (lv_pattern_constraint_7_0= rulePattern_Constraint )
            	    {
            	    // InternalMyXDsl.g:1076:4: (lv_pattern_constraint_7_0= rulePattern_Constraint )
            	    // InternalMyXDsl.g:1077:5: lv_pattern_constraint_7_0= rulePattern_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getPattern_constraintPattern_ConstraintParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_pattern_constraint_7_0=rulePattern_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"pattern_constraint",
            	    						lv_pattern_constraint_7_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Pattern_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

            // InternalMyXDsl.g:1094:3: ( (lv_reaction_constraint_8_0= ruleReaction_Constraint ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==RULE_ID) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalMyXDsl.g:1095:4: (lv_reaction_constraint_8_0= ruleReaction_Constraint )
            	    {
            	    // InternalMyXDsl.g:1095:4: (lv_reaction_constraint_8_0= ruleReaction_Constraint )
            	    // InternalMyXDsl.g:1096:5: lv_reaction_constraint_8_0= ruleReaction_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getConstraintsAccess().getReaction_constraintReaction_ConstraintParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_reaction_constraint_8_0=ruleReaction_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstraintsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"reaction_constraint",
            	    						lv_reaction_constraint_8_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Reaction_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            otherlv_9=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getConstraintsAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstraints"


    // $ANTLR start "entryRuleReaction_Constraint"
    // InternalMyXDsl.g:1121:1: entryRuleReaction_Constraint returns [EObject current=null] : iv_ruleReaction_Constraint= ruleReaction_Constraint EOF ;
    public final EObject entryRuleReaction_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReaction_Constraint = null;


        try {
            // InternalMyXDsl.g:1121:60: (iv_ruleReaction_Constraint= ruleReaction_Constraint EOF )
            // InternalMyXDsl.g:1122:2: iv_ruleReaction_Constraint= ruleReaction_Constraint EOF
            {
             newCompositeNode(grammarAccess.getReaction_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReaction_Constraint=ruleReaction_Constraint();

            state._fsp--;

             current =iv_ruleReaction_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReaction_Constraint"


    // $ANTLR start "ruleReaction_Constraint"
    // InternalMyXDsl.g:1128:1: ruleReaction_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reaction-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )* otherlv_13= '}' ) ;
    public final EObject ruleReaction_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_scope_11_0=null;
        Token otherlv_13=null;
        EObject lv_timingexpression_12_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:1134:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reaction-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )* otherlv_13= '}' ) )
            // InternalMyXDsl.g:1135:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reaction-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )* otherlv_13= '}' )
            {
            // InternalMyXDsl.g:1135:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reaction-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )* otherlv_13= '}' )
            // InternalMyXDsl.g:1136:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reaction-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )* otherlv_13= '}'
            {
            // InternalMyXDsl.g:1136:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1137:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1137:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1138:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_17); 

            					newLeafNode(lv_define_0_0, grammarAccess.getReaction_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,23,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getReaction_ConstraintAccess().getReactionConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getReaction_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:1162:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1163:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1163:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:1164:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getReaction_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getReaction_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:1184:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1185:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1185:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:1186:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getReaction_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getReaction_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:1206:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1207:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1207:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:1208:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getReaction_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getReaction_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:1228:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:1229:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1229:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:1230:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_18); 

            					newLeafNode(lv_name_9_0, grammarAccess.getReaction_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,24,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getReaction_ConstraintAccess().getSCOPEKeyword_10());
            		
            // InternalMyXDsl.g:1250:3: ( (lv_scope_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:1251:4: (lv_scope_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1251:4: (lv_scope_11_0= RULE_STRING )
            // InternalMyXDsl.g:1252:5: lv_scope_11_0= RULE_STRING
            {
            lv_scope_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_scope_11_0, grammarAccess.getReaction_ConstraintAccess().getScopeSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReaction_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"scope",
            						lv_scope_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:1268:3: ( (lv_timingexpression_12_0= ruleRC_TimingExpression ) )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==RULE_ID) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalMyXDsl.g:1269:4: (lv_timingexpression_12_0= ruleRC_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:1269:4: (lv_timingexpression_12_0= ruleRC_TimingExpression )
            	    // InternalMyXDsl.g:1270:5: lv_timingexpression_12_0= ruleRC_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getReaction_ConstraintAccess().getTimingexpressionRC_TimingExpressionParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_12_0=ruleRC_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getReaction_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_12_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.RC_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getReaction_ConstraintAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReaction_Constraint"


    // $ANTLR start "entryRuleRC_TimingExpression"
    // InternalMyXDsl.g:1295:1: entryRuleRC_TimingExpression returns [EObject current=null] : iv_ruleRC_TimingExpression= ruleRC_TimingExpression EOF ;
    public final EObject entryRuleRC_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRC_TimingExpression = null;


        try {
            // InternalMyXDsl.g:1295:60: (iv_ruleRC_TimingExpression= ruleRC_TimingExpression EOF )
            // InternalMyXDsl.g:1296:2: iv_ruleRC_TimingExpression= ruleRC_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getRC_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRC_TimingExpression=ruleRC_TimingExpression();

            state._fsp--;

             current =iv_ruleRC_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRC_TimingExpression"


    // $ANTLR start "ruleRC_TimingExpression"
    // InternalMyXDsl.g:1302:1: ruleRC_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject ruleRC_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:1308:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:1309:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:1309:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:1310:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:1310:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1311:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1311:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1312:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getRC_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getRC_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getRC_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:1336:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1337:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1337:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:1338:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getRC_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getRC_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:1358:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1359:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1359:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:1360:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getRC_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getRC_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:1380:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1381:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1381:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:1382:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getRC_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getRC_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRC_TimingExpression"


    // $ANTLR start "entryRulePattern_Constraint"
    // InternalMyXDsl.g:1406:1: entryRulePattern_Constraint returns [EObject current=null] : iv_rulePattern_Constraint= rulePattern_Constraint EOF ;
    public final EObject entryRulePattern_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePattern_Constraint = null;


        try {
            // InternalMyXDsl.g:1406:59: (iv_rulePattern_Constraint= rulePattern_Constraint EOF )
            // InternalMyXDsl.g:1407:2: iv_rulePattern_Constraint= rulePattern_Constraint EOF
            {
             newCompositeNode(grammarAccess.getPattern_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePattern_Constraint=rulePattern_Constraint();

            state._fsp--;

             current =iv_rulePattern_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePattern_Constraint"


    // $ANTLR start "rulePattern_Constraint"
    // InternalMyXDsl.g:1413:1: rulePattern_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Pattern-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )* otherlv_13= '}' ) ;
    public final EObject rulePattern_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_event_11_0=null;
        Token otherlv_13=null;
        EObject lv_timingexpression_12_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:1419:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Pattern-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )* otherlv_13= '}' ) )
            // InternalMyXDsl.g:1420:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Pattern-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )* otherlv_13= '}' )
            {
            // InternalMyXDsl.g:1420:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Pattern-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )* otherlv_13= '}' )
            // InternalMyXDsl.g:1421:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Pattern-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )* otherlv_13= '}'
            {
            // InternalMyXDsl.g:1421:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1422:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1422:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1423:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_23); 

            					newLeafNode(lv_define_0_0, grammarAccess.getPattern_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,28,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getPattern_ConstraintAccess().getPatternConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPattern_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:1447:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1448:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1448:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:1449:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getPattern_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getPattern_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:1469:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1470:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1470:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:1471:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getPattern_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getPattern_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:1491:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1492:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1492:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:1493:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getPattern_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getPattern_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:1513:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:1514:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1514:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:1515:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_24); 

            					newLeafNode(lv_name_9_0, grammarAccess.getPattern_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,29,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getPattern_ConstraintAccess().getEVENTKeyword_10());
            		
            // InternalMyXDsl.g:1535:3: ( (lv_event_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:1536:4: (lv_event_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1536:4: (lv_event_11_0= RULE_STRING )
            // InternalMyXDsl.g:1537:5: lv_event_11_0= RULE_STRING
            {
            lv_event_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_event_11_0, grammarAccess.getPattern_ConstraintAccess().getEventSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"event",
            						lv_event_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:1553:3: ( (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==RULE_ID) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalMyXDsl.g:1554:4: (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:1554:4: (lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression )
            	    // InternalMyXDsl.g:1555:5: lv_timingexpression_12_0= rulePattern_Constraint_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getPattern_ConstraintAccess().getTimingexpressionPattern_Constraint_TimingExpressionParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_12_0=rulePattern_Constraint_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getPattern_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_12_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Pattern_Constraint_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getPattern_ConstraintAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePattern_Constraint"


    // $ANTLR start "entryRulePattern_Constraint_TimingExpression"
    // InternalMyXDsl.g:1580:1: entryRulePattern_Constraint_TimingExpression returns [EObject current=null] : iv_rulePattern_Constraint_TimingExpression= rulePattern_Constraint_TimingExpression EOF ;
    public final EObject entryRulePattern_Constraint_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePattern_Constraint_TimingExpression = null;


        try {
            // InternalMyXDsl.g:1580:76: (iv_rulePattern_Constraint_TimingExpression= rulePattern_Constraint_TimingExpression EOF )
            // InternalMyXDsl.g:1581:2: iv_rulePattern_Constraint_TimingExpression= rulePattern_Constraint_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getPattern_Constraint_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePattern_Constraint_TimingExpression=rulePattern_Constraint_TimingExpression();

            state._fsp--;

             current =iv_rulePattern_Constraint_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePattern_Constraint_TimingExpression"


    // $ANTLR start "rulePattern_Constraint_TimingExpression"
    // InternalMyXDsl.g:1587:1: rulePattern_Constraint_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject rulePattern_Constraint_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:1593:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:1594:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:1594:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:1595:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:1595:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1596:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1596:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1597:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_Constraint_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:1621:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1622:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1622:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:1623:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_Constraint_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:1643:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1644:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1644:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:1645:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_Constraint_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:1665:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1666:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1666:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:1667:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPattern_Constraint_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getPattern_Constraint_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePattern_Constraint_TimingExpression"


    // $ANTLR start "entryRuleOrder_Constraint"
    // InternalMyXDsl.g:1691:1: entryRuleOrder_Constraint returns [EObject current=null] : iv_ruleOrder_Constraint= ruleOrder_Constraint EOF ;
    public final EObject entryRuleOrder_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOrder_Constraint = null;


        try {
            // InternalMyXDsl.g:1691:57: (iv_ruleOrder_Constraint= ruleOrder_Constraint EOF )
            // InternalMyXDsl.g:1692:2: iv_ruleOrder_Constraint= ruleOrder_Constraint EOF
            {
             newCompositeNode(grammarAccess.getOrder_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOrder_Constraint=ruleOrder_Constraint();

            state._fsp--;

             current =iv_ruleOrder_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOrder_Constraint"


    // $ANTLR start "ruleOrder_Constraint"
    // InternalMyXDsl.g:1698:1: ruleOrder_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Order-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) otherlv_14= '}' ) ;
    public final EObject ruleOrder_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_target_11_0=null;
        Token otherlv_12=null;
        Token lv_source_13_0=null;
        Token otherlv_14=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:1704:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Order-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) otherlv_14= '}' ) )
            // InternalMyXDsl.g:1705:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Order-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) otherlv_14= '}' )
            {
            // InternalMyXDsl.g:1705:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Order-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) otherlv_14= '}' )
            // InternalMyXDsl.g:1706:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Order-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) otherlv_14= '}'
            {
            // InternalMyXDsl.g:1706:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1707:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1707:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1708:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_25); 

            					newLeafNode(lv_define_0_0, grammarAccess.getOrder_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,30,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getOrder_ConstraintAccess().getOrderConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getOrder_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:1732:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1733:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1733:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:1734:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getOrder_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getOrder_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:1754:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1755:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1755:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:1756:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getOrder_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getOrder_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:1776:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1777:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1777:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:1778:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getOrder_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getOrder_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:1798:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:1799:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1799:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:1800:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

            					newLeafNode(lv_name_9_0, grammarAccess.getOrder_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,31,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getOrder_ConstraintAccess().getTARGETKeyword_10());
            		
            // InternalMyXDsl.g:1820:3: ( (lv_target_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:1821:4: (lv_target_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1821:4: (lv_target_11_0= RULE_STRING )
            // InternalMyXDsl.g:1822:5: lv_target_11_0= RULE_STRING
            {
            lv_target_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_target_11_0, grammarAccess.getOrder_ConstraintAccess().getTargetSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"target",
            						lv_target_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,32,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getOrder_ConstraintAccess().getSOURCEKeyword_12());
            		
            // InternalMyXDsl.g:1842:3: ( (lv_source_13_0= RULE_STRING ) )
            // InternalMyXDsl.g:1843:4: (lv_source_13_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1843:4: (lv_source_13_0= RULE_STRING )
            // InternalMyXDsl.g:1844:5: lv_source_13_0= RULE_STRING
            {
            lv_source_13_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_source_13_0, grammarAccess.getOrder_ConstraintAccess().getSourceSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOrder_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"source",
            						lv_source_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_14=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getOrder_ConstraintAccess().getRightCurlyBracketKeyword_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOrder_Constraint"


    // $ANTLR start "entryRuleExecution_Time_Constraint"
    // InternalMyXDsl.g:1868:1: entryRuleExecution_Time_Constraint returns [EObject current=null] : iv_ruleExecution_Time_Constraint= ruleExecution_Time_Constraint EOF ;
    public final EObject entryRuleExecution_Time_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExecution_Time_Constraint = null;


        try {
            // InternalMyXDsl.g:1868:66: (iv_ruleExecution_Time_Constraint= ruleExecution_Time_Constraint EOF )
            // InternalMyXDsl.g:1869:2: iv_ruleExecution_Time_Constraint= ruleExecution_Time_Constraint EOF
            {
             newCompositeNode(grammarAccess.getExecution_Time_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExecution_Time_Constraint=ruleExecution_Time_Constraint();

            state._fsp--;

             current =iv_ruleExecution_Time_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExecution_Time_Constraint"


    // $ANTLR start "ruleExecution_Time_Constraint"
    // InternalMyXDsl.g:1875:1: ruleExecution_Time_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Execution-Time-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )? (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )? otherlv_14= 'START:' ( (lv_start_15_0= RULE_STRING ) ) otherlv_16= 'STOP:' ( (lv_stop_17_0= RULE_STRING ) ) ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )* otherlv_19= '}' ) ;
    public final EObject ruleExecution_Time_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_resume_ref_11_0=null;
        Token otherlv_12=null;
        Token lv_preemption_refs_13_0=null;
        Token otherlv_14=null;
        Token lv_start_15_0=null;
        Token otherlv_16=null;
        Token lv_stop_17_0=null;
        Token otherlv_19=null;
        EObject lv_timingexpression_18_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:1881:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Execution-Time-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )? (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )? otherlv_14= 'START:' ( (lv_start_15_0= RULE_STRING ) ) otherlv_16= 'STOP:' ( (lv_stop_17_0= RULE_STRING ) ) ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )* otherlv_19= '}' ) )
            // InternalMyXDsl.g:1882:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Execution-Time-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )? (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )? otherlv_14= 'START:' ( (lv_start_15_0= RULE_STRING ) ) otherlv_16= 'STOP:' ( (lv_stop_17_0= RULE_STRING ) ) ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )* otherlv_19= '}' )
            {
            // InternalMyXDsl.g:1882:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Execution-Time-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )? (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )? otherlv_14= 'START:' ( (lv_start_15_0= RULE_STRING ) ) otherlv_16= 'STOP:' ( (lv_stop_17_0= RULE_STRING ) ) ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )* otherlv_19= '}' )
            // InternalMyXDsl.g:1883:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Execution-Time-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )? (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )? otherlv_14= 'START:' ( (lv_start_15_0= RULE_STRING ) ) otherlv_16= 'STOP:' ( (lv_stop_17_0= RULE_STRING ) ) ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )* otherlv_19= '}'
            {
            // InternalMyXDsl.g:1883:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:1884:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:1884:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:1885:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_28); 

            					newLeafNode(lv_define_0_0, grammarAccess.getExecution_Time_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,33,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getExecution_Time_ConstraintAccess().getExecutionTimeConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getExecution_Time_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:1909:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:1910:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1910:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:1911:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getExecution_Time_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getExecution_Time_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:1931:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:1932:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1932:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:1933:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getExecution_Time_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getExecution_Time_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:1953:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:1954:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1954:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:1955:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getExecution_Time_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getExecution_Time_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:1975:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:1976:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:1976:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:1977:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_29); 

            					newLeafNode(lv_name_9_0, grammarAccess.getExecution_Time_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:1993:3: (otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==34) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalMyXDsl.g:1994:4: otherlv_10= 'RESUME-REFS:' ( (lv_resume_ref_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,34,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getExecution_Time_ConstraintAccess().getRESUMEREFSKeyword_10_0());
                    			
                    // InternalMyXDsl.g:1998:4: ( (lv_resume_ref_11_0= RULE_STRING ) )
                    // InternalMyXDsl.g:1999:5: (lv_resume_ref_11_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:1999:5: (lv_resume_ref_11_0= RULE_STRING )
                    // InternalMyXDsl.g:2000:6: lv_resume_ref_11_0= RULE_STRING
                    {
                    lv_resume_ref_11_0=(Token)match(input,RULE_STRING,FOLLOW_30); 

                    						newLeafNode(lv_resume_ref_11_0, grammarAccess.getExecution_Time_ConstraintAccess().getResume_refSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"resume_ref",
                    							lv_resume_ref_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:2017:3: (otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==35) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalMyXDsl.g:2018:4: otherlv_12= 'PREEMPTION-REFS:' ( (lv_preemption_refs_13_0= RULE_STRING ) )
                    {
                    otherlv_12=(Token)match(input,35,FOLLOW_6); 

                    				newLeafNode(otherlv_12, grammarAccess.getExecution_Time_ConstraintAccess().getPREEMPTIONREFSKeyword_11_0());
                    			
                    // InternalMyXDsl.g:2022:4: ( (lv_preemption_refs_13_0= RULE_STRING ) )
                    // InternalMyXDsl.g:2023:5: (lv_preemption_refs_13_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:2023:5: (lv_preemption_refs_13_0= RULE_STRING )
                    // InternalMyXDsl.g:2024:6: lv_preemption_refs_13_0= RULE_STRING
                    {
                    lv_preemption_refs_13_0=(Token)match(input,RULE_STRING,FOLLOW_31); 

                    						newLeafNode(lv_preemption_refs_13_0, grammarAccess.getExecution_Time_ConstraintAccess().getPreemption_refsSTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"preemption_refs",
                    							lv_preemption_refs_13_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,36,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getExecution_Time_ConstraintAccess().getSTARTKeyword_12());
            		
            // InternalMyXDsl.g:2045:3: ( (lv_start_15_0= RULE_STRING ) )
            // InternalMyXDsl.g:2046:4: (lv_start_15_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2046:4: (lv_start_15_0= RULE_STRING )
            // InternalMyXDsl.g:2047:5: lv_start_15_0= RULE_STRING
            {
            lv_start_15_0=(Token)match(input,RULE_STRING,FOLLOW_32); 

            					newLeafNode(lv_start_15_0, grammarAccess.getExecution_Time_ConstraintAccess().getStartSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"start",
            						lv_start_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_16=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getExecution_Time_ConstraintAccess().getSTOPKeyword_14());
            		
            // InternalMyXDsl.g:2067:3: ( (lv_stop_17_0= RULE_STRING ) )
            // InternalMyXDsl.g:2068:4: (lv_stop_17_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2068:4: (lv_stop_17_0= RULE_STRING )
            // InternalMyXDsl.g:2069:5: lv_stop_17_0= RULE_STRING
            {
            lv_stop_17_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_stop_17_0, grammarAccess.getExecution_Time_ConstraintAccess().getStopSTRINGTerminalRuleCall_15_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExecution_Time_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"stop",
            						lv_stop_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:2085:3: ( (lv_timingexpression_18_0= ruleETC_TimingExpression ) )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==RULE_ID) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // InternalMyXDsl.g:2086:4: (lv_timingexpression_18_0= ruleETC_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:2086:4: (lv_timingexpression_18_0= ruleETC_TimingExpression )
            	    // InternalMyXDsl.g:2087:5: lv_timingexpression_18_0= ruleETC_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getExecution_Time_ConstraintAccess().getTimingexpressionETC_TimingExpressionParserRuleCall_16_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_18_0=ruleETC_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getExecution_Time_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_18_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.ETC_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

            otherlv_19=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_19, grammarAccess.getExecution_Time_ConstraintAccess().getRightCurlyBracketKeyword_17());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExecution_Time_Constraint"


    // $ANTLR start "entryRuleETC_TimingExpression"
    // InternalMyXDsl.g:2112:1: entryRuleETC_TimingExpression returns [EObject current=null] : iv_ruleETC_TimingExpression= ruleETC_TimingExpression EOF ;
    public final EObject entryRuleETC_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleETC_TimingExpression = null;


        try {
            // InternalMyXDsl.g:2112:61: (iv_ruleETC_TimingExpression= ruleETC_TimingExpression EOF )
            // InternalMyXDsl.g:2113:2: iv_ruleETC_TimingExpression= ruleETC_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getETC_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleETC_TimingExpression=ruleETC_TimingExpression();

            state._fsp--;

             current =iv_ruleETC_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleETC_TimingExpression"


    // $ANTLR start "ruleETC_TimingExpression"
    // InternalMyXDsl.g:2119:1: ruleETC_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject ruleETC_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:2125:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:2126:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:2126:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:2127:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:2127:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2128:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2128:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2129:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getETC_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getETC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getETC_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getETC_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:2153:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2154:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2154:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:2155:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getETC_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getETC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getETC_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:2175:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2176:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2176:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:2177:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getETC_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getETC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getETC_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:2197:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2198:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2198:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:2199:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getETC_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getETC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getETC_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleETC_TimingExpression"


    // $ANTLR start "entryRuleAge_Constraint"
    // InternalMyXDsl.g:2223:1: entryRuleAge_Constraint returns [EObject current=null] : iv_ruleAge_Constraint= ruleAge_Constraint EOF ;
    public final EObject entryRuleAge_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAge_Constraint = null;


        try {
            // InternalMyXDsl.g:2223:55: (iv_ruleAge_Constraint= ruleAge_Constraint EOF )
            // InternalMyXDsl.g:2224:2: iv_ruleAge_Constraint= ruleAge_Constraint EOF
            {
             newCompositeNode(grammarAccess.getAge_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAge_Constraint=ruleAge_Constraint();

            state._fsp--;

             current =iv_ruleAge_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAge_Constraint"


    // $ANTLR start "ruleAge_Constraint"
    // InternalMyXDsl.g:2230:1: ruleAge_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Age-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )* otherlv_13= '}' ) ;
    public final EObject ruleAge_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_scope_11_0=null;
        Token otherlv_13=null;
        EObject lv_timingexpression_12_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:2236:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Age-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )* otherlv_13= '}' ) )
            // InternalMyXDsl.g:2237:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Age-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )* otherlv_13= '}' )
            {
            // InternalMyXDsl.g:2237:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Age-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )* otherlv_13= '}' )
            // InternalMyXDsl.g:2238:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Age-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SCOPE:' ( (lv_scope_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )* otherlv_13= '}'
            {
            // InternalMyXDsl.g:2238:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2239:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2239:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2240:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_33); 

            					newLeafNode(lv_define_0_0, grammarAccess.getAge_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,38,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getAge_ConstraintAccess().getAgeConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getAge_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:2264:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2265:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2265:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:2266:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getAge_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getAge_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:2286:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2287:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2287:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:2288:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getAge_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getAge_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:2308:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2309:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2309:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:2310:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getAge_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getAge_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:2330:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:2331:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2331:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:2332:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_18); 

            					newLeafNode(lv_name_9_0, grammarAccess.getAge_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,24,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getAge_ConstraintAccess().getSCOPEKeyword_10());
            		
            // InternalMyXDsl.g:2352:3: ( (lv_scope_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:2353:4: (lv_scope_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2353:4: (lv_scope_11_0= RULE_STRING )
            // InternalMyXDsl.g:2354:5: lv_scope_11_0= RULE_STRING
            {
            lv_scope_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_scope_11_0, grammarAccess.getAge_ConstraintAccess().getScopeSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAge_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"scope",
            						lv_scope_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:2370:3: ( (lv_timingexpression_12_0= ruleAC_TimingExpression ) )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==RULE_ID) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalMyXDsl.g:2371:4: (lv_timingexpression_12_0= ruleAC_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:2371:4: (lv_timingexpression_12_0= ruleAC_TimingExpression )
            	    // InternalMyXDsl.g:2372:5: lv_timingexpression_12_0= ruleAC_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getAge_ConstraintAccess().getTimingexpressionAC_TimingExpressionParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_12_0=ruleAC_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getAge_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_12_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.AC_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getAge_ConstraintAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAge_Constraint"


    // $ANTLR start "entryRuleAC_TimingExpression"
    // InternalMyXDsl.g:2397:1: entryRuleAC_TimingExpression returns [EObject current=null] : iv_ruleAC_TimingExpression= ruleAC_TimingExpression EOF ;
    public final EObject entryRuleAC_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAC_TimingExpression = null;


        try {
            // InternalMyXDsl.g:2397:60: (iv_ruleAC_TimingExpression= ruleAC_TimingExpression EOF )
            // InternalMyXDsl.g:2398:2: iv_ruleAC_TimingExpression= ruleAC_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getAC_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAC_TimingExpression=ruleAC_TimingExpression();

            state._fsp--;

             current =iv_ruleAC_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAC_TimingExpression"


    // $ANTLR start "ruleAC_TimingExpression"
    // InternalMyXDsl.g:2404:1: ruleAC_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject ruleAC_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:2410:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:2411:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:2411:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:2412:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:2412:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2413:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2413:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2414:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getAC_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getAC_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getAC_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:2438:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2439:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2439:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:2440:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getAC_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getAC_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:2460:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2461:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2461:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:2462:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getAC_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getAC_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:2482:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2483:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2483:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:2484:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getAC_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getAC_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAC_TimingExpression"


    // $ANTLR start "entryRuleDelay_Constraint"
    // InternalMyXDsl.g:2508:1: entryRuleDelay_Constraint returns [EObject current=null] : iv_ruleDelay_Constraint= ruleDelay_Constraint EOF ;
    public final EObject entryRuleDelay_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDelay_Constraint = null;


        try {
            // InternalMyXDsl.g:2508:57: (iv_ruleDelay_Constraint= ruleDelay_Constraint EOF )
            // InternalMyXDsl.g:2509:2: iv_ruleDelay_Constraint= ruleDelay_Constraint EOF
            {
             newCompositeNode(grammarAccess.getDelay_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDelay_Constraint=ruleDelay_Constraint();

            state._fsp--;

             current =iv_ruleDelay_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDelay_Constraint"


    // $ANTLR start "ruleDelay_Constraint"
    // InternalMyXDsl.g:2515:1: ruleDelay_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Delay-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )* otherlv_15= '}' ) ;
    public final EObject ruleDelay_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_target_11_0=null;
        Token otherlv_12=null;
        Token lv_source_13_0=null;
        Token otherlv_15=null;
        EObject lv_timingexpression_14_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:2521:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Delay-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )* otherlv_15= '}' ) )
            // InternalMyXDsl.g:2522:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Delay-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )* otherlv_15= '}' )
            {
            // InternalMyXDsl.g:2522:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Delay-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )* otherlv_15= '}' )
            // InternalMyXDsl.g:2523:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Delay-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'TARGET:' ( (lv_target_11_0= RULE_STRING ) ) otherlv_12= 'SOURCE:' ( (lv_source_13_0= RULE_STRING ) ) ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )* otherlv_15= '}'
            {
            // InternalMyXDsl.g:2523:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2524:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2524:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2525:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_34); 

            					newLeafNode(lv_define_0_0, grammarAccess.getDelay_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,39,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getDelay_ConstraintAccess().getDelayConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getDelay_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:2549:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2550:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2550:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:2551:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getDelay_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getDelay_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:2571:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2572:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2572:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:2573:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getDelay_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getDelay_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:2593:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2594:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2594:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:2595:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getDelay_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getDelay_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:2615:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:2616:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2616:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:2617:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

            					newLeafNode(lv_name_9_0, grammarAccess.getDelay_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,31,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getDelay_ConstraintAccess().getTARGETKeyword_10());
            		
            // InternalMyXDsl.g:2637:3: ( (lv_target_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:2638:4: (lv_target_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2638:4: (lv_target_11_0= RULE_STRING )
            // InternalMyXDsl.g:2639:5: lv_target_11_0= RULE_STRING
            {
            lv_target_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_target_11_0, grammarAccess.getDelay_ConstraintAccess().getTargetSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"target",
            						lv_target_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,32,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getDelay_ConstraintAccess().getSOURCEKeyword_12());
            		
            // InternalMyXDsl.g:2659:3: ( (lv_source_13_0= RULE_STRING ) )
            // InternalMyXDsl.g:2660:4: (lv_source_13_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2660:4: (lv_source_13_0= RULE_STRING )
            // InternalMyXDsl.g:2661:5: lv_source_13_0= RULE_STRING
            {
            lv_source_13_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_source_13_0, grammarAccess.getDelay_ConstraintAccess().getSourceSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDelay_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"source",
            						lv_source_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:2677:3: ( (lv_timingexpression_14_0= ruleDC_TimingExpression ) )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==RULE_ID) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalMyXDsl.g:2678:4: (lv_timingexpression_14_0= ruleDC_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:2678:4: (lv_timingexpression_14_0= ruleDC_TimingExpression )
            	    // InternalMyXDsl.g:2679:5: lv_timingexpression_14_0= ruleDC_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getDelay_ConstraintAccess().getTimingexpressionDC_TimingExpressionParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_14_0=ruleDC_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDelay_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_14_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.DC_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getDelay_ConstraintAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDelay_Constraint"


    // $ANTLR start "entryRuleDC_TimingExpression"
    // InternalMyXDsl.g:2704:1: entryRuleDC_TimingExpression returns [EObject current=null] : iv_ruleDC_TimingExpression= ruleDC_TimingExpression EOF ;
    public final EObject entryRuleDC_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDC_TimingExpression = null;


        try {
            // InternalMyXDsl.g:2704:60: (iv_ruleDC_TimingExpression= ruleDC_TimingExpression EOF )
            // InternalMyXDsl.g:2705:2: iv_ruleDC_TimingExpression= ruleDC_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getDC_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDC_TimingExpression=ruleDC_TimingExpression();

            state._fsp--;

             current =iv_ruleDC_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDC_TimingExpression"


    // $ANTLR start "ruleDC_TimingExpression"
    // InternalMyXDsl.g:2711:1: ruleDC_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject ruleDC_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:2717:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:2718:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:2718:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:2719:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:2719:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2720:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2720:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2721:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getDC_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getDC_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getDC_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:2745:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2746:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2746:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:2747:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getDC_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getDC_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:2767:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2768:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2768:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:2769:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getDC_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getDC_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:2789:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2790:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2790:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:2791:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getDC_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getDC_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDC_TimingExpression"


    // $ANTLR start "entryRulePeriodic_Constraint"
    // InternalMyXDsl.g:2815:1: entryRulePeriodic_Constraint returns [EObject current=null] : iv_rulePeriodic_Constraint= rulePeriodic_Constraint EOF ;
    public final EObject entryRulePeriodic_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePeriodic_Constraint = null;


        try {
            // InternalMyXDsl.g:2815:60: (iv_rulePeriodic_Constraint= rulePeriodic_Constraint EOF )
            // InternalMyXDsl.g:2816:2: iv_rulePeriodic_Constraint= rulePeriodic_Constraint EOF
            {
             newCompositeNode(grammarAccess.getPeriodic_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePeriodic_Constraint=rulePeriodic_Constraint();

            state._fsp--;

             current =iv_rulePeriodic_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePeriodic_Constraint"


    // $ANTLR start "rulePeriodic_Constraint"
    // InternalMyXDsl.g:2822:1: rulePeriodic_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Periodic-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )* otherlv_13= '}' ) ;
    public final EObject rulePeriodic_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_event_11_0=null;
        Token otherlv_13=null;
        EObject lv_timingexpression_12_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:2828:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Periodic-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )* otherlv_13= '}' ) )
            // InternalMyXDsl.g:2829:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Periodic-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )* otherlv_13= '}' )
            {
            // InternalMyXDsl.g:2829:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Periodic-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )* otherlv_13= '}' )
            // InternalMyXDsl.g:2830:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Periodic-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'EVENT:' ( (lv_event_11_0= RULE_STRING ) ) ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )* otherlv_13= '}'
            {
            // InternalMyXDsl.g:2830:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:2831:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:2831:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:2832:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_35); 

            					newLeafNode(lv_define_0_0, grammarAccess.getPeriodic_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,40,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getPeriodic_ConstraintAccess().getPeriodicConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPeriodic_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:2856:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:2857:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2857:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:2858:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getPeriodic_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getPeriodic_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:2878:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:2879:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2879:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:2880:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getPeriodic_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getPeriodic_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:2900:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:2901:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2901:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:2902:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getPeriodic_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getPeriodic_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:2922:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:2923:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2923:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:2924:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_24); 

            					newLeafNode(lv_name_9_0, grammarAccess.getPeriodic_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,29,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getPeriodic_ConstraintAccess().getEVENTKeyword_10());
            		
            // InternalMyXDsl.g:2944:3: ( (lv_event_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:2945:4: (lv_event_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:2945:4: (lv_event_11_0= RULE_STRING )
            // InternalMyXDsl.g:2946:5: lv_event_11_0= RULE_STRING
            {
            lv_event_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_event_11_0, grammarAccess.getPeriodic_ConstraintAccess().getEventSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPeriodic_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"event",
            						lv_event_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:2962:3: ( (lv_timingexpression_12_0= rulePC_TimingExpression ) )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==RULE_ID) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalMyXDsl.g:2963:4: (lv_timingexpression_12_0= rulePC_TimingExpression )
            	    {
            	    // InternalMyXDsl.g:2963:4: (lv_timingexpression_12_0= rulePC_TimingExpression )
            	    // InternalMyXDsl.g:2964:5: lv_timingexpression_12_0= rulePC_TimingExpression
            	    {

            	    					newCompositeNode(grammarAccess.getPeriodic_ConstraintAccess().getTimingexpressionPC_TimingExpressionParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_timingexpression_12_0=rulePC_TimingExpression();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getPeriodic_ConstraintRule());
            	    					}
            	    					add(
            	    						current,
            	    						"timingexpression",
            	    						lv_timingexpression_12_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.PC_TimingExpression");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getPeriodic_ConstraintAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePeriodic_Constraint"


    // $ANTLR start "entryRulePC_TimingExpression"
    // InternalMyXDsl.g:2989:1: entryRulePC_TimingExpression returns [EObject current=null] : iv_rulePC_TimingExpression= rulePC_TimingExpression EOF ;
    public final EObject entryRulePC_TimingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePC_TimingExpression = null;


        try {
            // InternalMyXDsl.g:2989:60: (iv_rulePC_TimingExpression= rulePC_TimingExpression EOF )
            // InternalMyXDsl.g:2990:2: iv_rulePC_TimingExpression= rulePC_TimingExpression EOF
            {
             newCompositeNode(grammarAccess.getPC_TimingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePC_TimingExpression=rulePC_TimingExpression();

            state._fsp--;

             current =iv_rulePC_TimingExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePC_TimingExpression"


    // $ANTLR start "rulePC_TimingExpression"
    // InternalMyXDsl.g:2996:1: rulePC_TimingExpression returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) ;
    public final EObject rulePC_TimingExpression() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_type_5_0=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:3002:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' ) )
            // InternalMyXDsl.g:3003:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            {
            // InternalMyXDsl.g:3003:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}' )
            // InternalMyXDsl.g:3004:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Timing Expression {' otherlv_2= 'NAME:' ( (lv_name_3_0= RULE_STRING ) ) otherlv_4= 'TYPE:' ( (lv_type_5_0= RULE_STRING ) ) otherlv_6= 'Value:' ( (lv_value_7_0= RULE_STRING ) ) otherlv_8= '}'
            {
            // InternalMyXDsl.g:3004:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3005:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3005:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3006:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getPC_TimingExpressionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getPC_TimingExpressionAccess().getTimingExpressionKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPC_TimingExpressionAccess().getNAMEKeyword_2());
            		
            // InternalMyXDsl.g:3030:3: ( (lv_name_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:3031:4: (lv_name_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3031:4: (lv_name_3_0= RULE_STRING )
            // InternalMyXDsl.g:3032:5: lv_name_3_0= RULE_STRING
            {
            lv_name_3_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_3_0, grammarAccess.getPC_TimingExpressionAccess().getNameSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getPC_TimingExpressionAccess().getTYPEKeyword_4());
            		
            // InternalMyXDsl.g:3052:3: ( (lv_type_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:3053:4: (lv_type_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3053:4: (lv_type_5_0= RULE_STRING )
            // InternalMyXDsl.g:3054:5: lv_type_5_0= RULE_STRING
            {
            lv_type_5_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_type_5_0, grammarAccess.getPC_TimingExpressionAccess().getTypeSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getPC_TimingExpressionAccess().getValueKeyword_6());
            		
            // InternalMyXDsl.g:3074:3: ( (lv_value_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:3075:4: (lv_value_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3075:4: (lv_value_7_0= RULE_STRING )
            // InternalMyXDsl.g:3076:5: lv_value_7_0= RULE_STRING
            {
            lv_value_7_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_value_7_0, grammarAccess.getPC_TimingExpressionAccess().getValueSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPC_TimingExpressionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getPC_TimingExpressionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePC_TimingExpression"


    // $ANTLR start "entryRuleDescriptions"
    // InternalMyXDsl.g:3100:1: entryRuleDescriptions returns [EObject current=null] : iv_ruleDescriptions= ruleDescriptions EOF ;
    public final EObject entryRuleDescriptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDescriptions = null;


        try {
            // InternalMyXDsl.g:3100:53: (iv_ruleDescriptions= ruleDescriptions EOF )
            // InternalMyXDsl.g:3101:2: iv_ruleDescriptions= ruleDescriptions EOF
            {
             newCompositeNode(grammarAccess.getDescriptionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDescriptions=ruleDescriptions();

            state._fsp--;

             current =iv_ruleDescriptions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDescriptions"


    // $ANTLR start "ruleDescriptions"
    // InternalMyXDsl.g:3107:1: ruleDescriptions returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Events {' ( (lv_event_function_2_0= ruleEvent_Function ) )* ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )* ( (lv_event_chain_4_0= ruleEvent_Chain ) )* otherlv_5= '}' ) ;
    public final EObject ruleDescriptions() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_5=null;
        EObject lv_event_function_2_0 = null;

        EObject lv_event_function_flow_port_3_0 = null;

        EObject lv_event_chain_4_0 = null;



        	enterRule();

        try {
            // InternalMyXDsl.g:3113:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Events {' ( (lv_event_function_2_0= ruleEvent_Function ) )* ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )* ( (lv_event_chain_4_0= ruleEvent_Chain ) )* otherlv_5= '}' ) )
            // InternalMyXDsl.g:3114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Events {' ( (lv_event_function_2_0= ruleEvent_Function ) )* ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )* ( (lv_event_chain_4_0= ruleEvent_Chain ) )* otherlv_5= '}' )
            {
            // InternalMyXDsl.g:3114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Events {' ( (lv_event_function_2_0= ruleEvent_Function ) )* ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )* ( (lv_event_chain_4_0= ruleEvent_Chain ) )* otherlv_5= '}' )
            // InternalMyXDsl.g:3115:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Events {' ( (lv_event_function_2_0= ruleEvent_Function ) )* ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )* ( (lv_event_chain_4_0= ruleEvent_Chain ) )* otherlv_5= '}'
            {
            // InternalMyXDsl.g:3115:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3116:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3116:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3117:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_36); 

            					newLeafNode(lv_define_0_0, grammarAccess.getDescriptionsAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDescriptionsRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,41,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getDescriptionsAccess().getEventsKeyword_1());
            		
            // InternalMyXDsl.g:3137:3: ( (lv_event_function_2_0= ruleEvent_Function ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==RULE_ID) ) {
                    int LA33_1 = input.LA(2);

                    if ( (LA33_1==51) ) {
                        alt33=1;
                    }


                }


                switch (alt33) {
            	case 1 :
            	    // InternalMyXDsl.g:3138:4: (lv_event_function_2_0= ruleEvent_Function )
            	    {
            	    // InternalMyXDsl.g:3138:4: (lv_event_function_2_0= ruleEvent_Function )
            	    // InternalMyXDsl.g:3139:5: lv_event_function_2_0= ruleEvent_Function
            	    {

            	    					newCompositeNode(grammarAccess.getDescriptionsAccess().getEvent_functionEvent_FunctionParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_event_function_2_0=ruleEvent_Function();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDescriptionsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"event_function",
            	    						lv_event_function_2_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Event_Function");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            // InternalMyXDsl.g:3156:3: ( (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port ) )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( (LA34_0==RULE_ID) ) {
                    int LA34_1 = input.LA(2);

                    if ( (LA34_1==46) ) {
                        alt34=1;
                    }


                }


                switch (alt34) {
            	case 1 :
            	    // InternalMyXDsl.g:3157:4: (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port )
            	    {
            	    // InternalMyXDsl.g:3157:4: (lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port )
            	    // InternalMyXDsl.g:3158:5: lv_event_function_flow_port_3_0= ruleEvent_Function_Flow_Port
            	    {

            	    					newCompositeNode(grammarAccess.getDescriptionsAccess().getEvent_function_flow_portEvent_Function_Flow_PortParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_event_function_flow_port_3_0=ruleEvent_Function_Flow_Port();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDescriptionsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"event_function_flow_port",
            	    						lv_event_function_flow_port_3_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Event_Function_Flow_Port");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);

            // InternalMyXDsl.g:3175:3: ( (lv_event_chain_4_0= ruleEvent_Chain ) )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( (LA35_0==RULE_ID) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // InternalMyXDsl.g:3176:4: (lv_event_chain_4_0= ruleEvent_Chain )
            	    {
            	    // InternalMyXDsl.g:3176:4: (lv_event_chain_4_0= ruleEvent_Chain )
            	    // InternalMyXDsl.g:3177:5: lv_event_chain_4_0= ruleEvent_Chain
            	    {

            	    					newCompositeNode(grammarAccess.getDescriptionsAccess().getEvent_chainEvent_ChainParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_event_chain_4_0=ruleEvent_Chain();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getDescriptionsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"event_chain",
            	    						lv_event_chain_4_0,
            	    						"org.xtext.example.myxdsl.MyXDsl.Event_Chain");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);

            otherlv_5=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getDescriptionsAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDescriptions"


    // $ANTLR start "entryRuleEvent_Chain"
    // InternalMyXDsl.g:3202:1: entryRuleEvent_Chain returns [EObject current=null] : iv_ruleEvent_Chain= ruleEvent_Chain EOF ;
    public final EObject entryRuleEvent_Chain() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent_Chain = null;


        try {
            // InternalMyXDsl.g:3202:52: (iv_ruleEvent_Chain= ruleEvent_Chain EOF )
            // InternalMyXDsl.g:3203:2: iv_ruleEvent_Chain= ruleEvent_Chain EOF
            {
             newCompositeNode(grammarAccess.getEvent_ChainRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent_Chain=ruleEvent_Chain();

            state._fsp--;

             current =iv_ruleEvent_Chain; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent_Chain"


    // $ANTLR start "ruleEvent_Chain"
    // InternalMyXDsl.g:3209:1: ruleEvent_Chain returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Chain {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )? otherlv_12= 'STIMULUS:' ( (lv_stimulus_13_0= RULE_STRING ) ) otherlv_14= 'RESPONSE:' ( (lv_response_15_0= RULE_STRING ) ) otherlv_16= '}' ) ;
    public final EObject ruleEvent_Chain() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_segment_ref_11_0=null;
        Token otherlv_12=null;
        Token lv_stimulus_13_0=null;
        Token otherlv_14=null;
        Token lv_response_15_0=null;
        Token otherlv_16=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:3215:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Chain {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )? otherlv_12= 'STIMULUS:' ( (lv_stimulus_13_0= RULE_STRING ) ) otherlv_14= 'RESPONSE:' ( (lv_response_15_0= RULE_STRING ) ) otherlv_16= '}' ) )
            // InternalMyXDsl.g:3216:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Chain {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )? otherlv_12= 'STIMULUS:' ( (lv_stimulus_13_0= RULE_STRING ) ) otherlv_14= 'RESPONSE:' ( (lv_response_15_0= RULE_STRING ) ) otherlv_16= '}' )
            {
            // InternalMyXDsl.g:3216:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Chain {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )? otherlv_12= 'STIMULUS:' ( (lv_stimulus_13_0= RULE_STRING ) ) otherlv_14= 'RESPONSE:' ( (lv_response_15_0= RULE_STRING ) ) otherlv_16= '}' )
            // InternalMyXDsl.g:3217:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Chain {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )? otherlv_12= 'STIMULUS:' ( (lv_stimulus_13_0= RULE_STRING ) ) otherlv_14= 'RESPONSE:' ( (lv_response_15_0= RULE_STRING ) ) otherlv_16= '}'
            {
            // InternalMyXDsl.g:3217:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3218:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3218:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3219:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_37); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEvent_ChainAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,42,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEvent_ChainAccess().getEventChainKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEvent_ChainAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:3243:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:3244:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3244:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:3245:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEvent_ChainAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEvent_ChainAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:3265:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:3266:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3266:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:3267:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEvent_ChainAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEvent_ChainAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:3287:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:3288:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3288:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:3289:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEvent_ChainAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEvent_ChainAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:3309:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:3310:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3310:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:3311:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEvent_ChainAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:3327:3: (otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) ) )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==43) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalMyXDsl.g:3328:4: otherlv_10= 'SEGMENT-REFS:' ( (lv_segment_ref_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,43,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getEvent_ChainAccess().getSEGMENTREFSKeyword_10_0());
                    			
                    // InternalMyXDsl.g:3332:4: ( (lv_segment_ref_11_0= RULE_STRING ) )
                    // InternalMyXDsl.g:3333:5: (lv_segment_ref_11_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:3333:5: (lv_segment_ref_11_0= RULE_STRING )
                    // InternalMyXDsl.g:3334:6: lv_segment_ref_11_0= RULE_STRING
                    {
                    lv_segment_ref_11_0=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    						newLeafNode(lv_segment_ref_11_0, grammarAccess.getEvent_ChainAccess().getSegment_refSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEvent_ChainRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"segment_ref",
                    							lv_segment_ref_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_12=(Token)match(input,44,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getEvent_ChainAccess().getSTIMULUSKeyword_11());
            		
            // InternalMyXDsl.g:3355:3: ( (lv_stimulus_13_0= RULE_STRING ) )
            // InternalMyXDsl.g:3356:4: (lv_stimulus_13_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3356:4: (lv_stimulus_13_0= RULE_STRING )
            // InternalMyXDsl.g:3357:5: lv_stimulus_13_0= RULE_STRING
            {
            lv_stimulus_13_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

            					newLeafNode(lv_stimulus_13_0, grammarAccess.getEvent_ChainAccess().getStimulusSTRINGTerminalRuleCall_12_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"stimulus",
            						lv_stimulus_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_14=(Token)match(input,45,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getEvent_ChainAccess().getRESPONSEKeyword_13());
            		
            // InternalMyXDsl.g:3377:3: ( (lv_response_15_0= RULE_STRING ) )
            // InternalMyXDsl.g:3378:4: (lv_response_15_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3378:4: (lv_response_15_0= RULE_STRING )
            // InternalMyXDsl.g:3379:5: lv_response_15_0= RULE_STRING
            {
            lv_response_15_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_response_15_0, grammarAccess.getEvent_ChainAccess().getResponseSTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_ChainRule());
            					}
            					setWithLastConsumed(
            						current,
            						"response",
            						lv_response_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getEvent_ChainAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent_Chain"


    // $ANTLR start "entryRuleEvent_Function_Flow_Port"
    // InternalMyXDsl.g:3403:1: entryRuleEvent_Function_Flow_Port returns [EObject current=null] : iv_ruleEvent_Function_Flow_Port= ruleEvent_Function_Flow_Port EOF ;
    public final EObject entryRuleEvent_Function_Flow_Port() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent_Function_Flow_Port = null;


        try {
            // InternalMyXDsl.g:3403:65: (iv_ruleEvent_Function_Flow_Port= ruleEvent_Function_Flow_Port EOF )
            // InternalMyXDsl.g:3404:2: iv_ruleEvent_Function_Flow_Port= ruleEvent_Function_Flow_Port EOF
            {
             newCompositeNode(grammarAccess.getEvent_Function_Flow_PortRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent_Function_Flow_Port=ruleEvent_Function_Flow_Port();

            state._fsp--;

             current =iv_ruleEvent_Function_Flow_Port; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent_Function_Flow_Port"


    // $ANTLR start "ruleEvent_Function_Flow_Port"
    // InternalMyXDsl.g:3410:1: ruleEvent_Function_Flow_Port returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function-Flow-Port {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FUNCTION-PROTOTYPE:' ( (lv_func_prototype_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-FLOW-PORT:' ( (lv_func_flow_port_17_0= RULE_STRING ) ) otherlv_18= '}' ) ;
    public final EObject ruleEvent_Function_Flow_Port() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_func_type_11_0=null;
        Token otherlv_12=null;
        Token lv_func_value_13_0=null;
        Token otherlv_14=null;
        Token lv_func_prototype_15_0=null;
        Token otherlv_16=null;
        Token lv_func_flow_port_17_0=null;
        Token otherlv_18=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:3416:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function-Flow-Port {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FUNCTION-PROTOTYPE:' ( (lv_func_prototype_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-FLOW-PORT:' ( (lv_func_flow_port_17_0= RULE_STRING ) ) otherlv_18= '}' ) )
            // InternalMyXDsl.g:3417:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function-Flow-Port {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FUNCTION-PROTOTYPE:' ( (lv_func_prototype_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-FLOW-PORT:' ( (lv_func_flow_port_17_0= RULE_STRING ) ) otherlv_18= '}' )
            {
            // InternalMyXDsl.g:3417:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function-Flow-Port {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FUNCTION-PROTOTYPE:' ( (lv_func_prototype_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-FLOW-PORT:' ( (lv_func_flow_port_17_0= RULE_STRING ) ) otherlv_18= '}' )
            // InternalMyXDsl.g:3418:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function-Flow-Port {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FUNCTION-PROTOTYPE:' ( (lv_func_prototype_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-FLOW-PORT:' ( (lv_func_flow_port_17_0= RULE_STRING ) ) otherlv_18= '}'
            {
            // InternalMyXDsl.g:3418:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3419:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3419:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3420:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_41); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEvent_Function_Flow_PortAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,46,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEvent_Function_Flow_PortAccess().getEventFunctionFlowPortKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEvent_Function_Flow_PortAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:3444:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:3445:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3445:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:3446:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEvent_Function_Flow_PortAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEvent_Function_Flow_PortAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:3466:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:3467:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3467:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:3468:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEvent_Function_Flow_PortAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEvent_Function_Flow_PortAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:3488:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:3489:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3489:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:3490:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEvent_Function_Flow_PortAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEvent_Function_Flow_PortAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:3510:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:3511:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3511:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:3512:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_42); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEvent_Function_Flow_PortAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,47,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getEvent_Function_Flow_PortAccess().getFUNCTIONTYPEKeyword_10());
            		
            // InternalMyXDsl.g:3532:3: ( (lv_func_type_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:3533:4: (lv_func_type_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3533:4: (lv_func_type_11_0= RULE_STRING )
            // InternalMyXDsl.g:3534:5: lv_func_type_11_0= RULE_STRING
            {
            lv_func_type_11_0=(Token)match(input,RULE_STRING,FOLLOW_43); 

            					newLeafNode(lv_func_type_11_0, grammarAccess.getEvent_Function_Flow_PortAccess().getFunc_typeSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_type",
            						lv_func_type_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,48,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getEvent_Function_Flow_PortAccess().getFUNCTIONVALUEKeyword_12());
            		
            // InternalMyXDsl.g:3554:3: ( (lv_func_value_13_0= RULE_STRING ) )
            // InternalMyXDsl.g:3555:4: (lv_func_value_13_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3555:4: (lv_func_value_13_0= RULE_STRING )
            // InternalMyXDsl.g:3556:5: lv_func_value_13_0= RULE_STRING
            {
            lv_func_value_13_0=(Token)match(input,RULE_STRING,FOLLOW_44); 

            					newLeafNode(lv_func_value_13_0, grammarAccess.getEvent_Function_Flow_PortAccess().getFunc_valueSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_value",
            						lv_func_value_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_14=(Token)match(input,49,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getEvent_Function_Flow_PortAccess().getFUNCTIONPROTOTYPEKeyword_14());
            		
            // InternalMyXDsl.g:3576:3: ( (lv_func_prototype_15_0= RULE_STRING ) )
            // InternalMyXDsl.g:3577:4: (lv_func_prototype_15_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3577:4: (lv_func_prototype_15_0= RULE_STRING )
            // InternalMyXDsl.g:3578:5: lv_func_prototype_15_0= RULE_STRING
            {
            lv_func_prototype_15_0=(Token)match(input,RULE_STRING,FOLLOW_45); 

            					newLeafNode(lv_func_prototype_15_0, grammarAccess.getEvent_Function_Flow_PortAccess().getFunc_prototypeSTRINGTerminalRuleCall_15_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_prototype",
            						lv_func_prototype_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_16=(Token)match(input,50,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getEvent_Function_Flow_PortAccess().getFUNCTIONFLOWPORTKeyword_16());
            		
            // InternalMyXDsl.g:3598:3: ( (lv_func_flow_port_17_0= RULE_STRING ) )
            // InternalMyXDsl.g:3599:4: (lv_func_flow_port_17_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3599:4: (lv_func_flow_port_17_0= RULE_STRING )
            // InternalMyXDsl.g:3600:5: lv_func_flow_port_17_0= RULE_STRING
            {
            lv_func_flow_port_17_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_func_flow_port_17_0, grammarAccess.getEvent_Function_Flow_PortAccess().getFunc_flow_portSTRINGTerminalRuleCall_17_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_Function_Flow_PortRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_flow_port",
            						lv_func_flow_port_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_18=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getEvent_Function_Flow_PortAccess().getRightCurlyBracketKeyword_18());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent_Function_Flow_Port"


    // $ANTLR start "entryRuleEvent_Function"
    // InternalMyXDsl.g:3624:1: entryRuleEvent_Function returns [EObject current=null] : iv_ruleEvent_Function= ruleEvent_Function EOF ;
    public final EObject entryRuleEvent_Function() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent_Function = null;


        try {
            // InternalMyXDsl.g:3624:55: (iv_ruleEvent_Function= ruleEvent_Function EOF )
            // InternalMyXDsl.g:3625:2: iv_ruleEvent_Function= ruleEvent_Function EOF
            {
             newCompositeNode(grammarAccess.getEvent_FunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent_Function=ruleEvent_Function();

            state._fsp--;

             current =iv_ruleEvent_Function; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent_Function"


    // $ANTLR start "ruleEvent_Function"
    // InternalMyXDsl.g:3631:1: ruleEvent_Function returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FFUNCTION-PROTOTYPE-TARGET:' ( (lv_func_prototype_target_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-PROTOTYPE-CONTEXT:' ( (lv_func_prototype_context_17_0= RULE_STRING ) ) otherlv_18= '}' ) ;
    public final EObject ruleEvent_Function() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_func_type_11_0=null;
        Token otherlv_12=null;
        Token lv_func_value_13_0=null;
        Token otherlv_14=null;
        Token lv_func_prototype_target_15_0=null;
        Token otherlv_16=null;
        Token lv_func_prototype_context_17_0=null;
        Token otherlv_18=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:3637:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FFUNCTION-PROTOTYPE-TARGET:' ( (lv_func_prototype_target_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-PROTOTYPE-CONTEXT:' ( (lv_func_prototype_context_17_0= RULE_STRING ) ) otherlv_18= '}' ) )
            // InternalMyXDsl.g:3638:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FFUNCTION-PROTOTYPE-TARGET:' ( (lv_func_prototype_target_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-PROTOTYPE-CONTEXT:' ( (lv_func_prototype_context_17_0= RULE_STRING ) ) otherlv_18= '}' )
            {
            // InternalMyXDsl.g:3638:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FFUNCTION-PROTOTYPE-TARGET:' ( (lv_func_prototype_target_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-PROTOTYPE-CONTEXT:' ( (lv_func_prototype_context_17_0= RULE_STRING ) ) otherlv_18= '}' )
            // InternalMyXDsl.g:3639:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Event-Function {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'FUNCTION-TYPE:' ( (lv_func_type_11_0= RULE_STRING ) ) otherlv_12= 'FUNCTION-VALUE:' ( (lv_func_value_13_0= RULE_STRING ) ) otherlv_14= 'FFUNCTION-PROTOTYPE-TARGET:' ( (lv_func_prototype_target_15_0= RULE_STRING ) ) otherlv_16= 'FUNCTION-PROTOTYPE-CONTEXT:' ( (lv_func_prototype_context_17_0= RULE_STRING ) ) otherlv_18= '}'
            {
            // InternalMyXDsl.g:3639:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3640:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3640:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3641:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_46); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEvent_FunctionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,51,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEvent_FunctionAccess().getEventFunctionKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEvent_FunctionAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:3665:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:3666:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3666:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:3667:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEvent_FunctionAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEvent_FunctionAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:3687:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:3688:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3688:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:3689:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEvent_FunctionAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEvent_FunctionAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:3709:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:3710:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3710:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:3711:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEvent_FunctionAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEvent_FunctionAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:3731:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:3732:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3732:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:3733:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_42); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEvent_FunctionAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,47,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getEvent_FunctionAccess().getFUNCTIONTYPEKeyword_10());
            		
            // InternalMyXDsl.g:3753:3: ( (lv_func_type_11_0= RULE_STRING ) )
            // InternalMyXDsl.g:3754:4: (lv_func_type_11_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3754:4: (lv_func_type_11_0= RULE_STRING )
            // InternalMyXDsl.g:3755:5: lv_func_type_11_0= RULE_STRING
            {
            lv_func_type_11_0=(Token)match(input,RULE_STRING,FOLLOW_43); 

            					newLeafNode(lv_func_type_11_0, grammarAccess.getEvent_FunctionAccess().getFunc_typeSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_type",
            						lv_func_type_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,48,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getEvent_FunctionAccess().getFUNCTIONVALUEKeyword_12());
            		
            // InternalMyXDsl.g:3775:3: ( (lv_func_value_13_0= RULE_STRING ) )
            // InternalMyXDsl.g:3776:4: (lv_func_value_13_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3776:4: (lv_func_value_13_0= RULE_STRING )
            // InternalMyXDsl.g:3777:5: lv_func_value_13_0= RULE_STRING
            {
            lv_func_value_13_0=(Token)match(input,RULE_STRING,FOLLOW_47); 

            					newLeafNode(lv_func_value_13_0, grammarAccess.getEvent_FunctionAccess().getFunc_valueSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_value",
            						lv_func_value_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_14=(Token)match(input,52,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getEvent_FunctionAccess().getFFUNCTIONPROTOTYPETARGETKeyword_14());
            		
            // InternalMyXDsl.g:3797:3: ( (lv_func_prototype_target_15_0= RULE_STRING ) )
            // InternalMyXDsl.g:3798:4: (lv_func_prototype_target_15_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3798:4: (lv_func_prototype_target_15_0= RULE_STRING )
            // InternalMyXDsl.g:3799:5: lv_func_prototype_target_15_0= RULE_STRING
            {
            lv_func_prototype_target_15_0=(Token)match(input,RULE_STRING,FOLLOW_48); 

            					newLeafNode(lv_func_prototype_target_15_0, grammarAccess.getEvent_FunctionAccess().getFunc_prototype_targetSTRINGTerminalRuleCall_15_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_prototype_target",
            						lv_func_prototype_target_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_16=(Token)match(input,53,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getEvent_FunctionAccess().getFUNCTIONPROTOTYPECONTEXTKeyword_16());
            		
            // InternalMyXDsl.g:3819:3: ( (lv_func_prototype_context_17_0= RULE_STRING ) )
            // InternalMyXDsl.g:3820:4: (lv_func_prototype_context_17_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3820:4: (lv_func_prototype_context_17_0= RULE_STRING )
            // InternalMyXDsl.g:3821:5: lv_func_prototype_context_17_0= RULE_STRING
            {
            lv_func_prototype_context_17_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_func_prototype_context_17_0, grammarAccess.getEvent_FunctionAccess().getFunc_prototype_contextSTRINGTerminalRuleCall_17_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEvent_FunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"func_prototype_context",
            						lv_func_prototype_context_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_18=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getEvent_FunctionAccess().getRightCurlyBracketKeyword_18());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent_Function"


    // $ANTLR start "entryRuleUnit"
    // InternalMyXDsl.g:3845:1: entryRuleUnit returns [EObject current=null] : iv_ruleUnit= ruleUnit EOF ;
    public final EObject entryRuleUnit() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUnit = null;


        try {
            // InternalMyXDsl.g:3845:45: (iv_ruleUnit= ruleUnit EOF )
            // InternalMyXDsl.g:3846:2: iv_ruleUnit= ruleUnit EOF
            {
             newCompositeNode(grammarAccess.getUnitRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUnit=ruleUnit();

            state._fsp--;

             current =iv_ruleUnit; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUnit"


    // $ANTLR start "ruleUnit"
    // InternalMyXDsl.g:3852:1: ruleUnit returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Unit {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )? (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )? (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )? otherlv_16= 'QUNATITY:' ( (lv_quantity_17_0= RULE_STRING ) ) otherlv_18= '}' ) ;
    public final EObject ruleUnit() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_factor_11_0=null;
        Token otherlv_12=null;
        Token lv_symbol_13_0=null;
        Token otherlv_14=null;
        Token lv_offset_15_0=null;
        Token otherlv_16=null;
        Token lv_quantity_17_0=null;
        Token otherlv_18=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:3858:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Unit {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )? (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )? (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )? otherlv_16= 'QUNATITY:' ( (lv_quantity_17_0= RULE_STRING ) ) otherlv_18= '}' ) )
            // InternalMyXDsl.g:3859:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Unit {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )? (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )? (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )? otherlv_16= 'QUNATITY:' ( (lv_quantity_17_0= RULE_STRING ) ) otherlv_18= '}' )
            {
            // InternalMyXDsl.g:3859:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Unit {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )? (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )? (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )? otherlv_16= 'QUNATITY:' ( (lv_quantity_17_0= RULE_STRING ) ) otherlv_18= '}' )
            // InternalMyXDsl.g:3860:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Unit {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )? (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )? (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )? otherlv_16= 'QUNATITY:' ( (lv_quantity_17_0= RULE_STRING ) ) otherlv_18= '}'
            {
            // InternalMyXDsl.g:3860:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:3861:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:3861:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:3862:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_49); 

            					newLeafNode(lv_define_0_0, grammarAccess.getUnitAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,54,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getUnitAccess().getUnitKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getUnitAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:3886:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:3887:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3887:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:3888:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getUnitAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getUnitAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:3908:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:3909:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3909:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:3910:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getUnitAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getUnitAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:3930:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:3931:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3931:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:3932:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getUnitAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getUnitAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:3952:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:3953:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:3953:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:3954:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_50); 

            					newLeafNode(lv_name_9_0, grammarAccess.getUnitAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:3970:3: (otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) ) )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==55) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalMyXDsl.g:3971:4: otherlv_10= 'FACTOR:' ( (lv_factor_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,55,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getUnitAccess().getFACTORKeyword_10_0());
                    			
                    // InternalMyXDsl.g:3975:4: ( (lv_factor_11_0= RULE_STRING ) )
                    // InternalMyXDsl.g:3976:5: (lv_factor_11_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:3976:5: (lv_factor_11_0= RULE_STRING )
                    // InternalMyXDsl.g:3977:6: lv_factor_11_0= RULE_STRING
                    {
                    lv_factor_11_0=(Token)match(input,RULE_STRING,FOLLOW_51); 

                    						newLeafNode(lv_factor_11_0, grammarAccess.getUnitAccess().getFactorSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUnitRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"factor",
                    							lv_factor_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:3994:3: (otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) ) )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==56) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalMyXDsl.g:3995:4: otherlv_12= 'SYMBOL:' ( (lv_symbol_13_0= RULE_STRING ) )
                    {
                    otherlv_12=(Token)match(input,56,FOLLOW_6); 

                    				newLeafNode(otherlv_12, grammarAccess.getUnitAccess().getSYMBOLKeyword_11_0());
                    			
                    // InternalMyXDsl.g:3999:4: ( (lv_symbol_13_0= RULE_STRING ) )
                    // InternalMyXDsl.g:4000:5: (lv_symbol_13_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:4000:5: (lv_symbol_13_0= RULE_STRING )
                    // InternalMyXDsl.g:4001:6: lv_symbol_13_0= RULE_STRING
                    {
                    lv_symbol_13_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

                    						newLeafNode(lv_symbol_13_0, grammarAccess.getUnitAccess().getSymbolSTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUnitRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"symbol",
                    							lv_symbol_13_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4018:3: (otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) ) )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==57) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalMyXDsl.g:4019:4: otherlv_14= 'OFFSET:' ( (lv_offset_15_0= RULE_STRING ) )
                    {
                    otherlv_14=(Token)match(input,57,FOLLOW_6); 

                    				newLeafNode(otherlv_14, grammarAccess.getUnitAccess().getOFFSETKeyword_12_0());
                    			
                    // InternalMyXDsl.g:4023:4: ( (lv_offset_15_0= RULE_STRING ) )
                    // InternalMyXDsl.g:4024:5: (lv_offset_15_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:4024:5: (lv_offset_15_0= RULE_STRING )
                    // InternalMyXDsl.g:4025:6: lv_offset_15_0= RULE_STRING
                    {
                    lv_offset_15_0=(Token)match(input,RULE_STRING,FOLLOW_53); 

                    						newLeafNode(lv_offset_15_0, grammarAccess.getUnitAccess().getOffsetSTRINGTerminalRuleCall_12_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUnitRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"offset",
                    							lv_offset_15_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,58,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getUnitAccess().getQUNATITYKeyword_13());
            		
            // InternalMyXDsl.g:4046:3: ( (lv_quantity_17_0= RULE_STRING ) )
            // InternalMyXDsl.g:4047:4: (lv_quantity_17_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4047:4: (lv_quantity_17_0= RULE_STRING )
            // InternalMyXDsl.g:4048:5: lv_quantity_17_0= RULE_STRING
            {
            lv_quantity_17_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_quantity_17_0, grammarAccess.getUnitAccess().getQuantitySTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUnitRule());
            					}
            					setWithLastConsumed(
            						current,
            						"quantity",
            						lv_quantity_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_18=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getUnitAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUnit"


    // $ANTLR start "entryRuleQuantity"
    // InternalMyXDsl.g:4072:1: entryRuleQuantity returns [EObject current=null] : iv_ruleQuantity= ruleQuantity EOF ;
    public final EObject entryRuleQuantity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQuantity = null;


        try {
            // InternalMyXDsl.g:4072:49: (iv_ruleQuantity= ruleQuantity EOF )
            // InternalMyXDsl.g:4073:2: iv_ruleQuantity= ruleQuantity EOF
            {
             newCompositeNode(grammarAccess.getQuantityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQuantity=ruleQuantity();

            state._fsp--;

             current =iv_ruleQuantity; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQuantity"


    // $ANTLR start "ruleQuantity"
    // InternalMyXDsl.g:4079:1: ruleQuantity returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Quantity {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )? (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )? (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )? (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )? (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )? (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )? (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )? otherlv_24= '}' ) ;
    public final EObject ruleQuantity() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_substance_exp_11_0=null;
        Token otherlv_12=null;
        Token lv_current_exp_13_0=null;
        Token otherlv_14=null;
        Token lv_length_exp_15_0=null;
        Token otherlv_16=null;
        Token lv_intensity_exp_17_0=null;
        Token otherlv_18=null;
        Token lv_mass_exp_19_0=null;
        Token otherlv_20=null;
        Token lv_temp_exp_21_0=null;
        Token otherlv_22=null;
        Token lv_time_exp_23_0=null;
        Token otherlv_24=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:4085:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Quantity {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )? (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )? (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )? (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )? (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )? (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )? (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )? otherlv_24= '}' ) )
            // InternalMyXDsl.g:4086:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Quantity {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )? (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )? (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )? (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )? (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )? (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )? (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )? otherlv_24= '}' )
            {
            // InternalMyXDsl.g:4086:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Quantity {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )? (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )? (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )? (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )? (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )? (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )? (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )? otherlv_24= '}' )
            // InternalMyXDsl.g:4087:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Quantity {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )? (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )? (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )? (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )? (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )? (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )? (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )? otherlv_24= '}'
            {
            // InternalMyXDsl.g:4087:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:4088:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:4088:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:4089:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_define_0_0, grammarAccess.getQuantityAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuantityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,59,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getQuantityAccess().getQuantityKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getQuantityAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:4113:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:4114:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4114:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:4115:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getQuantityAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuantityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getQuantityAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:4135:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:4136:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4136:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:4137:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getQuantityAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuantityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getQuantityAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:4157:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:4158:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4158:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:4159:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getQuantityAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuantityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getQuantityAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:4179:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:4180:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4180:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:4181:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_55); 

            					newLeafNode(lv_name_9_0, grammarAccess.getQuantityAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuantityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:4197:3: (otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==60) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalMyXDsl.g:4198:4: otherlv_10= 'AMOUNT-OF-SUBSTANCE-EXP:' ( (lv_substance_exp_11_0= RULE_INT ) )
                    {
                    otherlv_10=(Token)match(input,60,FOLLOW_56); 

                    				newLeafNode(otherlv_10, grammarAccess.getQuantityAccess().getAMOUNTOFSUBSTANCEEXPKeyword_10_0());
                    			
                    // InternalMyXDsl.g:4202:4: ( (lv_substance_exp_11_0= RULE_INT ) )
                    // InternalMyXDsl.g:4203:5: (lv_substance_exp_11_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4203:5: (lv_substance_exp_11_0= RULE_INT )
                    // InternalMyXDsl.g:4204:6: lv_substance_exp_11_0= RULE_INT
                    {
                    lv_substance_exp_11_0=(Token)match(input,RULE_INT,FOLLOW_57); 

                    						newLeafNode(lv_substance_exp_11_0, grammarAccess.getQuantityAccess().getSubstance_expINTTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"substance_exp",
                    							lv_substance_exp_11_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4221:3: (otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) ) )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==61) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalMyXDsl.g:4222:4: otherlv_12= 'ELECTRIC-CURRENT-EXP:' ( (lv_current_exp_13_0= RULE_INT ) )
                    {
                    otherlv_12=(Token)match(input,61,FOLLOW_56); 

                    				newLeafNode(otherlv_12, grammarAccess.getQuantityAccess().getELECTRICCURRENTEXPKeyword_11_0());
                    			
                    // InternalMyXDsl.g:4226:4: ( (lv_current_exp_13_0= RULE_INT ) )
                    // InternalMyXDsl.g:4227:5: (lv_current_exp_13_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4227:5: (lv_current_exp_13_0= RULE_INT )
                    // InternalMyXDsl.g:4228:6: lv_current_exp_13_0= RULE_INT
                    {
                    lv_current_exp_13_0=(Token)match(input,RULE_INT,FOLLOW_58); 

                    						newLeafNode(lv_current_exp_13_0, grammarAccess.getQuantityAccess().getCurrent_expINTTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"current_exp",
                    							lv_current_exp_13_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4245:3: (otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) ) )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==62) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalMyXDsl.g:4246:4: otherlv_14= 'LENGTH-EXP:' ( (lv_length_exp_15_0= RULE_INT ) )
                    {
                    otherlv_14=(Token)match(input,62,FOLLOW_56); 

                    				newLeafNode(otherlv_14, grammarAccess.getQuantityAccess().getLENGTHEXPKeyword_12_0());
                    			
                    // InternalMyXDsl.g:4250:4: ( (lv_length_exp_15_0= RULE_INT ) )
                    // InternalMyXDsl.g:4251:5: (lv_length_exp_15_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4251:5: (lv_length_exp_15_0= RULE_INT )
                    // InternalMyXDsl.g:4252:6: lv_length_exp_15_0= RULE_INT
                    {
                    lv_length_exp_15_0=(Token)match(input,RULE_INT,FOLLOW_59); 

                    						newLeafNode(lv_length_exp_15_0, grammarAccess.getQuantityAccess().getLength_expINTTerminalRuleCall_12_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"length_exp",
                    							lv_length_exp_15_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4269:3: (otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) ) )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==63) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalMyXDsl.g:4270:4: otherlv_16= 'LUMINOUS-INTENSITY-EXP:' ( (lv_intensity_exp_17_0= RULE_INT ) )
                    {
                    otherlv_16=(Token)match(input,63,FOLLOW_56); 

                    				newLeafNode(otherlv_16, grammarAccess.getQuantityAccess().getLUMINOUSINTENSITYEXPKeyword_13_0());
                    			
                    // InternalMyXDsl.g:4274:4: ( (lv_intensity_exp_17_0= RULE_INT ) )
                    // InternalMyXDsl.g:4275:5: (lv_intensity_exp_17_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4275:5: (lv_intensity_exp_17_0= RULE_INT )
                    // InternalMyXDsl.g:4276:6: lv_intensity_exp_17_0= RULE_INT
                    {
                    lv_intensity_exp_17_0=(Token)match(input,RULE_INT,FOLLOW_60); 

                    						newLeafNode(lv_intensity_exp_17_0, grammarAccess.getQuantityAccess().getIntensity_expINTTerminalRuleCall_13_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"intensity_exp",
                    							lv_intensity_exp_17_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4293:3: (otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) ) )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==64) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalMyXDsl.g:4294:4: otherlv_18= 'MASS-EXP:' ( (lv_mass_exp_19_0= RULE_INT ) )
                    {
                    otherlv_18=(Token)match(input,64,FOLLOW_56); 

                    				newLeafNode(otherlv_18, grammarAccess.getQuantityAccess().getMASSEXPKeyword_14_0());
                    			
                    // InternalMyXDsl.g:4298:4: ( (lv_mass_exp_19_0= RULE_INT ) )
                    // InternalMyXDsl.g:4299:5: (lv_mass_exp_19_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4299:5: (lv_mass_exp_19_0= RULE_INT )
                    // InternalMyXDsl.g:4300:6: lv_mass_exp_19_0= RULE_INT
                    {
                    lv_mass_exp_19_0=(Token)match(input,RULE_INT,FOLLOW_61); 

                    						newLeafNode(lv_mass_exp_19_0, grammarAccess.getQuantityAccess().getMass_expINTTerminalRuleCall_14_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"mass_exp",
                    							lv_mass_exp_19_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4317:3: (otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==65) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalMyXDsl.g:4318:4: otherlv_20= 'THERMODYNAMIC-TEMPERATURE-EXP:' ( (lv_temp_exp_21_0= RULE_INT ) )
                    {
                    otherlv_20=(Token)match(input,65,FOLLOW_56); 

                    				newLeafNode(otherlv_20, grammarAccess.getQuantityAccess().getTHERMODYNAMICTEMPERATUREEXPKeyword_15_0());
                    			
                    // InternalMyXDsl.g:4322:4: ( (lv_temp_exp_21_0= RULE_INT ) )
                    // InternalMyXDsl.g:4323:5: (lv_temp_exp_21_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4323:5: (lv_temp_exp_21_0= RULE_INT )
                    // InternalMyXDsl.g:4324:6: lv_temp_exp_21_0= RULE_INT
                    {
                    lv_temp_exp_21_0=(Token)match(input,RULE_INT,FOLLOW_62); 

                    						newLeafNode(lv_temp_exp_21_0, grammarAccess.getQuantityAccess().getTemp_expINTTerminalRuleCall_15_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"temp_exp",
                    							lv_temp_exp_21_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4341:3: (otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) ) )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==66) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalMyXDsl.g:4342:4: otherlv_22= 'TIME-EXP:' ( (lv_time_exp_23_0= RULE_INT ) )
                    {
                    otherlv_22=(Token)match(input,66,FOLLOW_56); 

                    				newLeafNode(otherlv_22, grammarAccess.getQuantityAccess().getTIMEEXPKeyword_16_0());
                    			
                    // InternalMyXDsl.g:4346:4: ( (lv_time_exp_23_0= RULE_INT ) )
                    // InternalMyXDsl.g:4347:5: (lv_time_exp_23_0= RULE_INT )
                    {
                    // InternalMyXDsl.g:4347:5: (lv_time_exp_23_0= RULE_INT )
                    // InternalMyXDsl.g:4348:6: lv_time_exp_23_0= RULE_INT
                    {
                    lv_time_exp_23_0=(Token)match(input,RULE_INT,FOLLOW_22); 

                    						newLeafNode(lv_time_exp_23_0, grammarAccess.getQuantityAccess().getTime_expINTTerminalRuleCall_16_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQuantityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"time_exp",
                    							lv_time_exp_23_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_24=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_24, grammarAccess.getQuantityAccess().getRightCurlyBracketKeyword_17());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQuantity"


    // $ANTLR start "entryRuleEA_Numerical"
    // InternalMyXDsl.g:4373:1: entryRuleEA_Numerical returns [EObject current=null] : iv_ruleEA_Numerical= ruleEA_Numerical EOF ;
    public final EObject entryRuleEA_Numerical() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEA_Numerical = null;


        try {
            // InternalMyXDsl.g:4373:53: (iv_ruleEA_Numerical= ruleEA_Numerical EOF )
            // InternalMyXDsl.g:4374:2: iv_ruleEA_Numerical= ruleEA_Numerical EOF
            {
             newCompositeNode(grammarAccess.getEA_NumericalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEA_Numerical=ruleEA_Numerical();

            state._fsp--;

             current =iv_ruleEA_Numerical; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEA_Numerical"


    // $ANTLR start "ruleEA_Numerical"
    // InternalMyXDsl.g:4380:1: ruleEA_Numerical returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'EA_Numerical {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )? (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )? (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )? otherlv_16= 'UNIT-OF-DATA:' ( (lv_data_unit_17_0= RULE_STRING ) ) otherlv_18= '}' ) ;
    public final EObject ruleEA_Numerical() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_text_11_0=null;
        Token otherlv_12=null;
        Token lv_max_13_0=null;
        Token otherlv_14=null;
        Token lv_min_15_0=null;
        Token otherlv_16=null;
        Token lv_data_unit_17_0=null;
        Token otherlv_18=null;


        	enterRule();

        try {
            // InternalMyXDsl.g:4386:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'EA_Numerical {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )? (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )? (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )? otherlv_16= 'UNIT-OF-DATA:' ( (lv_data_unit_17_0= RULE_STRING ) ) otherlv_18= '}' ) )
            // InternalMyXDsl.g:4387:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'EA_Numerical {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )? (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )? (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )? otherlv_16= 'UNIT-OF-DATA:' ( (lv_data_unit_17_0= RULE_STRING ) ) otherlv_18= '}' )
            {
            // InternalMyXDsl.g:4387:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'EA_Numerical {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )? (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )? (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )? otherlv_16= 'UNIT-OF-DATA:' ( (lv_data_unit_17_0= RULE_STRING ) ) otherlv_18= '}' )
            // InternalMyXDsl.g:4388:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'EA_Numerical {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )? (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )? (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )? otherlv_16= 'UNIT-OF-DATA:' ( (lv_data_unit_17_0= RULE_STRING ) ) otherlv_18= '}'
            {
            // InternalMyXDsl.g:4388:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalMyXDsl.g:4389:4: (lv_define_0_0= RULE_ID )
            {
            // InternalMyXDsl.g:4389:4: (lv_define_0_0= RULE_ID )
            // InternalMyXDsl.g:4390:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_63); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEA_NumericalAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,67,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEA_NumericalAccess().getEA_NumericalKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEA_NumericalAccess().getUUIDKeyword_2());
            		
            // InternalMyXDsl.g:4414:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalMyXDsl.g:4415:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4415:4: (lv_uuid_3_0= RULE_STRING )
            // InternalMyXDsl.g:4416:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEA_NumericalAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEA_NumericalAccess().getSHORTNAMEKeyword_4());
            		
            // InternalMyXDsl.g:4436:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalMyXDsl.g:4437:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4437:4: (lv_shortname_5_0= RULE_STRING )
            // InternalMyXDsl.g:4438:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEA_NumericalAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEA_NumericalAccess().getCATEGORYKeyword_6());
            		
            // InternalMyXDsl.g:4458:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalMyXDsl.g:4459:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4459:4: (lv_category_7_0= RULE_STRING )
            // InternalMyXDsl.g:4460:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEA_NumericalAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEA_NumericalAccess().getNAMEKeyword_8());
            		
            // InternalMyXDsl.g:4480:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalMyXDsl.g:4481:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4481:4: (lv_name_9_0= RULE_STRING )
            // InternalMyXDsl.g:4482:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_64); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEA_NumericalAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalMyXDsl.g:4498:3: (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==68) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalMyXDsl.g:4499:4: otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,68,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getEA_NumericalAccess().getTEXTKeyword_10_0());
                    			
                    // InternalMyXDsl.g:4503:4: ( (lv_text_11_0= RULE_STRING ) )
                    // InternalMyXDsl.g:4504:5: (lv_text_11_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:4504:5: (lv_text_11_0= RULE_STRING )
                    // InternalMyXDsl.g:4505:6: lv_text_11_0= RULE_STRING
                    {
                    lv_text_11_0=(Token)match(input,RULE_STRING,FOLLOW_65); 

                    						newLeafNode(lv_text_11_0, grammarAccess.getEA_NumericalAccess().getTextSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEA_NumericalRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"text",
                    							lv_text_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4522:3: (otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==69) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalMyXDsl.g:4523:4: otherlv_12= 'MAX:' ( (lv_max_13_0= RULE_STRING ) )
                    {
                    otherlv_12=(Token)match(input,69,FOLLOW_6); 

                    				newLeafNode(otherlv_12, grammarAccess.getEA_NumericalAccess().getMAXKeyword_11_0());
                    			
                    // InternalMyXDsl.g:4527:4: ( (lv_max_13_0= RULE_STRING ) )
                    // InternalMyXDsl.g:4528:5: (lv_max_13_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:4528:5: (lv_max_13_0= RULE_STRING )
                    // InternalMyXDsl.g:4529:6: lv_max_13_0= RULE_STRING
                    {
                    lv_max_13_0=(Token)match(input,RULE_STRING,FOLLOW_66); 

                    						newLeafNode(lv_max_13_0, grammarAccess.getEA_NumericalAccess().getMaxSTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEA_NumericalRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"max",
                    							lv_max_13_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyXDsl.g:4546:3: (otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) ) )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==70) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalMyXDsl.g:4547:4: otherlv_14= 'MIN:' ( (lv_min_15_0= RULE_STRING ) )
                    {
                    otherlv_14=(Token)match(input,70,FOLLOW_6); 

                    				newLeafNode(otherlv_14, grammarAccess.getEA_NumericalAccess().getMINKeyword_12_0());
                    			
                    // InternalMyXDsl.g:4551:4: ( (lv_min_15_0= RULE_STRING ) )
                    // InternalMyXDsl.g:4552:5: (lv_min_15_0= RULE_STRING )
                    {
                    // InternalMyXDsl.g:4552:5: (lv_min_15_0= RULE_STRING )
                    // InternalMyXDsl.g:4553:6: lv_min_15_0= RULE_STRING
                    {
                    lv_min_15_0=(Token)match(input,RULE_STRING,FOLLOW_67); 

                    						newLeafNode(lv_min_15_0, grammarAccess.getEA_NumericalAccess().getMinSTRINGTerminalRuleCall_12_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEA_NumericalRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"min",
                    							lv_min_15_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,71,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getEA_NumericalAccess().getUNITOFDATAKeyword_13());
            		
            // InternalMyXDsl.g:4574:3: ( (lv_data_unit_17_0= RULE_STRING ) )
            // InternalMyXDsl.g:4575:4: (lv_data_unit_17_0= RULE_STRING )
            {
            // InternalMyXDsl.g:4575:4: (lv_data_unit_17_0= RULE_STRING )
            // InternalMyXDsl.g:4576:5: lv_data_unit_17_0= RULE_STRING
            {
            lv_data_unit_17_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            					newLeafNode(lv_data_unit_17_0, grammarAccess.getEA_NumericalAccess().getData_unitSTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_NumericalRule());
            					}
            					setWithLastConsumed(
            						current,
            						"data_unit",
            						lv_data_unit_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_18=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getEA_NumericalAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEA_Numerical"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000210010L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000001C00000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000001800000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000180000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0780000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0700000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0600000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0xF000000000010000L,0x0000000000000007L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0xE000000000010000L,0x0000000000000007L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0xC000000000010000L,0x0000000000000007L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x8000000000010000L,0x0000000000000007L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000010000L,0x0000000000000007L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000010000L,0x0000000000000006L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000010000L,0x0000000000000004L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000000L,0x00000000000000F0L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000000L,0x00000000000000E0L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000000L,0x00000000000000C0L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});

}