import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class integration {
	
	 static Boolean check = false;
	
	public static void main(String[] args) throws Exception {
	       
	       File updated_file = new File("C:\\Users\\mar03\\Desktop\\demo-east-adl\\demo2\\BasicWW3.eaxml");
	        File timing_file = new File("C:\\Users\\mar03\\Documents\\eclispe-xtext\\runtime-EclipseXtext\\Runtime_Variability_v03.zip_expanded\\variability\\src-gen\\Variability.eaxml");
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document updated_doc = builder.parse(updated_file);
	        Document timing_doc = builder.parse(timing_file );
	        String TextNode = readdata(timing_doc);
	       // System.out.println(string);
	        check = printNode(updated_doc.getChildNodes(), "EA-PACKAGE", updated_doc, TextNode);
	        System.out.println("Check is "+ check);
	        if(check == false ) {
	        	findNode(updated_doc.getChildNodes(), "EA-PACKAGE", updated_doc, TextNode);
	        }
	       
	    }

	    public static void findNode(NodeList nList, String string, Document document, String TextNode) {
		// TODO Auto-generated method stub
	    	String extensions = "Extensions";
			int i=0;
			while(i<nList.getLength()){
				Node node = nList.item(i);
				if(node.hasChildNodes()){
					if(node.getChildNodes().getLength()==1) {
						    if(node.getParentNode().getNodeName()==string) {
						    if(node.getNodeName().equalsIgnoreCase("SHORT-NAME")) {
						   // System.out.println("Node Name" + node.getNodeName());
							if(node.getTextContent().contentEquals(extensions)){	
							findSubPackage(node.getParentNode().getChildNodes(), document, TextNode);
    //						node.getParentNode().getParentNode().appendChild(document.createTextNode(TextNode));
//							System.out.println("Node Content" + node.getTextContent());
//							System.out.println("Node Name" + node.getNodeName());
//							System.out.println("Parent Node Name" + node.getParentNode().getNodeName());
//							System.out.println("Grand Parent Node Name" + node.getParentNode().getParentNode().getNodeName());
//							SaveDocument(document);
							break;
							}
							
						    }  }
					}
					}
					 findNode(node.getChildNodes(), string, document, TextNode);
				i++;
				}
	}

		private static void findSubPackage(NodeList nList, Document document, String TextNode) {
			// TODO Auto-generated method stub
	    	String string = "SUB-PACKAGES";
			int i=0;
			while(i<nList.getLength()){
				Node node = nList.item(i);
			//	if(node.hasChildNodes()){
			//		if(node.getChildNodes().getLength()==1) {
						//System.out.println("Node Name" + node.getNodeName());
						    if(node.getNodeName()==string) {
							node.appendChild(document.createTextNode(TextNode));
							System.out.println("Node Content" + node.getTextContent());
							System.out.println("Node Name" + node.getNodeName());
							System.out.println("Parent Node Name" + node.getParentNode().getNodeName());
							System.out.println("Grand Parent Node Name" + node.getParentNode().getParentNode().getNodeName());
							SaveDocument(document);
							break;
							}
							
					//	    }  }
					
		          findSubPackage(node.getChildNodes(), document, TextNode);
				i++;
				}
			
			
		}

		public static Boolean printNode(NodeList nList, String string, Document document, String TextNode) {
			// TODO Auto-generated method stub
		    String variability = "Variability";
			int i=0;
			while(i<nList.getLength()){
				Node node = nList.item(i);
			//	if(node.hasChildNodes()){
			//		if(node.getChildNodes().getLength()==1) {
						if(node.getParentNode().getNodeName()==string) {
							if(node.getNodeName().equalsIgnoreCase("SHORT-NAME")) {
								//System.out.println("Yes =->" + node.getNodeName());
								//System.out.println("Yes =->" + node.getTextContent());
								while(node.getTextContent().contentEquals(variability)) {
									System.out.println("Yes =->" + node.getNodeName());
									System.out.println("Yes =->" + node.getParentNode().getNodeName());
									System.out.println("Yes =->" + node.getParentNode().getParentNode().getNodeName());
									System.out.println("Yes =->" + node.getTextContent());
									node.getParentNode().getParentNode().replaceChild(document.createTextNode(TextNode), node.getParentNode());
									SaveDocument(document);
									check = true;
									break;
								}	
						}
							}
						//} }
				
					 printNode(node.getChildNodes(), string, document, TextNode);
				i++; 
				}
			return check;
			
			
		}

		public static String readdata(Document doc) throws Exception {
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

	        StringWriter writer = new StringWriter();
	        StreamResult result = new StreamResult(writer);
	        DOMSource source = new DOMSource(doc);
	        transformer.transform(source, result);
	        String string=writer.toString();
	        return string;
	        
	    }
	    
	    public static void SaveDocument(Document doc) {
			// TODO Auto-generated method stub
			try {
			DOMSource source = new DOMSource(doc);
			String path = "C:\\Users\\mar03\\Desktop\\demo-east-adl\\demo2\\BasicWW3.eaxml";
			File file = new File(path);
		    Result result = new StreamResult(file);
		    TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			System.out.println("Document Saved Successfully");
			parse();
			
			
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}

		public static void parse() {
		  
			Map<String,String> variableMap = fillMap();
			Path path = Paths.get("C:\\Users\\mar03\\Desktop\\demo-east-adl\\demo2\\BasicWW3.eaxml");
			Stream<String> lines;
			try {
				lines = Files.lines(path,Charset.forName("UTF-8"));
				List<String> replacedLines = lines.map(line -> replaceTag(line,variableMap))
	                    .collect(Collectors.toList());
				Files.write(path, replacedLines, Charset.forName("UTF-8"));
				lines.close();
				System.out.println("Find and replace done");
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		public static Map<String,String> fillMap() {
			Map<String,String> map = new HashMap<String,String>();
			map.put("&lt;", "<");
			map.put("&gt;", ">");
			map.put("&#13;", "");
			return map;
		}
		private static String replaceTag(String str, Map<String,String> map) {
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if (str.contains(entry.getKey())) {
					str = str.replace(entry.getKey(), entry.getValue());
				}
			}
			return str;
		}


}
