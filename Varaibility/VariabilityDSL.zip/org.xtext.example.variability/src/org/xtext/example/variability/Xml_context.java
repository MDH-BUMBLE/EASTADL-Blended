package org.xtext.example.variability;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Xml_context {
	
	public static int size = 43;

	private static ArrayList<String> DisplayNode(NodeList nList, String check, String var, ArrayList<String> arr, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		String slash = "/";
		while(i<nList.getLength()){
			Node node = nList.item(i);
			if(node.hasChildNodes()) {	
				if(node.getChildNodes().getLength()==1) {
					if(node.getNodeName()=="SHORT-NAME") {
						var = var.concat(slash);
						var = var.concat(node.getTextContent());
						if(node.getParentNode().getNodeName()==check) { 
						arr.add(var); 	
					}		}	}
				
				DisplayNode(node.getChildNodes(),check, var,arr, doc);
				}   i++;  }
		return arr;
	}

	public static ArrayList<ArrayList<String>> parse() {
		// TODO Auto-generated method stub
	  String path = "C://Users//mar03//Desktop//demo-east-adl//demo1//BasicWW3.eaxml";
	  File file = new File(path);
      Document doc;
      String var = "";
      ArrayList<String> feature_model = new ArrayList<String>();
      ArrayList<String> feature = new ArrayList<String>();
      ArrayList<String> vehicle_feature = new ArrayList<String>();
      ArrayList<String> ea_numerical = new ArrayList<String>();
      ArrayList<String> rangeabl_value_type = new ArrayList<String>();
      ArrayList<String> ea_boolean = new ArrayList<String>();
      ArrayList<String> variable_element = new ArrayList<String>();
      ArrayList<String> function_allocation = new ArrayList<String>();
      ArrayList<String> allocation = new ArrayList<String>();
      ArrayList<String> behavior = new ArrayList<String>();
      ArrayList<String> event_chain = new ArrayList<String>();
      ArrayList<String> required_binding_time = new ArrayList<String>();
      ArrayList<String> actual_binding_time = new ArrayList<String>();
      ArrayList<String> func_flow_port = new ArrayList<String>();
      ArrayList<String> configurable_container = new ArrayList<String>();
      ArrayList<String> configuration_decision = new ArrayList<String>();
      ArrayList<String> configuration_decision_folder = new ArrayList<String>();
      ArrayList<String> deviation_attribute_set = new ArrayList<String>();
      ArrayList<String> design_func_type = new ArrayList<String>();
      ArrayList<String> design_func_prototype = new ArrayList<String>();
      ArrayList<String> feature_configuration = new ArrayList<String>();
      ArrayList<String> feature_link = new ArrayList<String>();
      ArrayList<String> feature_constraint = new ArrayList<String>();
      ArrayList<String> feature_group = new ArrayList<String>();
      ArrayList<String> delay_constraint = new ArrayList<String>();
      ArrayList<String> event_func_flow_port = new ArrayList<String>();
      ArrayList<String> func_behavior = new ArrayList<String>();
      ArrayList<String> hardware_component_prototype = new ArrayList<String>();
      ArrayList<String> function_connector = new ArrayList<String>();
      ArrayList<String> execution_time_constraint = new ArrayList<String>();
      ArrayList<String> periodic_constraint = new ArrayList<String>();
      ArrayList<String> event_func = new ArrayList<String>();
      ArrayList<String> hardware_func_type = new ArrayList<String>();
      ArrayList<String> vv_target = new ArrayList<String>();
      ArrayList<String> vehicle_level_binding = new ArrayList<String>();
      ArrayList<String> variation_group = new ArrayList<String>();
      ArrayList<String> variability = new ArrayList<String>();
      ArrayList<String> timing = new ArrayList<String>();
      ArrayList<String> quantity = new ArrayList<String>();
      ArrayList<String> unit = new ArrayList<String>();
      ArrayList<String> age_constraint = new ArrayList<String>();
      ArrayList<String> func_client_server_interface = new ArrayList<String>();
      ArrayList<String> reuse_meta_info = new ArrayList<String>();
      ArrayList<String> array = new ArrayList<String>();
      ArrayList<ArrayList<String> > arr =   new ArrayList<ArrayList<String> >(size);
      
      arr.add(0, feature_model);
      arr.add(1, feature);
      arr.add(2, vehicle_feature);
      arr.add(3, ea_numerical);
      arr.add(4, rangeabl_value_type);
      arr.add(5, ea_boolean);
      arr.add(6, variable_element);
      arr.add(7, function_allocation);
      arr.add(8, allocation);
      arr.add(9, behavior);
      arr.add(10, event_chain);
      arr.add(11, required_binding_time);
      arr.add(12, actual_binding_time);
      arr.add(13, func_flow_port);
      arr.add(14, configurable_container);
      arr.add(15, configuration_decision);
      arr.add(16, configuration_decision_folder);
      arr.add(17, deviation_attribute_set);
      arr.add(18, design_func_type);
      arr.add(19, design_func_prototype);
      arr.add(20, feature_configuration);
      arr.add(21, feature_link);
      arr.add(22, feature_constraint);
      arr.add(23, feature_group);
      arr.add(24, delay_constraint);
      arr.add(25, event_func_flow_port);
      arr.add(26, func_behavior);
      arr.add(27, hardware_component_prototype);
      arr.add(28, function_connector);
      arr.add(29, execution_time_constraint);
      arr.add(30, periodic_constraint);
      arr.add(31, event_func);
      arr.add(32, hardware_func_type);
      arr.add(33, vv_target);
      arr.add(34, vehicle_level_binding);
      arr.add(35, variation_group);
      arr.add(36, variability);
      arr.add(37, timing);
      arr.add(38, quantity);
      arr.add(39, unit);
      arr.add(40, age_constraint); 
      arr.add(41, func_client_server_interface);
      arr.add(42, reuse_meta_info);
     String value = "";
     String[] checklist = {"FEATURE-MODEL", "FEATURE", "VEHICLE-FEATURE", "EA-NUMERICAL", "RANGEABLE-VALUE-TYPE", "EA-BOOLEAN", "VARIABLE-ELEMENT", "FUNCTION-ALLOCATION",
    		 "ALLOCATION", "BEHAVIOR", "EVENT-CHAIN", "REQUIRED-BINDING-TIME", "ACTUAL-BINDING-TIME", "FUNCTION-FLOW-PORT", "CONFIGURABLE-CONTAINER",
    		 "CONFIGURATION-DECISION", "CONFIGURATION-DECISION-FOLDER", "DEVIATION-ATTRIBUTE-SET", "DESIGN-FUNCTION-TYPE", "DESIGN-FUNCTION-PROTOTYPE", "FEATURE-CONFIGURATION",
    		 "FEATURE-LINK", "FEATURE-CONSTRAINT", "FEATURE-GROUP", "DELAY-CONSTRAINT", "EVENT-FUNCTION-FLOW-PORT", "FUNCTION-BEHAVIOR", "HARDWARE-COMPONENT-PROTOTYPE",
    		 "FUNCTION-CONNECTOR", "EXECUTION-TIME-CONSTRAINT", "PERIODIC-CONSTRAINT", "EVENT-FUNCTION", "HARDWARE-FUNCTION-TYPE", "VV-TARGET", 
    		 "VEHICLE-LEVEL-BINDING", "VARIATION-GROUP", "VARIABILITY", "TIMING", "QUANTITY", "UNIT", "AGE-CONSTRAINT", "FUNCTION-CLIENT-SERVER-INTERFACE", "REUSE-META-INFORMATION"};
      
      DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
      try {
		DocumentBuilder dbBuilder = dbfactory.newDocumentBuilder();
		doc = dbBuilder.parse(file);
		doc.getDocumentElement().normalize();
		
	    for (int i = 0; i < arr.size(); i++) {
	    	array = DisplayNode(doc.getChildNodes(), checklist[i] ,var, arr.get(i), doc);
	    	arr.set(i, array);
		    }
	   /* for (int j = 0; j < design_func_prototype.size(); j++) {
				  System.out.println("array item "+design_func_prototype.get(j));
				} */
	    
	 	for (int i = 0; i < arr.size(); i++) {
	 		System.out.println("Array Begins");
	 		System.out.println("Checklist Item:" + checklist[i]);
			for (int j = 0; j < arr.get(i).size(); j++) {
			
			 System.out.println("array item "+arr.get(i).get(j));
			}  }
		
      } catch (ParserConfigurationException e) {
  		// TODO Auto-generated catch block
  		e.printStackTrace();
  	} catch (SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return arr;
	}

}
