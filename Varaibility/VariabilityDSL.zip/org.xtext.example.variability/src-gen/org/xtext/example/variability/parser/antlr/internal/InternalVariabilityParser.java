package org.xtext.example.variability.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.variability.services.VariabilityGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalVariabilityParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Top-Package {'", "'UUID:'", "'SHORT-NAME:'", "'CATEGORY:'", "'NAME:'", "'}'", "'Sub-Package {'", "'Package {'", "'Element {'", "'Variability {'", "'TRACEABLE-SPECIFICATION-REFS:'", "'Feature-Configuration {'", "'CONFIGURED FEATURE MODEL:'", "'Entry {'", "'Configuration-Decision-Folder {'", "'IS-ACTIVE:'", "'Configuration-Decision {'", "'IS-EQUIVALENCE:'", "'EFFECT:'", "'CRITERION:'", "'TARGET:'", "'Selection-Criteria {'", "'TYPE:'", "'SOURCE:'", "'Vehicle-Level-Binding {'", "'SOURCE-VEHICLE-FEATURE-MODEL:'", "'TARGET-FEATURE-MODEL:'", "'Feature-Model {'", "'Root-Feature {'", "'Feature {'", "'CARDINALITY:'", "'Required-Binding-Time {'", "'KIND:'", "'Actual-Binding-Time {'", "'Child-Node {'", "'Vehicle-Feature {'", "'IS-REMOVED:'", "'IS-CUSTOMER-VISIBLE:'", "'IS-DESIGN-VARIABILITY-RATIONALE:'", "'Deviation-Attribute-Set {'", "'ALLOW-REMOVAL:'", "'ALLOW-REGROUPING:'", "'ALLOW-REFINEMENT:'", "'ALLOW-REDUCTION:'", "'ALLOW-MOVE:'", "'ALLOW-CHANGE-NAME:'", "'ALLOW-CHANGE-DESCRIPTION:'", "'ALLOW-CHANGE-CARDINALITY:'", "'ALLOW-CHANGE-ATTRIBUTE:'", "'Feature-Group {'", "'Feature-Link {'", "'IS-BIDIRECTIONAL:'", "'CUSTOM-TYPE:'", "'START:'", "'END:'", "'Feature-Constraint {'", "'Variable-Element {'", "'OPTIONAL ELEMENT:'", "'Reuse-Meta-Information {'", "'TEXT:'", "'INFORMATION:'", "'IS-REUSEABLE:'", "'Configurable-Container {'", "'CONFIGURABLE-ELEMENT:'", "'Internal-Binding {'", "'Private-Content {'", "'PRIVATE-ELEMENT:'", "'Variation-Group {'", "'CONSTRAINT:'", "'VARIABLE-ELEMENT:'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__77=77;
    public static final int T__34=34;
    public static final int T__78=78;
    public static final int T__35=35;
    public static final int T__79=79;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalVariabilityParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalVariabilityParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalVariabilityParser.tokenNames; }
    public String getGrammarFileName() { return "InternalVariability.g"; }



     	private VariabilityGrammarAccess grammarAccess;

        public InternalVariabilityParser(TokenStream input, VariabilityGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected VariabilityGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalVariability.g:64:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalVariability.g:64:45: (iv_ruleFile= ruleFile EOF )
            // InternalVariability.g:65:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalVariability.g:71:1: ruleFile returns [EObject current=null] : ( (lv_ea_package_0_0= ruleEA_Package ) )* ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_ea_package_0_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:77:2: ( ( (lv_ea_package_0_0= ruleEA_Package ) )* )
            // InternalVariability.g:78:2: ( (lv_ea_package_0_0= ruleEA_Package ) )*
            {
            // InternalVariability.g:78:2: ( (lv_ea_package_0_0= ruleEA_Package ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_ID) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalVariability.g:79:3: (lv_ea_package_0_0= ruleEA_Package )
            	    {
            	    // InternalVariability.g:79:3: (lv_ea_package_0_0= ruleEA_Package )
            	    // InternalVariability.g:80:4: lv_ea_package_0_0= ruleEA_Package
            	    {

            	    				newCompositeNode(grammarAccess.getFileAccess().getEa_packageEA_PackageParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_ea_package_0_0=ruleEA_Package();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getFileRule());
            	    				}
            	    				add(
            	    					current,
            	    					"ea_package",
            	    					lv_ea_package_0_0,
            	    					"org.xtext.example.variability.Variability.EA_Package");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleEA_Package"
    // InternalVariability.g:100:1: entryRuleEA_Package returns [EObject current=null] : iv_ruleEA_Package= ruleEA_Package EOF ;
    public final EObject entryRuleEA_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEA_Package = null;


        try {
            // InternalVariability.g:100:51: (iv_ruleEA_Package= ruleEA_Package EOF )
            // InternalVariability.g:101:2: iv_ruleEA_Package= ruleEA_Package EOF
            {
             newCompositeNode(grammarAccess.getEA_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEA_Package=ruleEA_Package();

            state._fsp--;

             current =iv_ruleEA_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEA_Package"


    // $ANTLR start "ruleEA_Package"
    // InternalVariability.g:107:1: ruleEA_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' ) ;
    public final EObject ruleEA_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_12=null;
        EObject lv_subpackages_10_0 = null;

        EObject lv_elements_11_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:113:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' ) )
            // InternalVariability.g:114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' )
            {
            // InternalVariability.g:114:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}' )
            // InternalVariability.g:115:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Top-Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_elements_11_0= ruleElements ) )* otherlv_12= '}'
            {
            // InternalVariability.g:115:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:116:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:116:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:117:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEA_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,11,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getEA_PackageAccess().getTopPackageKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getEA_PackageAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:141:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:142:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:142:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:143:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getEA_PackageAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getEA_PackageAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:163:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:164:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:164:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:165:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getEA_PackageAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getEA_PackageAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:185:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:186:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:186:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:187:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getEA_PackageAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getEA_PackageAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:207:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:208:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:208:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:209:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_name_9_0, grammarAccess.getEA_PackageAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEA_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:225:3: ( (lv_subpackages_10_0= ruleSub_Package ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_ID) ) {
                    int LA2_1 = input.LA(2);

                    if ( (LA2_1==17) ) {
                        alt2=1;
                    }


                }


                switch (alt2) {
            	case 1 :
            	    // InternalVariability.g:226:4: (lv_subpackages_10_0= ruleSub_Package )
            	    {
            	    // InternalVariability.g:226:4: (lv_subpackages_10_0= ruleSub_Package )
            	    // InternalVariability.g:227:5: lv_subpackages_10_0= ruleSub_Package
            	    {

            	    					newCompositeNode(grammarAccess.getEA_PackageAccess().getSubpackagesSub_PackageParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_subpackages_10_0=ruleSub_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEA_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subpackages",
            	    						lv_subpackages_10_0,
            	    						"org.xtext.example.variability.Variability.Sub_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalVariability.g:244:3: ( (lv_elements_11_0= ruleElements ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalVariability.g:245:4: (lv_elements_11_0= ruleElements )
            	    {
            	    // InternalVariability.g:245:4: (lv_elements_11_0= ruleElements )
            	    // InternalVariability.g:246:5: lv_elements_11_0= ruleElements
            	    {

            	    					newCompositeNode(grammarAccess.getEA_PackageAccess().getElementsElementsParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_elements_11_0=ruleElements();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEA_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"elements",
            	    						lv_elements_11_0,
            	    						"org.xtext.example.variability.Variability.Elements");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getEA_PackageAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEA_Package"


    // $ANTLR start "entryRuleSub_Package"
    // InternalVariability.g:271:1: entryRuleSub_Package returns [EObject current=null] : iv_ruleSub_Package= ruleSub_Package EOF ;
    public final EObject entryRuleSub_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSub_Package = null;


        try {
            // InternalVariability.g:271:52: (iv_ruleSub_Package= ruleSub_Package EOF )
            // InternalVariability.g:272:2: iv_ruleSub_Package= ruleSub_Package EOF
            {
             newCompositeNode(grammarAccess.getSub_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSub_Package=ruleSub_Package();

            state._fsp--;

             current =iv_ruleSub_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSub_Package"


    // $ANTLR start "ruleSub_Package"
    // InternalVariability.g:278:1: ruleSub_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' ) ;
    public final EObject ruleSub_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_nested_package_2_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:284:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' ) )
            // InternalVariability.g:285:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' )
            {
            // InternalVariability.g:285:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}' )
            // InternalVariability.g:286:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Sub-Package {' ( (lv_nested_package_2_0= ruleNested_Package ) )* otherlv_3= '}'
            {
            // InternalVariability.g:286:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:287:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:287:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:288:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_define_0_0, grammarAccess.getSub_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSub_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,17,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getSub_PackageAccess().getSubPackageKeyword_1());
            		
            // InternalVariability.g:308:3: ( (lv_nested_package_2_0= ruleNested_Package ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalVariability.g:309:4: (lv_nested_package_2_0= ruleNested_Package )
            	    {
            	    // InternalVariability.g:309:4: (lv_nested_package_2_0= ruleNested_Package )
            	    // InternalVariability.g:310:5: lv_nested_package_2_0= ruleNested_Package
            	    {

            	    					newCompositeNode(grammarAccess.getSub_PackageAccess().getNested_packageNested_PackageParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_nested_package_2_0=ruleNested_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSub_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"nested_package",
            	    						lv_nested_package_2_0,
            	    						"org.xtext.example.variability.Variability.Nested_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_3=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getSub_PackageAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSub_Package"


    // $ANTLR start "entryRuleNested_Package"
    // InternalVariability.g:335:1: entryRuleNested_Package returns [EObject current=null] : iv_ruleNested_Package= ruleNested_Package EOF ;
    public final EObject entryRuleNested_Package() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNested_Package = null;


        try {
            // InternalVariability.g:335:55: (iv_ruleNested_Package= ruleNested_Package EOF )
            // InternalVariability.g:336:2: iv_ruleNested_Package= ruleNested_Package EOF
            {
             newCompositeNode(grammarAccess.getNested_PackageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNested_Package=ruleNested_Package();

            state._fsp--;

             current =iv_ruleNested_Package; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNested_Package"


    // $ANTLR start "ruleNested_Package"
    // InternalVariability.g:342:1: ruleNested_Package returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' ) ;
    public final EObject ruleNested_Package() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_12=null;
        EObject lv_subpackages_10_0 = null;

        EObject lv_element_11_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:348:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' ) )
            // InternalVariability.g:349:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' )
            {
            // InternalVariability.g:349:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}' )
            // InternalVariability.g:350:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Package {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_subpackages_10_0= ruleSub_Package ) )* ( (lv_element_11_0= ruleElement ) )* otherlv_12= '}'
            {
            // InternalVariability.g:350:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:351:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:351:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:352:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(lv_define_0_0, grammarAccess.getNested_PackageAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,18,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getNested_PackageAccess().getPackageKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getNested_PackageAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:376:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:377:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:377:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:378:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getNested_PackageAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getNested_PackageAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:398:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:399:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:399:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:400:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getNested_PackageAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getNested_PackageAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:420:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:421:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:421:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:422:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getNested_PackageAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getNested_PackageAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:442:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:443:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:443:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:444:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_name_9_0, grammarAccess.getNested_PackageAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getNested_PackageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:460:3: ( (lv_subpackages_10_0= ruleSub_Package ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID) ) {
                    int LA5_1 = input.LA(2);

                    if ( (LA5_1==17) ) {
                        alt5=1;
                    }


                }


                switch (alt5) {
            	case 1 :
            	    // InternalVariability.g:461:4: (lv_subpackages_10_0= ruleSub_Package )
            	    {
            	    // InternalVariability.g:461:4: (lv_subpackages_10_0= ruleSub_Package )
            	    // InternalVariability.g:462:5: lv_subpackages_10_0= ruleSub_Package
            	    {

            	    					newCompositeNode(grammarAccess.getNested_PackageAccess().getSubpackagesSub_PackageParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_subpackages_10_0=ruleSub_Package();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNested_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subpackages",
            	    						lv_subpackages_10_0,
            	    						"org.xtext.example.variability.Variability.Sub_Package");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalVariability.g:479:3: ( (lv_element_11_0= ruleElement ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalVariability.g:480:4: (lv_element_11_0= ruleElement )
            	    {
            	    // InternalVariability.g:480:4: (lv_element_11_0= ruleElement )
            	    // InternalVariability.g:481:5: lv_element_11_0= ruleElement
            	    {

            	    					newCompositeNode(grammarAccess.getNested_PackageAccess().getElementElementParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_element_11_0=ruleElement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNested_PackageRule());
            	    					}
            	    					add(
            	    						current,
            	    						"element",
            	    						lv_element_11_0,
            	    						"org.xtext.example.variability.Variability.Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getNested_PackageAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNested_Package"


    // $ANTLR start "entryRuleElement"
    // InternalVariability.g:506:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // InternalVariability.g:506:48: (iv_ruleElement= ruleElement EOF )
            // InternalVariability.g:507:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // InternalVariability.g:513:1: ruleElement returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_variability_2_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:519:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' ) )
            // InternalVariability.g:520:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' )
            {
            // InternalVariability.g:520:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' )
            // InternalVariability.g:521:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}'
            {
            // InternalVariability.g:521:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:522:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:522:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:523:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_define_0_0, grammarAccess.getElementAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,19,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getElementAccess().getElementKeyword_1());
            		
            // InternalVariability.g:543:3: ( (lv_variability_2_0= ruleVariability ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalVariability.g:544:4: (lv_variability_2_0= ruleVariability )
            	    {
            	    // InternalVariability.g:544:4: (lv_variability_2_0= ruleVariability )
            	    // InternalVariability.g:545:5: lv_variability_2_0= ruleVariability
            	    {

            	    					newCompositeNode(grammarAccess.getElementAccess().getVariabilityVariabilityParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_variability_2_0=ruleVariability();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementRule());
            	    					}
            	    					add(
            	    						current,
            	    						"variability",
            	    						lv_variability_2_0,
            	    						"org.xtext.example.variability.Variability.Variability");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_3=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getElementAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleElements"
    // InternalVariability.g:570:1: entryRuleElements returns [EObject current=null] : iv_ruleElements= ruleElements EOF ;
    public final EObject entryRuleElements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElements = null;


        try {
            // InternalVariability.g:570:49: (iv_ruleElements= ruleElements EOF )
            // InternalVariability.g:571:2: iv_ruleElements= ruleElements EOF
            {
             newCompositeNode(grammarAccess.getElementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElements=ruleElements();

            state._fsp--;

             current =iv_ruleElements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElements"


    // $ANTLR start "ruleElements"
    // InternalVariability.g:577:1: ruleElements returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' ) ;
    public final EObject ruleElements() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_variability_2_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:583:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' ) )
            // InternalVariability.g:584:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' )
            {
            // InternalVariability.g:584:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}' )
            // InternalVariability.g:585:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Element {' ( (lv_variability_2_0= ruleVariability ) )* otherlv_3= '}'
            {
            // InternalVariability.g:585:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:586:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:586:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:587:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_define_0_0, grammarAccess.getElementsAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getElementsRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,19,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getElementsAccess().getElementKeyword_1());
            		
            // InternalVariability.g:607:3: ( (lv_variability_2_0= ruleVariability ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalVariability.g:608:4: (lv_variability_2_0= ruleVariability )
            	    {
            	    // InternalVariability.g:608:4: (lv_variability_2_0= ruleVariability )
            	    // InternalVariability.g:609:5: lv_variability_2_0= ruleVariability
            	    {

            	    					newCompositeNode(grammarAccess.getElementsAccess().getVariabilityVariabilityParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_variability_2_0=ruleVariability();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getElementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"variability",
            	    						lv_variability_2_0,
            	    						"org.xtext.example.variability.Variability.Variability");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            otherlv_3=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getElementsAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElements"


    // $ANTLR start "entryRuleVariability"
    // InternalVariability.g:634:1: entryRuleVariability returns [EObject current=null] : iv_ruleVariability= ruleVariability EOF ;
    public final EObject entryRuleVariability() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariability = null;


        try {
            // InternalVariability.g:634:52: (iv_ruleVariability= ruleVariability EOF )
            // InternalVariability.g:635:2: iv_ruleVariability= ruleVariability EOF
            {
             newCompositeNode(grammarAccess.getVariabilityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariability=ruleVariability();

            state._fsp--;

             current =iv_ruleVariability; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariability"


    // $ANTLR start "ruleVariability"
    // InternalVariability.g:641:1: ruleVariability returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variability {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )* ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )* ( (lv_feature_model_14_0= ruleFeature_Model ) )* ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )* ( (lv_variable_element_16_0= ruleVariable_Element ) )* otherlv_17= '}' ) ;
    public final EObject ruleVariability() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_17=null;
        EObject lv_feature_configuration_12_0 = null;

        EObject lv_vehicle_level_binding_13_0 = null;

        EObject lv_feature_model_14_0 = null;

        EObject lv_configurable_container_15_0 = null;

        EObject lv_variable_element_16_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:647:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variability {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )* ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )* ( (lv_feature_model_14_0= ruleFeature_Model ) )* ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )* ( (lv_variable_element_16_0= ruleVariable_Element ) )* otherlv_17= '}' ) )
            // InternalVariability.g:648:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variability {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )* ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )* ( (lv_feature_model_14_0= ruleFeature_Model ) )* ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )* ( (lv_variable_element_16_0= ruleVariable_Element ) )* otherlv_17= '}' )
            {
            // InternalVariability.g:648:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variability {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )* ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )* ( (lv_feature_model_14_0= ruleFeature_Model ) )* ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )* ( (lv_variable_element_16_0= ruleVariable_Element ) )* otherlv_17= '}' )
            // InternalVariability.g:649:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variability {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )? ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )* ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )* ( (lv_feature_model_14_0= ruleFeature_Model ) )* ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )* ( (lv_variable_element_16_0= ruleVariable_Element ) )* otherlv_17= '}'
            {
            // InternalVariability.g:649:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:650:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:650:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:651:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_define_0_0, grammarAccess.getVariabilityAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariabilityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,20,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getVariabilityAccess().getVariabilityKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getVariabilityAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:675:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:676:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:676:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:677:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getVariabilityAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariabilityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getVariabilityAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:697:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:698:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:698:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:699:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getVariabilityAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariabilityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVariabilityAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:719:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:720:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:720:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:721:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getVariabilityAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariabilityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getVariabilityAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:741:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:742:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:742:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:743:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_15); 

            					newLeafNode(lv_name_9_0, grammarAccess.getVariabilityAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariabilityRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:759:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalVariability.g:760:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,21,FOLLOW_6); 

                    				newLeafNode(otherlv_10, grammarAccess.getVariabilityAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
                    			
                    // InternalVariability.g:764:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
                    // InternalVariability.g:765:5: (lv_traceable_specification_11_0= RULE_STRING )
                    {
                    // InternalVariability.g:765:5: (lv_traceable_specification_11_0= RULE_STRING )
                    // InternalVariability.g:766:6: lv_traceable_specification_11_0= RULE_STRING
                    {
                    lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getVariabilityAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVariabilityRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"traceable_specification",
                    							lv_traceable_specification_11_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalVariability.g:783:3: ( (lv_feature_configuration_12_0= ruleFeature_Configuration ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==RULE_ID) ) {
                    int LA10_1 = input.LA(2);

                    if ( (LA10_1==22) ) {
                        alt10=1;
                    }


                }


                switch (alt10) {
            	case 1 :
            	    // InternalVariability.g:784:4: (lv_feature_configuration_12_0= ruleFeature_Configuration )
            	    {
            	    // InternalVariability.g:784:4: (lv_feature_configuration_12_0= ruleFeature_Configuration )
            	    // InternalVariability.g:785:5: lv_feature_configuration_12_0= ruleFeature_Configuration
            	    {

            	    					newCompositeNode(grammarAccess.getVariabilityAccess().getFeature_configurationFeature_ConfigurationParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_configuration_12_0=ruleFeature_Configuration();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVariabilityRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature_configuration",
            	    						lv_feature_configuration_12_0,
            	    						"org.xtext.example.variability.Variability.Feature_Configuration");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            // InternalVariability.g:802:3: ( (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    int LA11_1 = input.LA(2);

                    if ( (LA11_1==35) ) {
                        alt11=1;
                    }


                }


                switch (alt11) {
            	case 1 :
            	    // InternalVariability.g:803:4: (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding )
            	    {
            	    // InternalVariability.g:803:4: (lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding )
            	    // InternalVariability.g:804:5: lv_vehicle_level_binding_13_0= ruleVehicle_Level_Binding
            	    {

            	    					newCompositeNode(grammarAccess.getVariabilityAccess().getVehicle_level_bindingVehicle_Level_BindingParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_vehicle_level_binding_13_0=ruleVehicle_Level_Binding();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVariabilityRule());
            	    					}
            	    					add(
            	    						current,
            	    						"vehicle_level_binding",
            	    						lv_vehicle_level_binding_13_0,
            	    						"org.xtext.example.variability.Variability.Vehicle_Level_Binding");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            // InternalVariability.g:821:3: ( (lv_feature_model_14_0= ruleFeature_Model ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_ID) ) {
                    int LA12_1 = input.LA(2);

                    if ( (LA12_1==38) ) {
                        alt12=1;
                    }


                }


                switch (alt12) {
            	case 1 :
            	    // InternalVariability.g:822:4: (lv_feature_model_14_0= ruleFeature_Model )
            	    {
            	    // InternalVariability.g:822:4: (lv_feature_model_14_0= ruleFeature_Model )
            	    // InternalVariability.g:823:5: lv_feature_model_14_0= ruleFeature_Model
            	    {

            	    					newCompositeNode(grammarAccess.getVariabilityAccess().getFeature_modelFeature_ModelParserRuleCall_13_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_model_14_0=ruleFeature_Model();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVariabilityRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature_model",
            	    						lv_feature_model_14_0,
            	    						"org.xtext.example.variability.Variability.Feature_Model");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            // InternalVariability.g:840:3: ( (lv_configurable_container_15_0= ruleConfigurable_Container ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==RULE_ID) ) {
                    int LA13_1 = input.LA(2);

                    if ( (LA13_1==73) ) {
                        alt13=1;
                    }


                }


                switch (alt13) {
            	case 1 :
            	    // InternalVariability.g:841:4: (lv_configurable_container_15_0= ruleConfigurable_Container )
            	    {
            	    // InternalVariability.g:841:4: (lv_configurable_container_15_0= ruleConfigurable_Container )
            	    // InternalVariability.g:842:5: lv_configurable_container_15_0= ruleConfigurable_Container
            	    {

            	    					newCompositeNode(grammarAccess.getVariabilityAccess().getConfigurable_containerConfigurable_ContainerParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_configurable_container_15_0=ruleConfigurable_Container();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVariabilityRule());
            	    					}
            	    					add(
            	    						current,
            	    						"configurable_container",
            	    						lv_configurable_container_15_0,
            	    						"org.xtext.example.variability.Variability.Configurable_Container");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalVariability.g:859:3: ( (lv_variable_element_16_0= ruleVariable_Element ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==RULE_ID) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalVariability.g:860:4: (lv_variable_element_16_0= ruleVariable_Element )
            	    {
            	    // InternalVariability.g:860:4: (lv_variable_element_16_0= ruleVariable_Element )
            	    // InternalVariability.g:861:5: lv_variable_element_16_0= ruleVariable_Element
            	    {

            	    					newCompositeNode(grammarAccess.getVariabilityAccess().getVariable_elementVariable_ElementParserRuleCall_15_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_variable_element_16_0=ruleVariable_Element();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVariabilityRule());
            	    					}
            	    					add(
            	    						current,
            	    						"variable_element",
            	    						lv_variable_element_16_0,
            	    						"org.xtext.example.variability.Variability.Variable_Element");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            otherlv_17=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getVariabilityAccess().getRightCurlyBracketKeyword_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariability"


    // $ANTLR start "entryRuleFeature_Configuration"
    // InternalVariability.g:886:1: entryRuleFeature_Configuration returns [EObject current=null] : iv_ruleFeature_Configuration= ruleFeature_Configuration EOF ;
    public final EObject entryRuleFeature_Configuration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature_Configuration = null;


        try {
            // InternalVariability.g:886:62: (iv_ruleFeature_Configuration= ruleFeature_Configuration EOF )
            // InternalVariability.g:887:2: iv_ruleFeature_Configuration= ruleFeature_Configuration EOF
            {
             newCompositeNode(grammarAccess.getFeature_ConfigurationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature_Configuration=ruleFeature_Configuration();

            state._fsp--;

             current =iv_ruleFeature_Configuration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature_Configuration"


    // $ANTLR start "ruleFeature_Configuration"
    // InternalVariability.g:893:1: ruleFeature_Configuration returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Configuration {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURED FEATURE MODEL:' ( (lv_configured_feature_model_11_0= RULE_STRING ) ) ( (lv_root_entry_12_0= ruleEntry ) )* otherlv_13= '}' ) ;
    public final EObject ruleFeature_Configuration() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_configured_feature_model_11_0=null;
        Token otherlv_13=null;
        EObject lv_root_entry_12_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:899:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Configuration {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURED FEATURE MODEL:' ( (lv_configured_feature_model_11_0= RULE_STRING ) ) ( (lv_root_entry_12_0= ruleEntry ) )* otherlv_13= '}' ) )
            // InternalVariability.g:900:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Configuration {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURED FEATURE MODEL:' ( (lv_configured_feature_model_11_0= RULE_STRING ) ) ( (lv_root_entry_12_0= ruleEntry ) )* otherlv_13= '}' )
            {
            // InternalVariability.g:900:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Configuration {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURED FEATURE MODEL:' ( (lv_configured_feature_model_11_0= RULE_STRING ) ) ( (lv_root_entry_12_0= ruleEntry ) )* otherlv_13= '}' )
            // InternalVariability.g:901:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Configuration {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURED FEATURE MODEL:' ( (lv_configured_feature_model_11_0= RULE_STRING ) ) ( (lv_root_entry_12_0= ruleEntry ) )* otherlv_13= '}'
            {
            // InternalVariability.g:901:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:902:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:902:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:903:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeature_ConfigurationAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,22,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeature_ConfigurationAccess().getFeatureConfigurationKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeature_ConfigurationAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:927:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:928:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:928:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:929:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeature_ConfigurationAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeature_ConfigurationAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:949:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:950:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:950:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:951:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeature_ConfigurationAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeature_ConfigurationAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:971:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:972:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:972:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:973:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeature_ConfigurationAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeature_ConfigurationAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:993:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:994:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:994:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:995:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_17); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeature_ConfigurationAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,23,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getFeature_ConfigurationAccess().getCONFIGUREDFEATUREMODELKeyword_10());
            		
            // InternalVariability.g:1015:3: ( (lv_configured_feature_model_11_0= RULE_STRING ) )
            // InternalVariability.g:1016:4: (lv_configured_feature_model_11_0= RULE_STRING )
            {
            // InternalVariability.g:1016:4: (lv_configured_feature_model_11_0= RULE_STRING )
            // InternalVariability.g:1017:5: lv_configured_feature_model_11_0= RULE_STRING
            {
            lv_configured_feature_model_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_configured_feature_model_11_0, grammarAccess.getFeature_ConfigurationAccess().getConfigured_feature_modelSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConfigurationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"configured_feature_model",
            						lv_configured_feature_model_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:1033:3: ( (lv_root_entry_12_0= ruleEntry ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_ID) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalVariability.g:1034:4: (lv_root_entry_12_0= ruleEntry )
            	    {
            	    // InternalVariability.g:1034:4: (lv_root_entry_12_0= ruleEntry )
            	    // InternalVariability.g:1035:5: lv_root_entry_12_0= ruleEntry
            	    {

            	    					newCompositeNode(grammarAccess.getFeature_ConfigurationAccess().getRoot_entryEntryParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_root_entry_12_0=ruleEntry();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeature_ConfigurationRule());
            	    					}
            	    					add(
            	    						current,
            	    						"root_entry",
            	    						lv_root_entry_12_0,
            	    						"org.xtext.example.variability.Variability.Entry");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getFeature_ConfigurationAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature_Configuration"


    // $ANTLR start "entryRuleEntry"
    // InternalVariability.g:1060:1: entryRuleEntry returns [EObject current=null] : iv_ruleEntry= ruleEntry EOF ;
    public final EObject entryRuleEntry() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntry = null;


        try {
            // InternalVariability.g:1060:46: (iv_ruleEntry= ruleEntry EOF )
            // InternalVariability.g:1061:2: iv_ruleEntry= ruleEntry EOF
            {
             newCompositeNode(grammarAccess.getEntryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEntry=ruleEntry();

            state._fsp--;

             current =iv_ruleEntry; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEntry"


    // $ANTLR start "ruleEntry"
    // InternalVariability.g:1067:1: ruleEntry returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Entry {' ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )* ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )* otherlv_4= '}' ) ;
    public final EObject ruleEntry() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_4=null;
        EObject lv_configuration_decision_2_0 = null;

        EObject lv_configuration_decision_folder_3_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:1073:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Entry {' ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )* ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )* otherlv_4= '}' ) )
            // InternalVariability.g:1074:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Entry {' ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )* ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )* otherlv_4= '}' )
            {
            // InternalVariability.g:1074:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Entry {' ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )* ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )* otherlv_4= '}' )
            // InternalVariability.g:1075:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Entry {' ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )* ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )* otherlv_4= '}'
            {
            // InternalVariability.g:1075:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1076:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1076:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1077:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            					newLeafNode(lv_define_0_0, grammarAccess.getEntryAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEntryRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,24,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getEntryAccess().getEntryKeyword_1());
            		
            // InternalVariability.g:1097:3: ( (lv_configuration_decision_2_0= ruleConfiguration_Decision ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==RULE_ID) ) {
                    int LA16_1 = input.LA(2);

                    if ( (LA16_1==27) ) {
                        alt16=1;
                    }


                }


                switch (alt16) {
            	case 1 :
            	    // InternalVariability.g:1098:4: (lv_configuration_decision_2_0= ruleConfiguration_Decision )
            	    {
            	    // InternalVariability.g:1098:4: (lv_configuration_decision_2_0= ruleConfiguration_Decision )
            	    // InternalVariability.g:1099:5: lv_configuration_decision_2_0= ruleConfiguration_Decision
            	    {

            	    					newCompositeNode(grammarAccess.getEntryAccess().getConfiguration_decisionConfiguration_DecisionParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_configuration_decision_2_0=ruleConfiguration_Decision();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEntryRule());
            	    					}
            	    					add(
            	    						current,
            	    						"configuration_decision",
            	    						lv_configuration_decision_2_0,
            	    						"org.xtext.example.variability.Variability.Configuration_Decision");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            // InternalVariability.g:1116:3: ( (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==RULE_ID) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalVariability.g:1117:4: (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder )
            	    {
            	    // InternalVariability.g:1117:4: (lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder )
            	    // InternalVariability.g:1118:5: lv_configuration_decision_folder_3_0= ruleConfiguration_Decision_Folder
            	    {

            	    					newCompositeNode(grammarAccess.getEntryAccess().getConfiguration_decision_folderConfiguration_Decision_FolderParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_configuration_decision_folder_3_0=ruleConfiguration_Decision_Folder();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEntryRule());
            	    					}
            	    					add(
            	    						current,
            	    						"configuration_decision_folder",
            	    						lv_configuration_decision_folder_3_0,
            	    						"org.xtext.example.variability.Variability.Configuration_Decision_Folder");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            otherlv_4=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getEntryAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEntry"


    // $ANTLR start "entryRuleConfiguration_Decision_Folder"
    // InternalVariability.g:1143:1: entryRuleConfiguration_Decision_Folder returns [EObject current=null] : iv_ruleConfiguration_Decision_Folder= ruleConfiguration_Decision_Folder EOF ;
    public final EObject entryRuleConfiguration_Decision_Folder() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfiguration_Decision_Folder = null;


        try {
            // InternalVariability.g:1143:70: (iv_ruleConfiguration_Decision_Folder= ruleConfiguration_Decision_Folder EOF )
            // InternalVariability.g:1144:2: iv_ruleConfiguration_Decision_Folder= ruleConfiguration_Decision_Folder EOF
            {
             newCompositeNode(grammarAccess.getConfiguration_Decision_FolderRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfiguration_Decision_Folder=ruleConfiguration_Decision_Folder();

            state._fsp--;

             current =iv_ruleConfiguration_Decision_Folder; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfiguration_Decision_Folder"


    // $ANTLR start "ruleConfiguration_Decision_Folder"
    // InternalVariability.g:1150:1: ruleConfiguration_Decision_Folder returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision-Folder {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ( (lv_child_entry_12_0= ruleEntry ) )* otherlv_13= '}' ) ;
    public final EObject ruleConfiguration_Decision_Folder() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_is_active_11_0=null;
        Token otherlv_13=null;
        EObject lv_child_entry_12_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:1156:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision-Folder {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ( (lv_child_entry_12_0= ruleEntry ) )* otherlv_13= '}' ) )
            // InternalVariability.g:1157:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision-Folder {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ( (lv_child_entry_12_0= ruleEntry ) )* otherlv_13= '}' )
            {
            // InternalVariability.g:1157:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision-Folder {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ( (lv_child_entry_12_0= ruleEntry ) )* otherlv_13= '}' )
            // InternalVariability.g:1158:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision-Folder {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ( (lv_child_entry_12_0= ruleEntry ) )* otherlv_13= '}'
            {
            // InternalVariability.g:1158:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1159:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1159:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1160:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_define_0_0, grammarAccess.getConfiguration_Decision_FolderAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getConfiguration_Decision_FolderAccess().getConfigurationDecisionFolderKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getConfiguration_Decision_FolderAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:1184:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:1185:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:1185:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:1186:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getConfiguration_Decision_FolderAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getConfiguration_Decision_FolderAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:1206:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:1207:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:1207:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:1208:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getConfiguration_Decision_FolderAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getConfiguration_Decision_FolderAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:1228:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:1229:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:1229:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:1230:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getConfiguration_Decision_FolderAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getConfiguration_Decision_FolderAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:1250:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:1251:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:1251:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:1252:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_9_0, grammarAccess.getConfiguration_Decision_FolderAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,26,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getConfiguration_Decision_FolderAccess().getISACTIVEKeyword_10());
            		
            // InternalVariability.g:1272:3: ( (lv_is_active_11_0= RULE_STRING ) )
            // InternalVariability.g:1273:4: (lv_is_active_11_0= RULE_STRING )
            {
            // InternalVariability.g:1273:4: (lv_is_active_11_0= RULE_STRING )
            // InternalVariability.g:1274:5: lv_is_active_11_0= RULE_STRING
            {
            lv_is_active_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_is_active_11_0, grammarAccess.getConfiguration_Decision_FolderAccess().getIs_activeSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_Decision_FolderRule());
            					}
            					setWithLastConsumed(
            						current,
            						"is_active",
            						lv_is_active_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:1290:3: ( (lv_child_entry_12_0= ruleEntry ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==RULE_ID) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalVariability.g:1291:4: (lv_child_entry_12_0= ruleEntry )
            	    {
            	    // InternalVariability.g:1291:4: (lv_child_entry_12_0= ruleEntry )
            	    // InternalVariability.g:1292:5: lv_child_entry_12_0= ruleEntry
            	    {

            	    					newCompositeNode(grammarAccess.getConfiguration_Decision_FolderAccess().getChild_entryEntryParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_child_entry_12_0=ruleEntry();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConfiguration_Decision_FolderRule());
            	    					}
            	    					add(
            	    						current,
            	    						"child_entry",
            	    						lv_child_entry_12_0,
            	    						"org.xtext.example.variability.Variability.Entry");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            otherlv_13=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getConfiguration_Decision_FolderAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfiguration_Decision_Folder"


    // $ANTLR start "entryRuleConfiguration_Decision"
    // InternalVariability.g:1317:1: entryRuleConfiguration_Decision returns [EObject current=null] : iv_ruleConfiguration_Decision= ruleConfiguration_Decision EOF ;
    public final EObject entryRuleConfiguration_Decision() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfiguration_Decision = null;


        try {
            // InternalVariability.g:1317:63: (iv_ruleConfiguration_Decision= ruleConfiguration_Decision EOF )
            // InternalVariability.g:1318:2: iv_ruleConfiguration_Decision= ruleConfiguration_Decision EOF
            {
             newCompositeNode(grammarAccess.getConfiguration_DecisionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfiguration_Decision=ruleConfiguration_Decision();

            state._fsp--;

             current =iv_ruleConfiguration_Decision; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfiguration_Decision"


    // $ANTLR start "ruleConfiguration_Decision"
    // InternalVariability.g:1324:1: ruleConfiguration_Decision returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ) (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) ) (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) ) (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) ) (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) ) ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) ) otherlv_21= '}' ) ;
    public final EObject ruleConfiguration_Decision() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_is_active_11_0=null;
        Token otherlv_12=null;
        Token lv_is_equivalnce_13_0=null;
        Token otherlv_14=null;
        Token lv_effect_15_0=null;
        Token otherlv_16=null;
        Token lv_criterion_17_0=null;
        Token otherlv_18=null;
        Token lv_target_19_0=null;
        Token otherlv_21=null;
        EObject lv_selection_criteria_20_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:1330:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ) (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) ) (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) ) (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) ) (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) ) ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) ) otherlv_21= '}' ) )
            // InternalVariability.g:1331:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ) (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) ) (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) ) (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) ) (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) ) ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) ) otherlv_21= '}' )
            {
            // InternalVariability.g:1331:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ) (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) ) (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) ) (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) ) (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) ) ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) ) otherlv_21= '}' )
            // InternalVariability.g:1332:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configuration-Decision {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) ) (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) ) (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) ) (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) ) (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) ) ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) ) otherlv_21= '}'
            {
            // InternalVariability.g:1332:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1333:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1333:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1334:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_21); 

            					newLeafNode(lv_define_0_0, grammarAccess.getConfiguration_DecisionAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,27,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getConfiguration_DecisionAccess().getConfigurationDecisionKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getConfiguration_DecisionAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:1358:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:1359:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:1359:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:1360:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getConfiguration_DecisionAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getConfiguration_DecisionAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:1380:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:1381:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:1381:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:1382:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getConfiguration_DecisionAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getConfiguration_DecisionAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:1402:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:1403:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:1403:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:1404:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getConfiguration_DecisionAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getConfiguration_DecisionAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:1424:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:1425:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:1425:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:1426:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_20); 

            					newLeafNode(lv_name_9_0, grammarAccess.getConfiguration_DecisionAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:1442:3: (otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) ) )
            // InternalVariability.g:1443:4: otherlv_10= 'IS-ACTIVE:' ( (lv_is_active_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,26,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getConfiguration_DecisionAccess().getISACTIVEKeyword_10_0());
            			
            // InternalVariability.g:1447:4: ( (lv_is_active_11_0= RULE_STRING ) )
            // InternalVariability.g:1448:5: (lv_is_active_11_0= RULE_STRING )
            {
            // InternalVariability.g:1448:5: (lv_is_active_11_0= RULE_STRING )
            // InternalVariability.g:1449:6: lv_is_active_11_0= RULE_STRING
            {
            lv_is_active_11_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            						newLeafNode(lv_is_active_11_0, grammarAccess.getConfiguration_DecisionAccess().getIs_activeSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_active",
            							lv_is_active_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:1466:3: (otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) ) )
            // InternalVariability.g:1467:4: otherlv_12= 'IS-EQUIVALENCE:' ( (lv_is_equivalnce_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,28,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getConfiguration_DecisionAccess().getISEQUIVALENCEKeyword_11_0());
            			
            // InternalVariability.g:1471:4: ( (lv_is_equivalnce_13_0= RULE_STRING ) )
            // InternalVariability.g:1472:5: (lv_is_equivalnce_13_0= RULE_STRING )
            {
            // InternalVariability.g:1472:5: (lv_is_equivalnce_13_0= RULE_STRING )
            // InternalVariability.g:1473:6: lv_is_equivalnce_13_0= RULE_STRING
            {
            lv_is_equivalnce_13_0=(Token)match(input,RULE_STRING,FOLLOW_23); 

            						newLeafNode(lv_is_equivalnce_13_0, grammarAccess.getConfiguration_DecisionAccess().getIs_equivalnceSTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_equivalnce",
            							lv_is_equivalnce_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:1490:3: (otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) ) )
            // InternalVariability.g:1491:4: otherlv_14= 'EFFECT:' ( (lv_effect_15_0= RULE_STRING ) )
            {
            otherlv_14=(Token)match(input,29,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getConfiguration_DecisionAccess().getEFFECTKeyword_12_0());
            			
            // InternalVariability.g:1495:4: ( (lv_effect_15_0= RULE_STRING ) )
            // InternalVariability.g:1496:5: (lv_effect_15_0= RULE_STRING )
            {
            // InternalVariability.g:1496:5: (lv_effect_15_0= RULE_STRING )
            // InternalVariability.g:1497:6: lv_effect_15_0= RULE_STRING
            {
            lv_effect_15_0=(Token)match(input,RULE_STRING,FOLLOW_24); 

            						newLeafNode(lv_effect_15_0, grammarAccess.getConfiguration_DecisionAccess().getEffectSTRINGTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"effect",
            							lv_effect_15_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:1514:3: (otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) ) )
            // InternalVariability.g:1515:4: otherlv_16= 'CRITERION:' ( (lv_criterion_17_0= RULE_STRING ) )
            {
            otherlv_16=(Token)match(input,30,FOLLOW_6); 

            				newLeafNode(otherlv_16, grammarAccess.getConfiguration_DecisionAccess().getCRITERIONKeyword_13_0());
            			
            // InternalVariability.g:1519:4: ( (lv_criterion_17_0= RULE_STRING ) )
            // InternalVariability.g:1520:5: (lv_criterion_17_0= RULE_STRING )
            {
            // InternalVariability.g:1520:5: (lv_criterion_17_0= RULE_STRING )
            // InternalVariability.g:1521:6: lv_criterion_17_0= RULE_STRING
            {
            lv_criterion_17_0=(Token)match(input,RULE_STRING,FOLLOW_25); 

            						newLeafNode(lv_criterion_17_0, grammarAccess.getConfiguration_DecisionAccess().getCriterionSTRINGTerminalRuleCall_13_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"criterion",
            							lv_criterion_17_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:1538:3: (otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) ) )
            // InternalVariability.g:1539:4: otherlv_18= 'TARGET:' ( (lv_target_19_0= RULE_STRING ) )
            {
            otherlv_18=(Token)match(input,31,FOLLOW_6); 

            				newLeafNode(otherlv_18, grammarAccess.getConfiguration_DecisionAccess().getTARGETKeyword_14_0());
            			
            // InternalVariability.g:1543:4: ( (lv_target_19_0= RULE_STRING ) )
            // InternalVariability.g:1544:5: (lv_target_19_0= RULE_STRING )
            {
            // InternalVariability.g:1544:5: (lv_target_19_0= RULE_STRING )
            // InternalVariability.g:1545:6: lv_target_19_0= RULE_STRING
            {
            lv_target_19_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

            						newLeafNode(lv_target_19_0, grammarAccess.getConfiguration_DecisionAccess().getTargetSTRINGTerminalRuleCall_14_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getConfiguration_DecisionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"target",
            							lv_target_19_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:1562:3: ( (lv_selection_criteria_20_0= ruleSelection_Criteria ) )
            // InternalVariability.g:1563:4: (lv_selection_criteria_20_0= ruleSelection_Criteria )
            {
            // InternalVariability.g:1563:4: (lv_selection_criteria_20_0= ruleSelection_Criteria )
            // InternalVariability.g:1564:5: lv_selection_criteria_20_0= ruleSelection_Criteria
            {

            					newCompositeNode(grammarAccess.getConfiguration_DecisionAccess().getSelection_criteriaSelection_CriteriaParserRuleCall_15_0());
            				
            pushFollow(FOLLOW_27);
            lv_selection_criteria_20_0=ruleSelection_Criteria();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConfiguration_DecisionRule());
            					}
            					add(
            						current,
            						"selection_criteria",
            						lv_selection_criteria_20_0,
            						"org.xtext.example.variability.Variability.Selection_Criteria");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_21=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_21, grammarAccess.getConfiguration_DecisionAccess().getRightCurlyBracketKeyword_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfiguration_Decision"


    // $ANTLR start "entryRuleSelection_Criteria"
    // InternalVariability.g:1589:1: entryRuleSelection_Criteria returns [EObject current=null] : iv_ruleSelection_Criteria= ruleSelection_Criteria EOF ;
    public final EObject entryRuleSelection_Criteria() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSelection_Criteria = null;


        try {
            // InternalVariability.g:1589:59: (iv_ruleSelection_Criteria= ruleSelection_Criteria EOF )
            // InternalVariability.g:1590:2: iv_ruleSelection_Criteria= ruleSelection_Criteria EOF
            {
             newCompositeNode(grammarAccess.getSelection_CriteriaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelection_Criteria=ruleSelection_Criteria();

            state._fsp--;

             current =iv_ruleSelection_Criteria; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelection_Criteria"


    // $ANTLR start "ruleSelection_Criteria"
    // InternalVariability.g:1596:1: ruleSelection_Criteria returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Selection-Criteria {' otherlv_2= 'TYPE:' ( (lv_type_3_0= RULE_STRING ) ) otherlv_4= 'SOURCE:' ( (lv_source_5_0= RULE_STRING ) ) otherlv_6= '}' ) ;
    public final EObject ruleSelection_Criteria() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_type_3_0=null;
        Token otherlv_4=null;
        Token lv_source_5_0=null;
        Token otherlv_6=null;


        	enterRule();

        try {
            // InternalVariability.g:1602:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Selection-Criteria {' otherlv_2= 'TYPE:' ( (lv_type_3_0= RULE_STRING ) ) otherlv_4= 'SOURCE:' ( (lv_source_5_0= RULE_STRING ) ) otherlv_6= '}' ) )
            // InternalVariability.g:1603:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Selection-Criteria {' otherlv_2= 'TYPE:' ( (lv_type_3_0= RULE_STRING ) ) otherlv_4= 'SOURCE:' ( (lv_source_5_0= RULE_STRING ) ) otherlv_6= '}' )
            {
            // InternalVariability.g:1603:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Selection-Criteria {' otherlv_2= 'TYPE:' ( (lv_type_3_0= RULE_STRING ) ) otherlv_4= 'SOURCE:' ( (lv_source_5_0= RULE_STRING ) ) otherlv_6= '}' )
            // InternalVariability.g:1604:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Selection-Criteria {' otherlv_2= 'TYPE:' ( (lv_type_3_0= RULE_STRING ) ) otherlv_4= 'SOURCE:' ( (lv_source_5_0= RULE_STRING ) ) otherlv_6= '}'
            {
            // InternalVariability.g:1604:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1605:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1605:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1606:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_28); 

            					newLeafNode(lv_define_0_0, grammarAccess.getSelection_CriteriaAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSelection_CriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,32,FOLLOW_29); 

            			newLeafNode(otherlv_1, grammarAccess.getSelection_CriteriaAccess().getSelectionCriteriaKeyword_1());
            		
            otherlv_2=(Token)match(input,33,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getSelection_CriteriaAccess().getTYPEKeyword_2());
            		
            // InternalVariability.g:1630:3: ( (lv_type_3_0= RULE_STRING ) )
            // InternalVariability.g:1631:4: (lv_type_3_0= RULE_STRING )
            {
            // InternalVariability.g:1631:4: (lv_type_3_0= RULE_STRING )
            // InternalVariability.g:1632:5: lv_type_3_0= RULE_STRING
            {
            lv_type_3_0=(Token)match(input,RULE_STRING,FOLLOW_30); 

            					newLeafNode(lv_type_3_0, grammarAccess.getSelection_CriteriaAccess().getTypeSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSelection_CriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"type",
            						lv_type_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,34,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getSelection_CriteriaAccess().getSOURCEKeyword_4());
            		
            // InternalVariability.g:1652:3: ( (lv_source_5_0= RULE_STRING ) )
            // InternalVariability.g:1653:4: (lv_source_5_0= RULE_STRING )
            {
            // InternalVariability.g:1653:4: (lv_source_5_0= RULE_STRING )
            // InternalVariability.g:1654:5: lv_source_5_0= RULE_STRING
            {
            lv_source_5_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_source_5_0, grammarAccess.getSelection_CriteriaAccess().getSourceSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSelection_CriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"source",
            						lv_source_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getSelection_CriteriaAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelection_Criteria"


    // $ANTLR start "entryRuleVehicle_Level_Binding"
    // InternalVariability.g:1678:1: entryRuleVehicle_Level_Binding returns [EObject current=null] : iv_ruleVehicle_Level_Binding= ruleVehicle_Level_Binding EOF ;
    public final EObject entryRuleVehicle_Level_Binding() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVehicle_Level_Binding = null;


        try {
            // InternalVariability.g:1678:62: (iv_ruleVehicle_Level_Binding= ruleVehicle_Level_Binding EOF )
            // InternalVariability.g:1679:2: iv_ruleVehicle_Level_Binding= ruleVehicle_Level_Binding EOF
            {
             newCompositeNode(grammarAccess.getVehicle_Level_BindingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVehicle_Level_Binding=ruleVehicle_Level_Binding();

            state._fsp--;

             current =iv_ruleVehicle_Level_Binding; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVehicle_Level_Binding"


    // $ANTLR start "ruleVehicle_Level_Binding"
    // InternalVariability.g:1685:1: ruleVehicle_Level_Binding returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Level-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SOURCE-VEHICLE-FEATURE-MODEL:' ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) ) otherlv_12= 'TARGET-FEATURE-MODEL:' ( (lv_target_feature_model_13_0= RULE_STRING ) ) ( (lv_root_entry_14_0= ruleEntry ) )* otherlv_15= '}' ) ;
    public final EObject ruleVehicle_Level_Binding() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_source_vehicle_feature_model_11_0=null;
        Token otherlv_12=null;
        Token lv_target_feature_model_13_0=null;
        Token otherlv_15=null;
        EObject lv_root_entry_14_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:1691:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Level-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SOURCE-VEHICLE-FEATURE-MODEL:' ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) ) otherlv_12= 'TARGET-FEATURE-MODEL:' ( (lv_target_feature_model_13_0= RULE_STRING ) ) ( (lv_root_entry_14_0= ruleEntry ) )* otherlv_15= '}' ) )
            // InternalVariability.g:1692:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Level-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SOURCE-VEHICLE-FEATURE-MODEL:' ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) ) otherlv_12= 'TARGET-FEATURE-MODEL:' ( (lv_target_feature_model_13_0= RULE_STRING ) ) ( (lv_root_entry_14_0= ruleEntry ) )* otherlv_15= '}' )
            {
            // InternalVariability.g:1692:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Level-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SOURCE-VEHICLE-FEATURE-MODEL:' ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) ) otherlv_12= 'TARGET-FEATURE-MODEL:' ( (lv_target_feature_model_13_0= RULE_STRING ) ) ( (lv_root_entry_14_0= ruleEntry ) )* otherlv_15= '}' )
            // InternalVariability.g:1693:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Level-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'SOURCE-VEHICLE-FEATURE-MODEL:' ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) ) otherlv_12= 'TARGET-FEATURE-MODEL:' ( (lv_target_feature_model_13_0= RULE_STRING ) ) ( (lv_root_entry_14_0= ruleEntry ) )* otherlv_15= '}'
            {
            // InternalVariability.g:1693:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1694:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1694:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1695:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_31); 

            					newLeafNode(lv_define_0_0, grammarAccess.getVehicle_Level_BindingAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,35,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getVehicle_Level_BindingAccess().getVehicleLevelBindingKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getVehicle_Level_BindingAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:1719:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:1720:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:1720:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:1721:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getVehicle_Level_BindingAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getVehicle_Level_BindingAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:1741:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:1742:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:1742:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:1743:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getVehicle_Level_BindingAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVehicle_Level_BindingAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:1763:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:1764:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:1764:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:1765:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getVehicle_Level_BindingAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getVehicle_Level_BindingAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:1785:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:1786:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:1786:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:1787:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_32); 

            					newLeafNode(lv_name_9_0, grammarAccess.getVehicle_Level_BindingAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,36,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getVehicle_Level_BindingAccess().getSOURCEVEHICLEFEATUREMODELKeyword_10());
            		
            // InternalVariability.g:1807:3: ( (lv_source_vehicle_feature_model_11_0= RULE_STRING ) )
            // InternalVariability.g:1808:4: (lv_source_vehicle_feature_model_11_0= RULE_STRING )
            {
            // InternalVariability.g:1808:4: (lv_source_vehicle_feature_model_11_0= RULE_STRING )
            // InternalVariability.g:1809:5: lv_source_vehicle_feature_model_11_0= RULE_STRING
            {
            lv_source_vehicle_feature_model_11_0=(Token)match(input,RULE_STRING,FOLLOW_33); 

            					newLeafNode(lv_source_vehicle_feature_model_11_0, grammarAccess.getVehicle_Level_BindingAccess().getSource_vehicle_feature_modelSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"source_vehicle_feature_model",
            						lv_source_vehicle_feature_model_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,37,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getVehicle_Level_BindingAccess().getTARGETFEATUREMODELKeyword_12());
            		
            // InternalVariability.g:1829:3: ( (lv_target_feature_model_13_0= RULE_STRING ) )
            // InternalVariability.g:1830:4: (lv_target_feature_model_13_0= RULE_STRING )
            {
            // InternalVariability.g:1830:4: (lv_target_feature_model_13_0= RULE_STRING )
            // InternalVariability.g:1831:5: lv_target_feature_model_13_0= RULE_STRING
            {
            lv_target_feature_model_13_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_target_feature_model_13_0, grammarAccess.getVehicle_Level_BindingAccess().getTarget_feature_modelSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_Level_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"target_feature_model",
            						lv_target_feature_model_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:1847:3: ( (lv_root_entry_14_0= ruleEntry ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_ID) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalVariability.g:1848:4: (lv_root_entry_14_0= ruleEntry )
            	    {
            	    // InternalVariability.g:1848:4: (lv_root_entry_14_0= ruleEntry )
            	    // InternalVariability.g:1849:5: lv_root_entry_14_0= ruleEntry
            	    {

            	    					newCompositeNode(grammarAccess.getVehicle_Level_BindingAccess().getRoot_entryEntryParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_root_entry_14_0=ruleEntry();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVehicle_Level_BindingRule());
            	    					}
            	    					add(
            	    						current,
            	    						"root_entry",
            	    						lv_root_entry_14_0,
            	    						"org.xtext.example.variability.Variability.Entry");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getVehicle_Level_BindingAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVehicle_Level_Binding"


    // $ANTLR start "entryRuleFeature_Model"
    // InternalVariability.g:1874:1: entryRuleFeature_Model returns [EObject current=null] : iv_ruleFeature_Model= ruleFeature_Model EOF ;
    public final EObject entryRuleFeature_Model() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature_Model = null;


        try {
            // InternalVariability.g:1874:54: (iv_ruleFeature_Model= ruleFeature_Model EOF )
            // InternalVariability.g:1875:2: iv_ruleFeature_Model= ruleFeature_Model EOF
            {
             newCompositeNode(grammarAccess.getFeature_ModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature_Model=ruleFeature_Model();

            state._fsp--;

             current =iv_ruleFeature_Model; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature_Model"


    // $ANTLR start "ruleFeature_Model"
    // InternalVariability.g:1881:1: ruleFeature_Model returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Model {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) ( (lv_root_feature_12_0= ruleRoot_Feature ) )* ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )* ( (lv_feature_link_14_0= ruleFeature_Link ) )* otherlv_15= '}' ) ;
    public final EObject ruleFeature_Model() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_15=null;
        EObject lv_root_feature_12_0 = null;

        EObject lv_feature_constraint_13_0 = null;

        EObject lv_feature_link_14_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:1887:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Model {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) ( (lv_root_feature_12_0= ruleRoot_Feature ) )* ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )* ( (lv_feature_link_14_0= ruleFeature_Link ) )* otherlv_15= '}' ) )
            // InternalVariability.g:1888:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Model {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) ( (lv_root_feature_12_0= ruleRoot_Feature ) )* ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )* ( (lv_feature_link_14_0= ruleFeature_Link ) )* otherlv_15= '}' )
            {
            // InternalVariability.g:1888:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Model {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) ( (lv_root_feature_12_0= ruleRoot_Feature ) )* ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )* ( (lv_feature_link_14_0= ruleFeature_Link ) )* otherlv_15= '}' )
            // InternalVariability.g:1889:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Model {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) ( (lv_root_feature_12_0= ruleRoot_Feature ) )* ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )* ( (lv_feature_link_14_0= ruleFeature_Link ) )* otherlv_15= '}'
            {
            // InternalVariability.g:1889:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:1890:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:1890:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:1891:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_34); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeature_ModelAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,38,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeature_ModelAccess().getFeatureModelKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeature_ModelAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:1915:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:1916:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:1916:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:1917:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeature_ModelAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeature_ModelAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:1937:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:1938:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:1938:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:1939:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeature_ModelAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeature_ModelAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:1959:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:1960:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:1960:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:1961:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeature_ModelAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeature_ModelAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:1981:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:1982:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:1982:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:1983:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_35); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeature_ModelAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:1999:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )
            // InternalVariability.g:2000:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,21,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getFeature_ModelAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
            			
            // InternalVariability.g:2004:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
            // InternalVariability.g:2005:5: (lv_traceable_specification_11_0= RULE_STRING )
            {
            // InternalVariability.g:2005:5: (lv_traceable_specification_11_0= RULE_STRING )
            // InternalVariability.g:2006:6: lv_traceable_specification_11_0= RULE_STRING
            {
            lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getFeature_ModelAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_ModelRule());
            						}
            						setWithLastConsumed(
            							current,
            							"traceable_specification",
            							lv_traceable_specification_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:2023:3: ( (lv_root_feature_12_0= ruleRoot_Feature ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_ID) ) {
                    int LA20_1 = input.LA(2);

                    if ( (LA20_1==39) ) {
                        alt20=1;
                    }


                }


                switch (alt20) {
            	case 1 :
            	    // InternalVariability.g:2024:4: (lv_root_feature_12_0= ruleRoot_Feature )
            	    {
            	    // InternalVariability.g:2024:4: (lv_root_feature_12_0= ruleRoot_Feature )
            	    // InternalVariability.g:2025:5: lv_root_feature_12_0= ruleRoot_Feature
            	    {

            	    					newCompositeNode(grammarAccess.getFeature_ModelAccess().getRoot_featureRoot_FeatureParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_root_feature_12_0=ruleRoot_Feature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeature_ModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"root_feature",
            	    						lv_root_feature_12_0,
            	    						"org.xtext.example.variability.Variability.Root_Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            // InternalVariability.g:2042:3: ( (lv_feature_constraint_13_0= ruleFeature_Constraint ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==RULE_ID) ) {
                    int LA21_1 = input.LA(2);

                    if ( (LA21_1==66) ) {
                        alt21=1;
                    }


                }


                switch (alt21) {
            	case 1 :
            	    // InternalVariability.g:2043:4: (lv_feature_constraint_13_0= ruleFeature_Constraint )
            	    {
            	    // InternalVariability.g:2043:4: (lv_feature_constraint_13_0= ruleFeature_Constraint )
            	    // InternalVariability.g:2044:5: lv_feature_constraint_13_0= ruleFeature_Constraint
            	    {

            	    					newCompositeNode(grammarAccess.getFeature_ModelAccess().getFeature_constraintFeature_ConstraintParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_constraint_13_0=ruleFeature_Constraint();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeature_ModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature_constraint",
            	    						lv_feature_constraint_13_0,
            	    						"org.xtext.example.variability.Variability.Feature_Constraint");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            // InternalVariability.g:2061:3: ( (lv_feature_link_14_0= ruleFeature_Link ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==RULE_ID) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalVariability.g:2062:4: (lv_feature_link_14_0= ruleFeature_Link )
            	    {
            	    // InternalVariability.g:2062:4: (lv_feature_link_14_0= ruleFeature_Link )
            	    // InternalVariability.g:2063:5: lv_feature_link_14_0= ruleFeature_Link
            	    {

            	    					newCompositeNode(grammarAccess.getFeature_ModelAccess().getFeature_linkFeature_LinkParserRuleCall_13_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_link_14_0=ruleFeature_Link();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeature_ModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature_link",
            	    						lv_feature_link_14_0,
            	    						"org.xtext.example.variability.Variability.Feature_Link");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getFeature_ModelAccess().getRightCurlyBracketKeyword_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature_Model"


    // $ANTLR start "entryRuleRoot_Feature"
    // InternalVariability.g:2088:1: entryRuleRoot_Feature returns [EObject current=null] : iv_ruleRoot_Feature= ruleRoot_Feature EOF ;
    public final EObject entryRuleRoot_Feature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRoot_Feature = null;


        try {
            // InternalVariability.g:2088:53: (iv_ruleRoot_Feature= ruleRoot_Feature EOF )
            // InternalVariability.g:2089:2: iv_ruleRoot_Feature= ruleRoot_Feature EOF
            {
             newCompositeNode(grammarAccess.getRoot_FeatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRoot_Feature=ruleRoot_Feature();

            state._fsp--;

             current =iv_ruleRoot_Feature; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRoot_Feature"


    // $ANTLR start "ruleRoot_Feature"
    // InternalVariability.g:2095:1: ruleRoot_Feature returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Root-Feature {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* otherlv_4= '}' ) ;
    public final EObject ruleRoot_Feature() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_4=null;
        EObject lv_feature_2_0 = null;

        EObject lv_vehicle_feature_3_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:2101:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Root-Feature {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* otherlv_4= '}' ) )
            // InternalVariability.g:2102:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Root-Feature {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* otherlv_4= '}' )
            {
            // InternalVariability.g:2102:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Root-Feature {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* otherlv_4= '}' )
            // InternalVariability.g:2103:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Root-Feature {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* otherlv_4= '}'
            {
            // InternalVariability.g:2103:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2104:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2104:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2105:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_36); 

            					newLeafNode(lv_define_0_0, grammarAccess.getRoot_FeatureAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRoot_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,39,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getRoot_FeatureAccess().getRootFeatureKeyword_1());
            		
            // InternalVariability.g:2125:3: ( (lv_feature_2_0= ruleFeature ) )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==RULE_ID) ) {
                    int LA23_1 = input.LA(2);

                    if ( (LA23_1==40) ) {
                        alt23=1;
                    }


                }


                switch (alt23) {
            	case 1 :
            	    // InternalVariability.g:2126:4: (lv_feature_2_0= ruleFeature )
            	    {
            	    // InternalVariability.g:2126:4: (lv_feature_2_0= ruleFeature )
            	    // InternalVariability.g:2127:5: lv_feature_2_0= ruleFeature
            	    {

            	    					newCompositeNode(grammarAccess.getRoot_FeatureAccess().getFeatureFeatureParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_2_0=ruleFeature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRoot_FeatureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature",
            	    						lv_feature_2_0,
            	    						"org.xtext.example.variability.Variability.Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

            // InternalVariability.g:2144:3: ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==RULE_ID) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalVariability.g:2145:4: (lv_vehicle_feature_3_0= ruleVehicle_Feature )
            	    {
            	    // InternalVariability.g:2145:4: (lv_vehicle_feature_3_0= ruleVehicle_Feature )
            	    // InternalVariability.g:2146:5: lv_vehicle_feature_3_0= ruleVehicle_Feature
            	    {

            	    					newCompositeNode(grammarAccess.getRoot_FeatureAccess().getVehicle_featureVehicle_FeatureParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_vehicle_feature_3_0=ruleVehicle_Feature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRoot_FeatureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"vehicle_feature",
            	    						lv_vehicle_feature_3_0,
            	    						"org.xtext.example.variability.Variability.Vehicle_Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            otherlv_4=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getRoot_FeatureAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRoot_Feature"


    // $ANTLR start "entryRuleFeature"
    // InternalVariability.g:2171:1: entryRuleFeature returns [EObject current=null] : iv_ruleFeature= ruleFeature EOF ;
    public final EObject entryRuleFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature = null;


        try {
            // InternalVariability.g:2171:48: (iv_ruleFeature= ruleFeature EOF )
            // InternalVariability.g:2172:2: iv_ruleFeature= ruleFeature EOF
            {
             newCompositeNode(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature=ruleFeature();

            state._fsp--;

             current =iv_ruleFeature; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // InternalVariability.g:2178:1: ruleFeature returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )? ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) ) ( (lv_child_node_16_0= ruleChild_Node ) )* otherlv_17= '}' ) ;
    public final EObject ruleFeature() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_12=null;
        Token lv_cardinality_13_0=null;
        Token otherlv_17=null;
        EObject lv_actual_binding_time_14_0 = null;

        EObject lv_required_binding_time_15_0 = null;

        EObject lv_child_node_16_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:2184:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )? ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) ) ( (lv_child_node_16_0= ruleChild_Node ) )* otherlv_17= '}' ) )
            // InternalVariability.g:2185:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )? ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) ) ( (lv_child_node_16_0= ruleChild_Node ) )* otherlv_17= '}' )
            {
            // InternalVariability.g:2185:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )? ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) ) ( (lv_child_node_16_0= ruleChild_Node ) )* otherlv_17= '}' )
            // InternalVariability.g:2186:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )? ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) ) ( (lv_child_node_16_0= ruleChild_Node ) )* otherlv_17= '}'
            {
            // InternalVariability.g:2186:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2187:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2187:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2188:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_37); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeatureAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,40,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeatureAccess().getFeatureKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeatureAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:2212:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:2213:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:2213:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:2214:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeatureAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeatureAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:2234:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:2235:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:2235:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:2236:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeatureAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeatureAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:2256:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:2257:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:2257:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:2258:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeatureAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeatureAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:2278:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:2279:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:2279:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:2280:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_35); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeatureAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:2296:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )
            // InternalVariability.g:2297:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,21,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getFeatureAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
            			
            // InternalVariability.g:2301:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
            // InternalVariability.g:2302:5: (lv_traceable_specification_11_0= RULE_STRING )
            {
            // InternalVariability.g:2302:5: (lv_traceable_specification_11_0= RULE_STRING )
            // InternalVariability.g:2303:6: lv_traceable_specification_11_0= RULE_STRING
            {
            lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

            						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getFeatureAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"traceable_specification",
            							lv_traceable_specification_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:2320:3: (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==41) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalVariability.g:2321:4: otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) )
                    {
                    otherlv_12=(Token)match(input,41,FOLLOW_6); 

                    				newLeafNode(otherlv_12, grammarAccess.getFeatureAccess().getCARDINALITYKeyword_11_0());
                    			
                    // InternalVariability.g:2325:4: ( (lv_cardinality_13_0= RULE_STRING ) )
                    // InternalVariability.g:2326:5: (lv_cardinality_13_0= RULE_STRING )
                    {
                    // InternalVariability.g:2326:5: (lv_cardinality_13_0= RULE_STRING )
                    // InternalVariability.g:2327:6: lv_cardinality_13_0= RULE_STRING
                    {
                    lv_cardinality_13_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

                    						newLeafNode(lv_cardinality_13_0, grammarAccess.getFeatureAccess().getCardinalitySTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFeatureRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"cardinality",
                    							lv_cardinality_13_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalVariability.g:2344:3: ( (lv_actual_binding_time_14_0= ruleActual_Binding_Time ) )
            // InternalVariability.g:2345:4: (lv_actual_binding_time_14_0= ruleActual_Binding_Time )
            {
            // InternalVariability.g:2345:4: (lv_actual_binding_time_14_0= ruleActual_Binding_Time )
            // InternalVariability.g:2346:5: lv_actual_binding_time_14_0= ruleActual_Binding_Time
            {

            					newCompositeNode(grammarAccess.getFeatureAccess().getActual_binding_timeActual_Binding_TimeParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_26);
            lv_actual_binding_time_14_0=ruleActual_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFeatureRule());
            					}
            					add(
            						current,
            						"actual_binding_time",
            						lv_actual_binding_time_14_0,
            						"org.xtext.example.variability.Variability.Actual_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:2363:3: ( (lv_required_binding_time_15_0= ruleRequired_Binding_Time ) )
            // InternalVariability.g:2364:4: (lv_required_binding_time_15_0= ruleRequired_Binding_Time )
            {
            // InternalVariability.g:2364:4: (lv_required_binding_time_15_0= ruleRequired_Binding_Time )
            // InternalVariability.g:2365:5: lv_required_binding_time_15_0= ruleRequired_Binding_Time
            {

            					newCompositeNode(grammarAccess.getFeatureAccess().getRequired_binding_timeRequired_Binding_TimeParserRuleCall_13_0());
            				
            pushFollow(FOLLOW_10);
            lv_required_binding_time_15_0=ruleRequired_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFeatureRule());
            					}
            					add(
            						current,
            						"required_binding_time",
            						lv_required_binding_time_15_0,
            						"org.xtext.example.variability.Variability.Required_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:2382:3: ( (lv_child_node_16_0= ruleChild_Node ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==RULE_ID) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalVariability.g:2383:4: (lv_child_node_16_0= ruleChild_Node )
            	    {
            	    // InternalVariability.g:2383:4: (lv_child_node_16_0= ruleChild_Node )
            	    // InternalVariability.g:2384:5: lv_child_node_16_0= ruleChild_Node
            	    {

            	    					newCompositeNode(grammarAccess.getFeatureAccess().getChild_nodeChild_NodeParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_child_node_16_0=ruleChild_Node();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeatureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"child_node",
            	    						lv_child_node_16_0,
            	    						"org.xtext.example.variability.Variability.Child_Node");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            otherlv_17=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getFeatureAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "entryRuleRequired_Binding_Time"
    // InternalVariability.g:2409:1: entryRuleRequired_Binding_Time returns [EObject current=null] : iv_ruleRequired_Binding_Time= ruleRequired_Binding_Time EOF ;
    public final EObject entryRuleRequired_Binding_Time() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRequired_Binding_Time = null;


        try {
            // InternalVariability.g:2409:62: (iv_ruleRequired_Binding_Time= ruleRequired_Binding_Time EOF )
            // InternalVariability.g:2410:2: iv_ruleRequired_Binding_Time= ruleRequired_Binding_Time EOF
            {
             newCompositeNode(grammarAccess.getRequired_Binding_TimeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRequired_Binding_Time=ruleRequired_Binding_Time();

            state._fsp--;

             current =iv_ruleRequired_Binding_Time; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRequired_Binding_Time"


    // $ANTLR start "ruleRequired_Binding_Time"
    // InternalVariability.g:2416:1: ruleRequired_Binding_Time returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Required-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' ) ;
    public final EObject ruleRequired_Binding_Time() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_kind_11_0=null;
        Token otherlv_12=null;


        	enterRule();

        try {
            // InternalVariability.g:2422:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Required-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' ) )
            // InternalVariability.g:2423:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Required-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' )
            {
            // InternalVariability.g:2423:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Required-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' )
            // InternalVariability.g:2424:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Required-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}'
            {
            // InternalVariability.g:2424:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2425:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2425:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2426:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_39); 

            					newLeafNode(lv_define_0_0, grammarAccess.getRequired_Binding_TimeAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,42,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getRequired_Binding_TimeAccess().getRequiredBindingTimeKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getRequired_Binding_TimeAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:2450:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:2451:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:2451:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:2452:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getRequired_Binding_TimeAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getRequired_Binding_TimeAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:2472:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:2473:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:2473:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:2474:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getRequired_Binding_TimeAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getRequired_Binding_TimeAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:2494:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:2495:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:2495:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:2496:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getRequired_Binding_TimeAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getRequired_Binding_TimeAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:2516:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:2517:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:2517:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:2518:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

            					newLeafNode(lv_name_9_0, grammarAccess.getRequired_Binding_TimeAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,43,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getRequired_Binding_TimeAccess().getKINDKeyword_10());
            		
            // InternalVariability.g:2538:3: ( (lv_kind_11_0= RULE_STRING ) )
            // InternalVariability.g:2539:4: (lv_kind_11_0= RULE_STRING )
            {
            // InternalVariability.g:2539:4: (lv_kind_11_0= RULE_STRING )
            // InternalVariability.g:2540:5: lv_kind_11_0= RULE_STRING
            {
            lv_kind_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_kind_11_0, grammarAccess.getRequired_Binding_TimeAccess().getKindSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRequired_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"kind",
            						lv_kind_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getRequired_Binding_TimeAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRequired_Binding_Time"


    // $ANTLR start "entryRuleActual_Binding_Time"
    // InternalVariability.g:2564:1: entryRuleActual_Binding_Time returns [EObject current=null] : iv_ruleActual_Binding_Time= ruleActual_Binding_Time EOF ;
    public final EObject entryRuleActual_Binding_Time() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActual_Binding_Time = null;


        try {
            // InternalVariability.g:2564:60: (iv_ruleActual_Binding_Time= ruleActual_Binding_Time EOF )
            // InternalVariability.g:2565:2: iv_ruleActual_Binding_Time= ruleActual_Binding_Time EOF
            {
             newCompositeNode(grammarAccess.getActual_Binding_TimeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActual_Binding_Time=ruleActual_Binding_Time();

            state._fsp--;

             current =iv_ruleActual_Binding_Time; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActual_Binding_Time"


    // $ANTLR start "ruleActual_Binding_Time"
    // InternalVariability.g:2571:1: ruleActual_Binding_Time returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Actual-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' ) ;
    public final EObject ruleActual_Binding_Time() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_kind_11_0=null;
        Token otherlv_12=null;


        	enterRule();

        try {
            // InternalVariability.g:2577:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Actual-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' ) )
            // InternalVariability.g:2578:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Actual-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' )
            {
            // InternalVariability.g:2578:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Actual-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}' )
            // InternalVariability.g:2579:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Actual-Binding-Time {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'KIND:' ( (lv_kind_11_0= RULE_STRING ) ) otherlv_12= '}'
            {
            // InternalVariability.g:2579:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2580:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2580:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2581:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_41); 

            					newLeafNode(lv_define_0_0, grammarAccess.getActual_Binding_TimeAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,44,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getActual_Binding_TimeAccess().getActualBindingTimeKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getActual_Binding_TimeAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:2605:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:2606:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:2606:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:2607:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getActual_Binding_TimeAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getActual_Binding_TimeAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:2627:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:2628:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:2628:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:2629:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getActual_Binding_TimeAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getActual_Binding_TimeAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:2649:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:2650:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:2650:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:2651:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getActual_Binding_TimeAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getActual_Binding_TimeAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:2671:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:2672:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:2672:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:2673:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

            					newLeafNode(lv_name_9_0, grammarAccess.getActual_Binding_TimeAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,43,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getActual_Binding_TimeAccess().getKINDKeyword_10());
            		
            // InternalVariability.g:2693:3: ( (lv_kind_11_0= RULE_STRING ) )
            // InternalVariability.g:2694:4: (lv_kind_11_0= RULE_STRING )
            {
            // InternalVariability.g:2694:4: (lv_kind_11_0= RULE_STRING )
            // InternalVariability.g:2695:5: lv_kind_11_0= RULE_STRING
            {
            lv_kind_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_kind_11_0, grammarAccess.getActual_Binding_TimeAccess().getKindSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActual_Binding_TimeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"kind",
            						lv_kind_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getActual_Binding_TimeAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActual_Binding_Time"


    // $ANTLR start "entryRuleChild_Node"
    // InternalVariability.g:2719:1: entryRuleChild_Node returns [EObject current=null] : iv_ruleChild_Node= ruleChild_Node EOF ;
    public final EObject entryRuleChild_Node() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChild_Node = null;


        try {
            // InternalVariability.g:2719:51: (iv_ruleChild_Node= ruleChild_Node EOF )
            // InternalVariability.g:2720:2: iv_ruleChild_Node= ruleChild_Node EOF
            {
             newCompositeNode(grammarAccess.getChild_NodeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChild_Node=ruleChild_Node();

            state._fsp--;

             current =iv_ruleChild_Node; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChild_Node"


    // $ANTLR start "ruleChild_Node"
    // InternalVariability.g:2726:1: ruleChild_Node returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Child-Node {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* ( (lv_feature_group_4_0= ruleFeature_Group ) )* otherlv_5= '}' ) ;
    public final EObject ruleChild_Node() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_5=null;
        EObject lv_feature_2_0 = null;

        EObject lv_vehicle_feature_3_0 = null;

        EObject lv_feature_group_4_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:2732:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Child-Node {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* ( (lv_feature_group_4_0= ruleFeature_Group ) )* otherlv_5= '}' ) )
            // InternalVariability.g:2733:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Child-Node {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* ( (lv_feature_group_4_0= ruleFeature_Group ) )* otherlv_5= '}' )
            {
            // InternalVariability.g:2733:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Child-Node {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* ( (lv_feature_group_4_0= ruleFeature_Group ) )* otherlv_5= '}' )
            // InternalVariability.g:2734:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Child-Node {' ( (lv_feature_2_0= ruleFeature ) )* ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )* ( (lv_feature_group_4_0= ruleFeature_Group ) )* otherlv_5= '}'
            {
            // InternalVariability.g:2734:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2735:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2735:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2736:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_42); 

            					newLeafNode(lv_define_0_0, grammarAccess.getChild_NodeAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getChild_NodeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,45,FOLLOW_10); 

            			newLeafNode(otherlv_1, grammarAccess.getChild_NodeAccess().getChildNodeKeyword_1());
            		
            // InternalVariability.g:2756:3: ( (lv_feature_2_0= ruleFeature ) )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==RULE_ID) ) {
                    int LA27_1 = input.LA(2);

                    if ( (LA27_1==40) ) {
                        alt27=1;
                    }


                }


                switch (alt27) {
            	case 1 :
            	    // InternalVariability.g:2757:4: (lv_feature_2_0= ruleFeature )
            	    {
            	    // InternalVariability.g:2757:4: (lv_feature_2_0= ruleFeature )
            	    // InternalVariability.g:2758:5: lv_feature_2_0= ruleFeature
            	    {

            	    					newCompositeNode(grammarAccess.getChild_NodeAccess().getFeatureFeatureParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_2_0=ruleFeature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getChild_NodeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature",
            	    						lv_feature_2_0,
            	    						"org.xtext.example.variability.Variability.Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            // InternalVariability.g:2775:3: ( (lv_vehicle_feature_3_0= ruleVehicle_Feature ) )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==RULE_ID) ) {
                    int LA28_1 = input.LA(2);

                    if ( (LA28_1==46) ) {
                        alt28=1;
                    }


                }


                switch (alt28) {
            	case 1 :
            	    // InternalVariability.g:2776:4: (lv_vehicle_feature_3_0= ruleVehicle_Feature )
            	    {
            	    // InternalVariability.g:2776:4: (lv_vehicle_feature_3_0= ruleVehicle_Feature )
            	    // InternalVariability.g:2777:5: lv_vehicle_feature_3_0= ruleVehicle_Feature
            	    {

            	    					newCompositeNode(grammarAccess.getChild_NodeAccess().getVehicle_featureVehicle_FeatureParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_vehicle_feature_3_0=ruleVehicle_Feature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getChild_NodeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"vehicle_feature",
            	    						lv_vehicle_feature_3_0,
            	    						"org.xtext.example.variability.Variability.Vehicle_Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

            // InternalVariability.g:2794:3: ( (lv_feature_group_4_0= ruleFeature_Group ) )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==RULE_ID) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // InternalVariability.g:2795:4: (lv_feature_group_4_0= ruleFeature_Group )
            	    {
            	    // InternalVariability.g:2795:4: (lv_feature_group_4_0= ruleFeature_Group )
            	    // InternalVariability.g:2796:5: lv_feature_group_4_0= ruleFeature_Group
            	    {

            	    					newCompositeNode(grammarAccess.getChild_NodeAccess().getFeature_groupFeature_GroupParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_group_4_0=ruleFeature_Group();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getChild_NodeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature_group",
            	    						lv_feature_group_4_0,
            	    						"org.xtext.example.variability.Variability.Feature_Group");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

            otherlv_5=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getChild_NodeAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChild_Node"


    // $ANTLR start "entryRuleVehicle_Feature"
    // InternalVariability.g:2821:1: entryRuleVehicle_Feature returns [EObject current=null] : iv_ruleVehicle_Feature= ruleVehicle_Feature EOF ;
    public final EObject entryRuleVehicle_Feature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVehicle_Feature = null;


        try {
            // InternalVariability.g:2821:56: (iv_ruleVehicle_Feature= ruleVehicle_Feature EOF )
            // InternalVariability.g:2822:2: iv_ruleVehicle_Feature= ruleVehicle_Feature EOF
            {
             newCompositeNode(grammarAccess.getVehicle_FeatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVehicle_Feature=ruleVehicle_Feature();

            state._fsp--;

             current =iv_ruleVehicle_Feature; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVehicle_Feature"


    // $ANTLR start "ruleVehicle_Feature"
    // InternalVariability.g:2828:1: ruleVehicle_Feature returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) ) (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) ) (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) ) ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) ) ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) ) ( (lv_child_node_23_0= ruleChild_Node ) )* otherlv_24= '}' ) ;
    public final EObject ruleVehicle_Feature() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_12=null;
        Token lv_cardinality_13_0=null;
        Token otherlv_14=null;
        Token lv_is_removed_15_0=null;
        Token otherlv_16=null;
        Token lv_is_customer_visible_17_0=null;
        Token otherlv_18=null;
        Token lv_is_design_variability_rationale_19_0=null;
        Token otherlv_24=null;
        EObject lv_actual_binding_time_20_0 = null;

        EObject lv_required_binding_time_21_0 = null;

        EObject lv_deviation_attribute_set_22_0 = null;

        EObject lv_child_node_23_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:2834:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) ) (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) ) (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) ) ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) ) ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) ) ( (lv_child_node_23_0= ruleChild_Node ) )* otherlv_24= '}' ) )
            // InternalVariability.g:2835:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) ) (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) ) (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) ) ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) ) ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) ) ( (lv_child_node_23_0= ruleChild_Node ) )* otherlv_24= '}' )
            {
            // InternalVariability.g:2835:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) ) (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) ) (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) ) ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) ) ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) ) ( (lv_child_node_23_0= ruleChild_Node ) )* otherlv_24= '}' )
            // InternalVariability.g:2836:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Vehicle-Feature {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) ) (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) ) (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) ) ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) ) ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) ) ( (lv_child_node_23_0= ruleChild_Node ) )* otherlv_24= '}'
            {
            // InternalVariability.g:2836:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:2837:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:2837:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:2838:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_43); 

            					newLeafNode(lv_define_0_0, grammarAccess.getVehicle_FeatureAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,46,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getVehicle_FeatureAccess().getVehicleFeatureKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getVehicle_FeatureAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:2862:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:2863:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:2863:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:2864:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getVehicle_FeatureAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getVehicle_FeatureAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:2884:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:2885:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:2885:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:2886:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getVehicle_FeatureAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVehicle_FeatureAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:2906:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:2907:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:2907:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:2908:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getVehicle_FeatureAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getVehicle_FeatureAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:2928:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:2929:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:2929:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:2930:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_35); 

            					newLeafNode(lv_name_9_0, grammarAccess.getVehicle_FeatureAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:2946:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )
            // InternalVariability.g:2947:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,21,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getVehicle_FeatureAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
            			
            // InternalVariability.g:2951:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
            // InternalVariability.g:2952:5: (lv_traceable_specification_11_0= RULE_STRING )
            {
            // InternalVariability.g:2952:5: (lv_traceable_specification_11_0= RULE_STRING )
            // InternalVariability.g:2953:6: lv_traceable_specification_11_0= RULE_STRING
            {
            lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_44); 

            						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getVehicle_FeatureAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"traceable_specification",
            							lv_traceable_specification_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:2970:3: (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )
            // InternalVariability.g:2971:4: otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,41,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getVehicle_FeatureAccess().getCARDINALITYKeyword_11_0());
            			
            // InternalVariability.g:2975:4: ( (lv_cardinality_13_0= RULE_STRING ) )
            // InternalVariability.g:2976:5: (lv_cardinality_13_0= RULE_STRING )
            {
            // InternalVariability.g:2976:5: (lv_cardinality_13_0= RULE_STRING )
            // InternalVariability.g:2977:6: lv_cardinality_13_0= RULE_STRING
            {
            lv_cardinality_13_0=(Token)match(input,RULE_STRING,FOLLOW_45); 

            						newLeafNode(lv_cardinality_13_0, grammarAccess.getVehicle_FeatureAccess().getCardinalitySTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"cardinality",
            							lv_cardinality_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:2994:3: (otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) ) )
            // InternalVariability.g:2995:4: otherlv_14= 'IS-REMOVED:' ( (lv_is_removed_15_0= RULE_STRING ) )
            {
            otherlv_14=(Token)match(input,47,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getVehicle_FeatureAccess().getISREMOVEDKeyword_12_0());
            			
            // InternalVariability.g:2999:4: ( (lv_is_removed_15_0= RULE_STRING ) )
            // InternalVariability.g:3000:5: (lv_is_removed_15_0= RULE_STRING )
            {
            // InternalVariability.g:3000:5: (lv_is_removed_15_0= RULE_STRING )
            // InternalVariability.g:3001:6: lv_is_removed_15_0= RULE_STRING
            {
            lv_is_removed_15_0=(Token)match(input,RULE_STRING,FOLLOW_46); 

            						newLeafNode(lv_is_removed_15_0, grammarAccess.getVehicle_FeatureAccess().getIs_removedSTRINGTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_removed",
            							lv_is_removed_15_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3018:3: (otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) ) )
            // InternalVariability.g:3019:4: otherlv_16= 'IS-CUSTOMER-VISIBLE:' ( (lv_is_customer_visible_17_0= RULE_STRING ) )
            {
            otherlv_16=(Token)match(input,48,FOLLOW_6); 

            				newLeafNode(otherlv_16, grammarAccess.getVehicle_FeatureAccess().getISCUSTOMERVISIBLEKeyword_13_0());
            			
            // InternalVariability.g:3023:4: ( (lv_is_customer_visible_17_0= RULE_STRING ) )
            // InternalVariability.g:3024:5: (lv_is_customer_visible_17_0= RULE_STRING )
            {
            // InternalVariability.g:3024:5: (lv_is_customer_visible_17_0= RULE_STRING )
            // InternalVariability.g:3025:6: lv_is_customer_visible_17_0= RULE_STRING
            {
            lv_is_customer_visible_17_0=(Token)match(input,RULE_STRING,FOLLOW_47); 

            						newLeafNode(lv_is_customer_visible_17_0, grammarAccess.getVehicle_FeatureAccess().getIs_customer_visibleSTRINGTerminalRuleCall_13_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_customer_visible",
            							lv_is_customer_visible_17_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3042:3: (otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) ) )
            // InternalVariability.g:3043:4: otherlv_18= 'IS-DESIGN-VARIABILITY-RATIONALE:' ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) )
            {
            otherlv_18=(Token)match(input,49,FOLLOW_6); 

            				newLeafNode(otherlv_18, grammarAccess.getVehicle_FeatureAccess().getISDESIGNVARIABILITYRATIONALEKeyword_14_0());
            			
            // InternalVariability.g:3047:4: ( (lv_is_design_variability_rationale_19_0= RULE_STRING ) )
            // InternalVariability.g:3048:5: (lv_is_design_variability_rationale_19_0= RULE_STRING )
            {
            // InternalVariability.g:3048:5: (lv_is_design_variability_rationale_19_0= RULE_STRING )
            // InternalVariability.g:3049:6: lv_is_design_variability_rationale_19_0= RULE_STRING
            {
            lv_is_design_variability_rationale_19_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

            						newLeafNode(lv_is_design_variability_rationale_19_0, grammarAccess.getVehicle_FeatureAccess().getIs_design_variability_rationaleSTRINGTerminalRuleCall_14_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVehicle_FeatureRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_design_variability_rationale",
            							lv_is_design_variability_rationale_19_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3066:3: ( (lv_actual_binding_time_20_0= ruleActual_Binding_Time ) )
            // InternalVariability.g:3067:4: (lv_actual_binding_time_20_0= ruleActual_Binding_Time )
            {
            // InternalVariability.g:3067:4: (lv_actual_binding_time_20_0= ruleActual_Binding_Time )
            // InternalVariability.g:3068:5: lv_actual_binding_time_20_0= ruleActual_Binding_Time
            {

            					newCompositeNode(grammarAccess.getVehicle_FeatureAccess().getActual_binding_timeActual_Binding_TimeParserRuleCall_15_0());
            				
            pushFollow(FOLLOW_26);
            lv_actual_binding_time_20_0=ruleActual_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVehicle_FeatureRule());
            					}
            					add(
            						current,
            						"actual_binding_time",
            						lv_actual_binding_time_20_0,
            						"org.xtext.example.variability.Variability.Actual_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:3085:3: ( (lv_required_binding_time_21_0= ruleRequired_Binding_Time ) )
            // InternalVariability.g:3086:4: (lv_required_binding_time_21_0= ruleRequired_Binding_Time )
            {
            // InternalVariability.g:3086:4: (lv_required_binding_time_21_0= ruleRequired_Binding_Time )
            // InternalVariability.g:3087:5: lv_required_binding_time_21_0= ruleRequired_Binding_Time
            {

            					newCompositeNode(grammarAccess.getVehicle_FeatureAccess().getRequired_binding_timeRequired_Binding_TimeParserRuleCall_16_0());
            				
            pushFollow(FOLLOW_26);
            lv_required_binding_time_21_0=ruleRequired_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVehicle_FeatureRule());
            					}
            					add(
            						current,
            						"required_binding_time",
            						lv_required_binding_time_21_0,
            						"org.xtext.example.variability.Variability.Required_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:3104:3: ( (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set ) )
            // InternalVariability.g:3105:4: (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set )
            {
            // InternalVariability.g:3105:4: (lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set )
            // InternalVariability.g:3106:5: lv_deviation_attribute_set_22_0= ruleDeviation_Attribute_Set
            {

            					newCompositeNode(grammarAccess.getVehicle_FeatureAccess().getDeviation_attribute_setDeviation_Attribute_SetParserRuleCall_17_0());
            				
            pushFollow(FOLLOW_10);
            lv_deviation_attribute_set_22_0=ruleDeviation_Attribute_Set();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVehicle_FeatureRule());
            					}
            					add(
            						current,
            						"deviation_attribute_set",
            						lv_deviation_attribute_set_22_0,
            						"org.xtext.example.variability.Variability.Deviation_Attribute_Set");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:3123:3: ( (lv_child_node_23_0= ruleChild_Node ) )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==RULE_ID) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalVariability.g:3124:4: (lv_child_node_23_0= ruleChild_Node )
            	    {
            	    // InternalVariability.g:3124:4: (lv_child_node_23_0= ruleChild_Node )
            	    // InternalVariability.g:3125:5: lv_child_node_23_0= ruleChild_Node
            	    {

            	    					newCompositeNode(grammarAccess.getVehicle_FeatureAccess().getChild_nodeChild_NodeParserRuleCall_18_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_child_node_23_0=ruleChild_Node();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getVehicle_FeatureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"child_node",
            	    						lv_child_node_23_0,
            	    						"org.xtext.example.variability.Variability.Child_Node");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

            otherlv_24=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_24, grammarAccess.getVehicle_FeatureAccess().getRightCurlyBracketKeyword_19());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVehicle_Feature"


    // $ANTLR start "entryRuleDeviation_Attribute_Set"
    // InternalVariability.g:3150:1: entryRuleDeviation_Attribute_Set returns [EObject current=null] : iv_ruleDeviation_Attribute_Set= ruleDeviation_Attribute_Set EOF ;
    public final EObject entryRuleDeviation_Attribute_Set() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDeviation_Attribute_Set = null;


        try {
            // InternalVariability.g:3150:64: (iv_ruleDeviation_Attribute_Set= ruleDeviation_Attribute_Set EOF )
            // InternalVariability.g:3151:2: iv_ruleDeviation_Attribute_Set= ruleDeviation_Attribute_Set EOF
            {
             newCompositeNode(grammarAccess.getDeviation_Attribute_SetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeviation_Attribute_Set=ruleDeviation_Attribute_Set();

            state._fsp--;

             current =iv_ruleDeviation_Attribute_Set; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeviation_Attribute_Set"


    // $ANTLR start "ruleDeviation_Attribute_Set"
    // InternalVariability.g:3157:1: ruleDeviation_Attribute_Set returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Deviation-Attribute-Set {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'ALLOW-REMOVAL:' ( (lv_allow_removal_11_0= RULE_STRING ) ) otherlv_12= 'ALLOW-REGROUPING:' ( (lv_allow_regrouping_13_0= RULE_STRING ) ) otherlv_14= 'ALLOW-REFINEMENT:' ( (lv_allow_refinement_15_0= RULE_STRING ) ) otherlv_16= 'ALLOW-REDUCTION:' ( (lv_allow_reduction_17_0= RULE_STRING ) ) otherlv_18= 'ALLOW-MOVE:' ( (lv_allow_move_19_0= RULE_STRING ) ) otherlv_20= 'ALLOW-CHANGE-NAME:' ( (lv_allow_change_name_21_0= RULE_STRING ) ) otherlv_22= 'ALLOW-CHANGE-DESCRIPTION:' ( (lv_allow_change_description_23_0= RULE_STRING ) ) otherlv_24= 'ALLOW-CHANGE-CARDINALITY:' ( (lv_allow_change_cardinality_25_0= RULE_STRING ) ) otherlv_26= 'ALLOW-CHANGE-ATTRIBUTE:' ( (lv_allow_change_attribute_27_0= RULE_STRING ) ) otherlv_28= '}' ) ;
    public final EObject ruleDeviation_Attribute_Set() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_allow_removal_11_0=null;
        Token otherlv_12=null;
        Token lv_allow_regrouping_13_0=null;
        Token otherlv_14=null;
        Token lv_allow_refinement_15_0=null;
        Token otherlv_16=null;
        Token lv_allow_reduction_17_0=null;
        Token otherlv_18=null;
        Token lv_allow_move_19_0=null;
        Token otherlv_20=null;
        Token lv_allow_change_name_21_0=null;
        Token otherlv_22=null;
        Token lv_allow_change_description_23_0=null;
        Token otherlv_24=null;
        Token lv_allow_change_cardinality_25_0=null;
        Token otherlv_26=null;
        Token lv_allow_change_attribute_27_0=null;
        Token otherlv_28=null;


        	enterRule();

        try {
            // InternalVariability.g:3163:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Deviation-Attribute-Set {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'ALLOW-REMOVAL:' ( (lv_allow_removal_11_0= RULE_STRING ) ) otherlv_12= 'ALLOW-REGROUPING:' ( (lv_allow_regrouping_13_0= RULE_STRING ) ) otherlv_14= 'ALLOW-REFINEMENT:' ( (lv_allow_refinement_15_0= RULE_STRING ) ) otherlv_16= 'ALLOW-REDUCTION:' ( (lv_allow_reduction_17_0= RULE_STRING ) ) otherlv_18= 'ALLOW-MOVE:' ( (lv_allow_move_19_0= RULE_STRING ) ) otherlv_20= 'ALLOW-CHANGE-NAME:' ( (lv_allow_change_name_21_0= RULE_STRING ) ) otherlv_22= 'ALLOW-CHANGE-DESCRIPTION:' ( (lv_allow_change_description_23_0= RULE_STRING ) ) otherlv_24= 'ALLOW-CHANGE-CARDINALITY:' ( (lv_allow_change_cardinality_25_0= RULE_STRING ) ) otherlv_26= 'ALLOW-CHANGE-ATTRIBUTE:' ( (lv_allow_change_attribute_27_0= RULE_STRING ) ) otherlv_28= '}' ) )
            // InternalVariability.g:3164:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Deviation-Attribute-Set {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'ALLOW-REMOVAL:' ( (lv_allow_removal_11_0= RULE_STRING ) ) otherlv_12= 'ALLOW-REGROUPING:' ( (lv_allow_regrouping_13_0= RULE_STRING ) ) otherlv_14= 'ALLOW-REFINEMENT:' ( (lv_allow_refinement_15_0= RULE_STRING ) ) otherlv_16= 'ALLOW-REDUCTION:' ( (lv_allow_reduction_17_0= RULE_STRING ) ) otherlv_18= 'ALLOW-MOVE:' ( (lv_allow_move_19_0= RULE_STRING ) ) otherlv_20= 'ALLOW-CHANGE-NAME:' ( (lv_allow_change_name_21_0= RULE_STRING ) ) otherlv_22= 'ALLOW-CHANGE-DESCRIPTION:' ( (lv_allow_change_description_23_0= RULE_STRING ) ) otherlv_24= 'ALLOW-CHANGE-CARDINALITY:' ( (lv_allow_change_cardinality_25_0= RULE_STRING ) ) otherlv_26= 'ALLOW-CHANGE-ATTRIBUTE:' ( (lv_allow_change_attribute_27_0= RULE_STRING ) ) otherlv_28= '}' )
            {
            // InternalVariability.g:3164:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Deviation-Attribute-Set {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'ALLOW-REMOVAL:' ( (lv_allow_removal_11_0= RULE_STRING ) ) otherlv_12= 'ALLOW-REGROUPING:' ( (lv_allow_regrouping_13_0= RULE_STRING ) ) otherlv_14= 'ALLOW-REFINEMENT:' ( (lv_allow_refinement_15_0= RULE_STRING ) ) otherlv_16= 'ALLOW-REDUCTION:' ( (lv_allow_reduction_17_0= RULE_STRING ) ) otherlv_18= 'ALLOW-MOVE:' ( (lv_allow_move_19_0= RULE_STRING ) ) otherlv_20= 'ALLOW-CHANGE-NAME:' ( (lv_allow_change_name_21_0= RULE_STRING ) ) otherlv_22= 'ALLOW-CHANGE-DESCRIPTION:' ( (lv_allow_change_description_23_0= RULE_STRING ) ) otherlv_24= 'ALLOW-CHANGE-CARDINALITY:' ( (lv_allow_change_cardinality_25_0= RULE_STRING ) ) otherlv_26= 'ALLOW-CHANGE-ATTRIBUTE:' ( (lv_allow_change_attribute_27_0= RULE_STRING ) ) otherlv_28= '}' )
            // InternalVariability.g:3165:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Deviation-Attribute-Set {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'ALLOW-REMOVAL:' ( (lv_allow_removal_11_0= RULE_STRING ) ) otherlv_12= 'ALLOW-REGROUPING:' ( (lv_allow_regrouping_13_0= RULE_STRING ) ) otherlv_14= 'ALLOW-REFINEMENT:' ( (lv_allow_refinement_15_0= RULE_STRING ) ) otherlv_16= 'ALLOW-REDUCTION:' ( (lv_allow_reduction_17_0= RULE_STRING ) ) otherlv_18= 'ALLOW-MOVE:' ( (lv_allow_move_19_0= RULE_STRING ) ) otherlv_20= 'ALLOW-CHANGE-NAME:' ( (lv_allow_change_name_21_0= RULE_STRING ) ) otherlv_22= 'ALLOW-CHANGE-DESCRIPTION:' ( (lv_allow_change_description_23_0= RULE_STRING ) ) otherlv_24= 'ALLOW-CHANGE-CARDINALITY:' ( (lv_allow_change_cardinality_25_0= RULE_STRING ) ) otherlv_26= 'ALLOW-CHANGE-ATTRIBUTE:' ( (lv_allow_change_attribute_27_0= RULE_STRING ) ) otherlv_28= '}'
            {
            // InternalVariability.g:3165:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:3166:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:3166:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:3167:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_48); 

            					newLeafNode(lv_define_0_0, grammarAccess.getDeviation_Attribute_SetAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,50,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getDeviation_Attribute_SetAccess().getDeviationAttributeSetKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getDeviation_Attribute_SetAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:3191:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:3192:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:3192:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:3193:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getDeviation_Attribute_SetAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getDeviation_Attribute_SetAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:3213:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:3214:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:3214:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:3215:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getDeviation_Attribute_SetAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getDeviation_Attribute_SetAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:3235:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:3236:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:3236:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:3237:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getDeviation_Attribute_SetAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getDeviation_Attribute_SetAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:3257:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:3258:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:3258:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:3259:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_49); 

            					newLeafNode(lv_name_9_0, grammarAccess.getDeviation_Attribute_SetAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,51,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWREMOVALKeyword_10());
            		
            // InternalVariability.g:3279:3: ( (lv_allow_removal_11_0= RULE_STRING ) )
            // InternalVariability.g:3280:4: (lv_allow_removal_11_0= RULE_STRING )
            {
            // InternalVariability.g:3280:4: (lv_allow_removal_11_0= RULE_STRING )
            // InternalVariability.g:3281:5: lv_allow_removal_11_0= RULE_STRING
            {
            lv_allow_removal_11_0=(Token)match(input,RULE_STRING,FOLLOW_50); 

            					newLeafNode(lv_allow_removal_11_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_removalSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_removal",
            						lv_allow_removal_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,52,FOLLOW_6); 

            			newLeafNode(otherlv_12, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWREGROUPINGKeyword_12());
            		
            // InternalVariability.g:3301:3: ( (lv_allow_regrouping_13_0= RULE_STRING ) )
            // InternalVariability.g:3302:4: (lv_allow_regrouping_13_0= RULE_STRING )
            {
            // InternalVariability.g:3302:4: (lv_allow_regrouping_13_0= RULE_STRING )
            // InternalVariability.g:3303:5: lv_allow_regrouping_13_0= RULE_STRING
            {
            lv_allow_regrouping_13_0=(Token)match(input,RULE_STRING,FOLLOW_51); 

            					newLeafNode(lv_allow_regrouping_13_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_regroupingSTRINGTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_regrouping",
            						lv_allow_regrouping_13_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_14=(Token)match(input,53,FOLLOW_6); 

            			newLeafNode(otherlv_14, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWREFINEMENTKeyword_14());
            		
            // InternalVariability.g:3323:3: ( (lv_allow_refinement_15_0= RULE_STRING ) )
            // InternalVariability.g:3324:4: (lv_allow_refinement_15_0= RULE_STRING )
            {
            // InternalVariability.g:3324:4: (lv_allow_refinement_15_0= RULE_STRING )
            // InternalVariability.g:3325:5: lv_allow_refinement_15_0= RULE_STRING
            {
            lv_allow_refinement_15_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_allow_refinement_15_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_refinementSTRINGTerminalRuleCall_15_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_refinement",
            						lv_allow_refinement_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_16=(Token)match(input,54,FOLLOW_6); 

            			newLeafNode(otherlv_16, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWREDUCTIONKeyword_16());
            		
            // InternalVariability.g:3345:3: ( (lv_allow_reduction_17_0= RULE_STRING ) )
            // InternalVariability.g:3346:4: (lv_allow_reduction_17_0= RULE_STRING )
            {
            // InternalVariability.g:3346:4: (lv_allow_reduction_17_0= RULE_STRING )
            // InternalVariability.g:3347:5: lv_allow_reduction_17_0= RULE_STRING
            {
            lv_allow_reduction_17_0=(Token)match(input,RULE_STRING,FOLLOW_53); 

            					newLeafNode(lv_allow_reduction_17_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_reductionSTRINGTerminalRuleCall_17_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_reduction",
            						lv_allow_reduction_17_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_18=(Token)match(input,55,FOLLOW_6); 

            			newLeafNode(otherlv_18, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWMOVEKeyword_18());
            		
            // InternalVariability.g:3367:3: ( (lv_allow_move_19_0= RULE_STRING ) )
            // InternalVariability.g:3368:4: (lv_allow_move_19_0= RULE_STRING )
            {
            // InternalVariability.g:3368:4: (lv_allow_move_19_0= RULE_STRING )
            // InternalVariability.g:3369:5: lv_allow_move_19_0= RULE_STRING
            {
            lv_allow_move_19_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_allow_move_19_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_moveSTRINGTerminalRuleCall_19_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_move",
            						lv_allow_move_19_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_20=(Token)match(input,56,FOLLOW_6); 

            			newLeafNode(otherlv_20, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWCHANGENAMEKeyword_20());
            		
            // InternalVariability.g:3389:3: ( (lv_allow_change_name_21_0= RULE_STRING ) )
            // InternalVariability.g:3390:4: (lv_allow_change_name_21_0= RULE_STRING )
            {
            // InternalVariability.g:3390:4: (lv_allow_change_name_21_0= RULE_STRING )
            // InternalVariability.g:3391:5: lv_allow_change_name_21_0= RULE_STRING
            {
            lv_allow_change_name_21_0=(Token)match(input,RULE_STRING,FOLLOW_55); 

            					newLeafNode(lv_allow_change_name_21_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_change_nameSTRINGTerminalRuleCall_21_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_change_name",
            						lv_allow_change_name_21_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_22=(Token)match(input,57,FOLLOW_6); 

            			newLeafNode(otherlv_22, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWCHANGEDESCRIPTIONKeyword_22());
            		
            // InternalVariability.g:3411:3: ( (lv_allow_change_description_23_0= RULE_STRING ) )
            // InternalVariability.g:3412:4: (lv_allow_change_description_23_0= RULE_STRING )
            {
            // InternalVariability.g:3412:4: (lv_allow_change_description_23_0= RULE_STRING )
            // InternalVariability.g:3413:5: lv_allow_change_description_23_0= RULE_STRING
            {
            lv_allow_change_description_23_0=(Token)match(input,RULE_STRING,FOLLOW_56); 

            					newLeafNode(lv_allow_change_description_23_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_change_descriptionSTRINGTerminalRuleCall_23_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_change_description",
            						lv_allow_change_description_23_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_24=(Token)match(input,58,FOLLOW_6); 

            			newLeafNode(otherlv_24, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWCHANGECARDINALITYKeyword_24());
            		
            // InternalVariability.g:3433:3: ( (lv_allow_change_cardinality_25_0= RULE_STRING ) )
            // InternalVariability.g:3434:4: (lv_allow_change_cardinality_25_0= RULE_STRING )
            {
            // InternalVariability.g:3434:4: (lv_allow_change_cardinality_25_0= RULE_STRING )
            // InternalVariability.g:3435:5: lv_allow_change_cardinality_25_0= RULE_STRING
            {
            lv_allow_change_cardinality_25_0=(Token)match(input,RULE_STRING,FOLLOW_57); 

            					newLeafNode(lv_allow_change_cardinality_25_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_change_cardinalitySTRINGTerminalRuleCall_25_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_change_cardinality",
            						lv_allow_change_cardinality_25_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_26=(Token)match(input,59,FOLLOW_6); 

            			newLeafNode(otherlv_26, grammarAccess.getDeviation_Attribute_SetAccess().getALLOWCHANGEATTRIBUTEKeyword_26());
            		
            // InternalVariability.g:3455:3: ( (lv_allow_change_attribute_27_0= RULE_STRING ) )
            // InternalVariability.g:3456:4: (lv_allow_change_attribute_27_0= RULE_STRING )
            {
            // InternalVariability.g:3456:4: (lv_allow_change_attribute_27_0= RULE_STRING )
            // InternalVariability.g:3457:5: lv_allow_change_attribute_27_0= RULE_STRING
            {
            lv_allow_change_attribute_27_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_allow_change_attribute_27_0, grammarAccess.getDeviation_Attribute_SetAccess().getAllow_change_attributeSTRINGTerminalRuleCall_27_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDeviation_Attribute_SetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"allow_change_attribute",
            						lv_allow_change_attribute_27_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_28=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_28, grammarAccess.getDeviation_Attribute_SetAccess().getRightCurlyBracketKeyword_28());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeviation_Attribute_Set"


    // $ANTLR start "entryRuleFeature_Group"
    // InternalVariability.g:3481:1: entryRuleFeature_Group returns [EObject current=null] : iv_ruleFeature_Group= ruleFeature_Group EOF ;
    public final EObject entryRuleFeature_Group() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature_Group = null;


        try {
            // InternalVariability.g:3481:54: (iv_ruleFeature_Group= ruleFeature_Group EOF )
            // InternalVariability.g:3482:2: iv_ruleFeature_Group= ruleFeature_Group EOF
            {
             newCompositeNode(grammarAccess.getFeature_GroupRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature_Group=ruleFeature_Group();

            state._fsp--;

             current =iv_ruleFeature_Group; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature_Group"


    // $ANTLR start "ruleFeature_Group"
    // InternalVariability.g:3488:1: ruleFeature_Group returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) ( (lv_child_feature_14_0= ruleRoot_Feature ) )* otherlv_15= '}' ) ;
    public final EObject ruleFeature_Group() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_traceable_specification_11_0=null;
        Token otherlv_12=null;
        Token lv_cardinality_13_0=null;
        Token otherlv_15=null;
        EObject lv_child_feature_14_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:3494:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) ( (lv_child_feature_14_0= ruleRoot_Feature ) )* otherlv_15= '}' ) )
            // InternalVariability.g:3495:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) ( (lv_child_feature_14_0= ruleRoot_Feature ) )* otherlv_15= '}' )
            {
            // InternalVariability.g:3495:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) ( (lv_child_feature_14_0= ruleRoot_Feature ) )* otherlv_15= '}' )
            // InternalVariability.g:3496:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) ) (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) ) ( (lv_child_feature_14_0= ruleRoot_Feature ) )* otherlv_15= '}'
            {
            // InternalVariability.g:3496:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:3497:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:3497:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:3498:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_58); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeature_GroupAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,60,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeature_GroupAccess().getFeatureGroupKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeature_GroupAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:3522:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:3523:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:3523:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:3524:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeature_GroupAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeature_GroupAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:3544:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:3545:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:3545:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:3546:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeature_GroupAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeature_GroupAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:3566:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:3567:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:3567:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:3568:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeature_GroupAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeature_GroupAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:3588:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:3589:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:3589:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:3590:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_35); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeature_GroupAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:3606:3: (otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) ) )
            // InternalVariability.g:3607:4: otherlv_10= 'TRACEABLE-SPECIFICATION-REFS:' ( (lv_traceable_specification_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,21,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getFeature_GroupAccess().getTRACEABLESPECIFICATIONREFSKeyword_10_0());
            			
            // InternalVariability.g:3611:4: ( (lv_traceable_specification_11_0= RULE_STRING ) )
            // InternalVariability.g:3612:5: (lv_traceable_specification_11_0= RULE_STRING )
            {
            // InternalVariability.g:3612:5: (lv_traceable_specification_11_0= RULE_STRING )
            // InternalVariability.g:3613:6: lv_traceable_specification_11_0= RULE_STRING
            {
            lv_traceable_specification_11_0=(Token)match(input,RULE_STRING,FOLLOW_44); 

            						newLeafNode(lv_traceable_specification_11_0, grammarAccess.getFeature_GroupAccess().getTraceable_specificationSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_GroupRule());
            						}
            						setWithLastConsumed(
            							current,
            							"traceable_specification",
            							lv_traceable_specification_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3630:3: (otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) ) )
            // InternalVariability.g:3631:4: otherlv_12= 'CARDINALITY:' ( (lv_cardinality_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,41,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getFeature_GroupAccess().getCARDINALITYKeyword_11_0());
            			
            // InternalVariability.g:3635:4: ( (lv_cardinality_13_0= RULE_STRING ) )
            // InternalVariability.g:3636:5: (lv_cardinality_13_0= RULE_STRING )
            {
            // InternalVariability.g:3636:5: (lv_cardinality_13_0= RULE_STRING )
            // InternalVariability.g:3637:6: lv_cardinality_13_0= RULE_STRING
            {
            lv_cardinality_13_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            						newLeafNode(lv_cardinality_13_0, grammarAccess.getFeature_GroupAccess().getCardinalitySTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_GroupRule());
            						}
            						setWithLastConsumed(
            							current,
            							"cardinality",
            							lv_cardinality_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3654:3: ( (lv_child_feature_14_0= ruleRoot_Feature ) )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==RULE_ID) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalVariability.g:3655:4: (lv_child_feature_14_0= ruleRoot_Feature )
            	    {
            	    // InternalVariability.g:3655:4: (lv_child_feature_14_0= ruleRoot_Feature )
            	    // InternalVariability.g:3656:5: lv_child_feature_14_0= ruleRoot_Feature
            	    {

            	    					newCompositeNode(grammarAccess.getFeature_GroupAccess().getChild_featureRoot_FeatureParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_child_feature_14_0=ruleRoot_Feature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeature_GroupRule());
            	    					}
            	    					add(
            	    						current,
            	    						"child_feature",
            	    						lv_child_feature_14_0,
            	    						"org.xtext.example.variability.Variability.Root_Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getFeature_GroupAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature_Group"


    // $ANTLR start "entryRuleFeature_Link"
    // InternalVariability.g:3681:1: entryRuleFeature_Link returns [EObject current=null] : iv_ruleFeature_Link= ruleFeature_Link EOF ;
    public final EObject entryRuleFeature_Link() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature_Link = null;


        try {
            // InternalVariability.g:3681:53: (iv_ruleFeature_Link= ruleFeature_Link EOF )
            // InternalVariability.g:3682:2: iv_ruleFeature_Link= ruleFeature_Link EOF
            {
             newCompositeNode(grammarAccess.getFeature_LinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature_Link=ruleFeature_Link();

            state._fsp--;

             current =iv_ruleFeature_Link; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature_Link"


    // $ANTLR start "ruleFeature_Link"
    // InternalVariability.g:3688:1: ruleFeature_Link returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Link {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) ) (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) ) (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) ) (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) ) (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )? otherlv_20= '}' ) ;
    public final EObject ruleFeature_Link() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_is_bidirectional_11_0=null;
        Token otherlv_12=null;
        Token lv_custom_type_13_0=null;
        Token otherlv_14=null;
        Token lv_kind_15_0=null;
        Token otherlv_16=null;
        Token lv_start_17_0=null;
        Token otherlv_18=null;
        Token lv_end_19_0=null;
        Token otherlv_20=null;


        	enterRule();

        try {
            // InternalVariability.g:3694:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Link {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) ) (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) ) (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) ) (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) ) (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )? otherlv_20= '}' ) )
            // InternalVariability.g:3695:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Link {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) ) (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) ) (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) ) (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) ) (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )? otherlv_20= '}' )
            {
            // InternalVariability.g:3695:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Link {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) ) (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) ) (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) ) (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) ) (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )? otherlv_20= '}' )
            // InternalVariability.g:3696:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Link {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) ) (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) ) (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) ) (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) ) (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )? otherlv_20= '}'
            {
            // InternalVariability.g:3696:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:3697:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:3697:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:3698:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_59); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeature_LinkAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_LinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,61,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeature_LinkAccess().getFeatureLinkKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeature_LinkAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:3722:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:3723:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:3723:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:3724:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeature_LinkAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_LinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeature_LinkAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:3744:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:3745:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:3745:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:3746:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeature_LinkAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_LinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeature_LinkAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:3766:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:3767:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:3767:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:3768:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeature_LinkAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_LinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeature_LinkAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:3788:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:3789:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:3789:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:3790:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_60); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeature_LinkAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_LinkRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:3806:3: (otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) ) )
            // InternalVariability.g:3807:4: otherlv_10= 'IS-BIDIRECTIONAL:' ( (lv_is_bidirectional_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,62,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getFeature_LinkAccess().getISBIDIRECTIONALKeyword_10_0());
            			
            // InternalVariability.g:3811:4: ( (lv_is_bidirectional_11_0= RULE_STRING ) )
            // InternalVariability.g:3812:5: (lv_is_bidirectional_11_0= RULE_STRING )
            {
            // InternalVariability.g:3812:5: (lv_is_bidirectional_11_0= RULE_STRING )
            // InternalVariability.g:3813:6: lv_is_bidirectional_11_0= RULE_STRING
            {
            lv_is_bidirectional_11_0=(Token)match(input,RULE_STRING,FOLLOW_61); 

            						newLeafNode(lv_is_bidirectional_11_0, grammarAccess.getFeature_LinkAccess().getIs_bidirectionalSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_LinkRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_bidirectional",
            							lv_is_bidirectional_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3830:3: (otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) ) )
            // InternalVariability.g:3831:4: otherlv_12= 'CUSTOM-TYPE:' ( (lv_custom_type_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,63,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getFeature_LinkAccess().getCUSTOMTYPEKeyword_11_0());
            			
            // InternalVariability.g:3835:4: ( (lv_custom_type_13_0= RULE_STRING ) )
            // InternalVariability.g:3836:5: (lv_custom_type_13_0= RULE_STRING )
            {
            // InternalVariability.g:3836:5: (lv_custom_type_13_0= RULE_STRING )
            // InternalVariability.g:3837:6: lv_custom_type_13_0= RULE_STRING
            {
            lv_custom_type_13_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

            						newLeafNode(lv_custom_type_13_0, grammarAccess.getFeature_LinkAccess().getCustom_typeSTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_LinkRule());
            						}
            						setWithLastConsumed(
            							current,
            							"custom_type",
            							lv_custom_type_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3854:3: (otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) ) )
            // InternalVariability.g:3855:4: otherlv_14= 'KIND:' ( (lv_kind_15_0= RULE_STRING ) )
            {
            otherlv_14=(Token)match(input,43,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getFeature_LinkAccess().getKINDKeyword_12_0());
            			
            // InternalVariability.g:3859:4: ( (lv_kind_15_0= RULE_STRING ) )
            // InternalVariability.g:3860:5: (lv_kind_15_0= RULE_STRING )
            {
            // InternalVariability.g:3860:5: (lv_kind_15_0= RULE_STRING )
            // InternalVariability.g:3861:6: lv_kind_15_0= RULE_STRING
            {
            lv_kind_15_0=(Token)match(input,RULE_STRING,FOLLOW_62); 

            						newLeafNode(lv_kind_15_0, grammarAccess.getFeature_LinkAccess().getKindSTRINGTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_LinkRule());
            						}
            						setWithLastConsumed(
            							current,
            							"kind",
            							lv_kind_15_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3878:3: (otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) ) )
            // InternalVariability.g:3879:4: otherlv_16= 'START:' ( (lv_start_17_0= RULE_STRING ) )
            {
            otherlv_16=(Token)match(input,64,FOLLOW_6); 

            				newLeafNode(otherlv_16, grammarAccess.getFeature_LinkAccess().getSTARTKeyword_13_0());
            			
            // InternalVariability.g:3883:4: ( (lv_start_17_0= RULE_STRING ) )
            // InternalVariability.g:3884:5: (lv_start_17_0= RULE_STRING )
            {
            // InternalVariability.g:3884:5: (lv_start_17_0= RULE_STRING )
            // InternalVariability.g:3885:6: lv_start_17_0= RULE_STRING
            {
            lv_start_17_0=(Token)match(input,RULE_STRING,FOLLOW_63); 

            						newLeafNode(lv_start_17_0, grammarAccess.getFeature_LinkAccess().getStartSTRINGTerminalRuleCall_13_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_LinkRule());
            						}
            						setWithLastConsumed(
            							current,
            							"start",
            							lv_start_17_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:3902:3: (otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==65) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalVariability.g:3903:4: otherlv_18= 'END:' ( (lv_end_19_0= RULE_STRING ) )
                    {
                    otherlv_18=(Token)match(input,65,FOLLOW_6); 

                    				newLeafNode(otherlv_18, grammarAccess.getFeature_LinkAccess().getENDKeyword_14_0());
                    			
                    // InternalVariability.g:3907:4: ( (lv_end_19_0= RULE_STRING ) )
                    // InternalVariability.g:3908:5: (lv_end_19_0= RULE_STRING )
                    {
                    // InternalVariability.g:3908:5: (lv_end_19_0= RULE_STRING )
                    // InternalVariability.g:3909:6: lv_end_19_0= RULE_STRING
                    {
                    lv_end_19_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

                    						newLeafNode(lv_end_19_0, grammarAccess.getFeature_LinkAccess().getEndSTRINGTerminalRuleCall_14_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFeature_LinkRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"end",
                    							lv_end_19_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_20=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_20, grammarAccess.getFeature_LinkAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature_Link"


    // $ANTLR start "entryRuleFeature_Constraint"
    // InternalVariability.g:3934:1: entryRuleFeature_Constraint returns [EObject current=null] : iv_ruleFeature_Constraint= ruleFeature_Constraint EOF ;
    public final EObject entryRuleFeature_Constraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature_Constraint = null;


        try {
            // InternalVariability.g:3934:59: (iv_ruleFeature_Constraint= ruleFeature_Constraint EOF )
            // InternalVariability.g:3935:2: iv_ruleFeature_Constraint= ruleFeature_Constraint EOF
            {
             newCompositeNode(grammarAccess.getFeature_ConstraintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature_Constraint=ruleFeature_Constraint();

            state._fsp--;

             current =iv_ruleFeature_Constraint; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature_Constraint"


    // $ANTLR start "ruleFeature_Constraint"
    // InternalVariability.g:3941:1: ruleFeature_Constraint returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) ) otherlv_12= '}' ) ;
    public final EObject ruleFeature_Constraint() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_criterion_11_0=null;
        Token otherlv_12=null;


        	enterRule();

        try {
            // InternalVariability.g:3947:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) ) otherlv_12= '}' ) )
            // InternalVariability.g:3948:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) ) otherlv_12= '}' )
            {
            // InternalVariability.g:3948:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) ) otherlv_12= '}' )
            // InternalVariability.g:3949:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Feature-Constraint {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) ) otherlv_12= '}'
            {
            // InternalVariability.g:3949:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:3950:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:3950:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:3951:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_64); 

            					newLeafNode(lv_define_0_0, grammarAccess.getFeature_ConstraintAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,66,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getFeature_ConstraintAccess().getFeatureConstraintKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getFeature_ConstraintAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:3975:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:3976:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:3976:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:3977:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getFeature_ConstraintAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getFeature_ConstraintAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:3997:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:3998:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:3998:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:3999:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getFeature_ConstraintAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getFeature_ConstraintAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4019:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4020:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4020:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4021:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getFeature_ConstraintAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getFeature_ConstraintAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4041:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4042:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4042:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:4043:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_24); 

            					newLeafNode(lv_name_9_0, grammarAccess.getFeature_ConstraintAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:4059:3: (otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) ) )
            // InternalVariability.g:4060:4: otherlv_10= 'CRITERION:' ( (lv_criterion_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,30,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getFeature_ConstraintAccess().getCRITERIONKeyword_10_0());
            			
            // InternalVariability.g:4064:4: ( (lv_criterion_11_0= RULE_STRING ) )
            // InternalVariability.g:4065:5: (lv_criterion_11_0= RULE_STRING )
            {
            // InternalVariability.g:4065:5: (lv_criterion_11_0= RULE_STRING )
            // InternalVariability.g:4066:6: lv_criterion_11_0= RULE_STRING
            {
            lv_criterion_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            						newLeafNode(lv_criterion_11_0, grammarAccess.getFeature_ConstraintAccess().getCriterionSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getFeature_ConstraintRule());
            						}
            						setWithLastConsumed(
            							current,
            							"criterion",
            							lv_criterion_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getFeature_ConstraintAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature_Constraint"


    // $ANTLR start "entryRuleVariable_Element"
    // InternalVariability.g:4091:1: entryRuleVariable_Element returns [EObject current=null] : iv_ruleVariable_Element= ruleVariable_Element EOF ;
    public final EObject entryRuleVariable_Element() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariable_Element = null;


        try {
            // InternalVariability.g:4091:57: (iv_ruleVariable_Element= ruleVariable_Element EOF )
            // InternalVariability.g:4092:2: iv_ruleVariable_Element= ruleVariable_Element EOF
            {
             newCompositeNode(grammarAccess.getVariable_ElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariable_Element=ruleVariable_Element();

            state._fsp--;

             current =iv_ruleVariable_Element; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariable_Element"


    // $ANTLR start "ruleVariable_Element"
    // InternalVariability.g:4098:1: ruleVariable_Element returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variable-Element {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'OPTIONAL ELEMENT:' ( (lv_optional_element_11_0= RULE_STRING ) ) ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) ) ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) ) otherlv_15= '}' ) ;
    public final EObject ruleVariable_Element() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_optional_element_11_0=null;
        Token otherlv_15=null;
        EObject lv_actual_binding_time_12_0 = null;

        EObject lv_required_binding_time_13_0 = null;

        EObject lv_reuse_meta_info_14_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:4104:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variable-Element {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'OPTIONAL ELEMENT:' ( (lv_optional_element_11_0= RULE_STRING ) ) ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) ) ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) ) otherlv_15= '}' ) )
            // InternalVariability.g:4105:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variable-Element {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'OPTIONAL ELEMENT:' ( (lv_optional_element_11_0= RULE_STRING ) ) ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) ) ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) ) otherlv_15= '}' )
            {
            // InternalVariability.g:4105:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variable-Element {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'OPTIONAL ELEMENT:' ( (lv_optional_element_11_0= RULE_STRING ) ) ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) ) ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) ) otherlv_15= '}' )
            // InternalVariability.g:4106:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variable-Element {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'OPTIONAL ELEMENT:' ( (lv_optional_element_11_0= RULE_STRING ) ) ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) ) ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) ) ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) ) otherlv_15= '}'
            {
            // InternalVariability.g:4106:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:4107:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:4107:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:4108:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_65); 

            					newLeafNode(lv_define_0_0, grammarAccess.getVariable_ElementAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,67,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getVariable_ElementAccess().getVariableElementKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getVariable_ElementAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:4132:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:4133:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:4133:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:4134:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getVariable_ElementAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getVariable_ElementAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:4154:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:4155:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:4155:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:4156:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getVariable_ElementAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVariable_ElementAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4176:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4177:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4177:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4178:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getVariable_ElementAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getVariable_ElementAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4198:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4199:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4199:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:4200:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_66); 

            					newLeafNode(lv_name_9_0, grammarAccess.getVariable_ElementAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,68,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getVariable_ElementAccess().getOPTIONALELEMENTKeyword_10());
            		
            // InternalVariability.g:4220:3: ( (lv_optional_element_11_0= RULE_STRING ) )
            // InternalVariability.g:4221:4: (lv_optional_element_11_0= RULE_STRING )
            {
            // InternalVariability.g:4221:4: (lv_optional_element_11_0= RULE_STRING )
            // InternalVariability.g:4222:5: lv_optional_element_11_0= RULE_STRING
            {
            lv_optional_element_11_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

            					newLeafNode(lv_optional_element_11_0, grammarAccess.getVariable_ElementAccess().getOptional_elementSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariable_ElementRule());
            					}
            					setWithLastConsumed(
            						current,
            						"optional_element",
            						lv_optional_element_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:4238:3: ( (lv_actual_binding_time_12_0= ruleActual_Binding_Time ) )
            // InternalVariability.g:4239:4: (lv_actual_binding_time_12_0= ruleActual_Binding_Time )
            {
            // InternalVariability.g:4239:4: (lv_actual_binding_time_12_0= ruleActual_Binding_Time )
            // InternalVariability.g:4240:5: lv_actual_binding_time_12_0= ruleActual_Binding_Time
            {

            					newCompositeNode(grammarAccess.getVariable_ElementAccess().getActual_binding_timeActual_Binding_TimeParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_26);
            lv_actual_binding_time_12_0=ruleActual_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariable_ElementRule());
            					}
            					add(
            						current,
            						"actual_binding_time",
            						lv_actual_binding_time_12_0,
            						"org.xtext.example.variability.Variability.Actual_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:4257:3: ( (lv_required_binding_time_13_0= ruleRequired_Binding_Time ) )
            // InternalVariability.g:4258:4: (lv_required_binding_time_13_0= ruleRequired_Binding_Time )
            {
            // InternalVariability.g:4258:4: (lv_required_binding_time_13_0= ruleRequired_Binding_Time )
            // InternalVariability.g:4259:5: lv_required_binding_time_13_0= ruleRequired_Binding_Time
            {

            					newCompositeNode(grammarAccess.getVariable_ElementAccess().getRequired_binding_timeRequired_Binding_TimeParserRuleCall_13_0());
            				
            pushFollow(FOLLOW_26);
            lv_required_binding_time_13_0=ruleRequired_Binding_Time();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariable_ElementRule());
            					}
            					add(
            						current,
            						"required_binding_time",
            						lv_required_binding_time_13_0,
            						"org.xtext.example.variability.Variability.Required_Binding_Time");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:4276:3: ( (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information ) )
            // InternalVariability.g:4277:4: (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information )
            {
            // InternalVariability.g:4277:4: (lv_reuse_meta_info_14_0= ruleReuse_Meta_Information )
            // InternalVariability.g:4278:5: lv_reuse_meta_info_14_0= ruleReuse_Meta_Information
            {

            					newCompositeNode(grammarAccess.getVariable_ElementAccess().getReuse_meta_infoReuse_Meta_InformationParserRuleCall_14_0());
            				
            pushFollow(FOLLOW_27);
            lv_reuse_meta_info_14_0=ruleReuse_Meta_Information();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVariable_ElementRule());
            					}
            					add(
            						current,
            						"reuse_meta_info",
            						lv_reuse_meta_info_14_0,
            						"org.xtext.example.variability.Variability.Reuse_Meta_Information");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getVariable_ElementAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariable_Element"


    // $ANTLR start "entryRuleReuse_Meta_Information"
    // InternalVariability.g:4303:1: entryRuleReuse_Meta_Information returns [EObject current=null] : iv_ruleReuse_Meta_Information= ruleReuse_Meta_Information EOF ;
    public final EObject entryRuleReuse_Meta_Information() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReuse_Meta_Information = null;


        try {
            // InternalVariability.g:4303:63: (iv_ruleReuse_Meta_Information= ruleReuse_Meta_Information EOF )
            // InternalVariability.g:4304:2: iv_ruleReuse_Meta_Information= ruleReuse_Meta_Information EOF
            {
             newCompositeNode(grammarAccess.getReuse_Meta_InformationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReuse_Meta_Information=ruleReuse_Meta_Information();

            state._fsp--;

             current =iv_ruleReuse_Meta_Information; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReuse_Meta_Information"


    // $ANTLR start "ruleReuse_Meta_Information"
    // InternalVariability.g:4310:1: ruleReuse_Meta_Information returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reuse-Meta-Information {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) ) (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) ) otherlv_16= '}' ) ;
    public final EObject ruleReuse_Meta_Information() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_text_11_0=null;
        Token otherlv_12=null;
        Token lv_information_13_0=null;
        Token otherlv_14=null;
        Token lv_is_reuseable_15_0=null;
        Token otherlv_16=null;


        	enterRule();

        try {
            // InternalVariability.g:4316:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reuse-Meta-Information {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) ) (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) ) otherlv_16= '}' ) )
            // InternalVariability.g:4317:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reuse-Meta-Information {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) ) (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) ) otherlv_16= '}' )
            {
            // InternalVariability.g:4317:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reuse-Meta-Information {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) ) (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) ) otherlv_16= '}' )
            // InternalVariability.g:4318:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Reuse-Meta-Information {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) ) (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) ) (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) ) otherlv_16= '}'
            {
            // InternalVariability.g:4318:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:4319:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:4319:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:4320:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_define_0_0, grammarAccess.getReuse_Meta_InformationAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,69,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getReuse_Meta_InformationAccess().getReuseMetaInformationKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getReuse_Meta_InformationAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:4344:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:4345:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:4345:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:4346:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getReuse_Meta_InformationAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getReuse_Meta_InformationAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:4366:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:4367:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:4367:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:4368:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getReuse_Meta_InformationAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getReuse_Meta_InformationAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4388:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4389:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4389:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4390:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getReuse_Meta_InformationAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getReuse_Meta_InformationAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4410:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4411:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4411:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:4412:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_68); 

            					newLeafNode(lv_name_9_0, grammarAccess.getReuse_Meta_InformationAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:4428:3: (otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) ) )
            // InternalVariability.g:4429:4: otherlv_10= 'TEXT:' ( (lv_text_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,70,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getReuse_Meta_InformationAccess().getTEXTKeyword_10_0());
            			
            // InternalVariability.g:4433:4: ( (lv_text_11_0= RULE_STRING ) )
            // InternalVariability.g:4434:5: (lv_text_11_0= RULE_STRING )
            {
            // InternalVariability.g:4434:5: (lv_text_11_0= RULE_STRING )
            // InternalVariability.g:4435:6: lv_text_11_0= RULE_STRING
            {
            lv_text_11_0=(Token)match(input,RULE_STRING,FOLLOW_69); 

            						newLeafNode(lv_text_11_0, grammarAccess.getReuse_Meta_InformationAccess().getTextSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            						}
            						setWithLastConsumed(
            							current,
            							"text",
            							lv_text_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:4452:3: (otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) ) )
            // InternalVariability.g:4453:4: otherlv_12= 'INFORMATION:' ( (lv_information_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,71,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getReuse_Meta_InformationAccess().getINFORMATIONKeyword_11_0());
            			
            // InternalVariability.g:4457:4: ( (lv_information_13_0= RULE_STRING ) )
            // InternalVariability.g:4458:5: (lv_information_13_0= RULE_STRING )
            {
            // InternalVariability.g:4458:5: (lv_information_13_0= RULE_STRING )
            // InternalVariability.g:4459:6: lv_information_13_0= RULE_STRING
            {
            lv_information_13_0=(Token)match(input,RULE_STRING,FOLLOW_70); 

            						newLeafNode(lv_information_13_0, grammarAccess.getReuse_Meta_InformationAccess().getInformationSTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            						}
            						setWithLastConsumed(
            							current,
            							"information",
            							lv_information_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:4476:3: (otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) ) )
            // InternalVariability.g:4477:4: otherlv_14= 'IS-REUSEABLE:' ( (lv_is_reuseable_15_0= RULE_STRING ) )
            {
            otherlv_14=(Token)match(input,72,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getReuse_Meta_InformationAccess().getISREUSEABLEKeyword_12_0());
            			
            // InternalVariability.g:4481:4: ( (lv_is_reuseable_15_0= RULE_STRING ) )
            // InternalVariability.g:4482:5: (lv_is_reuseable_15_0= RULE_STRING )
            {
            // InternalVariability.g:4482:5: (lv_is_reuseable_15_0= RULE_STRING )
            // InternalVariability.g:4483:6: lv_is_reuseable_15_0= RULE_STRING
            {
            lv_is_reuseable_15_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            						newLeafNode(lv_is_reuseable_15_0, grammarAccess.getReuse_Meta_InformationAccess().getIs_reuseableSTRINGTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getReuse_Meta_InformationRule());
            						}
            						setWithLastConsumed(
            							current,
            							"is_reuseable",
            							lv_is_reuseable_15_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getReuse_Meta_InformationAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReuse_Meta_Information"


    // $ANTLR start "entryRuleConfigurable_Container"
    // InternalVariability.g:4508:1: entryRuleConfigurable_Container returns [EObject current=null] : iv_ruleConfigurable_Container= ruleConfigurable_Container EOF ;
    public final EObject entryRuleConfigurable_Container() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfigurable_Container = null;


        try {
            // InternalVariability.g:4508:63: (iv_ruleConfigurable_Container= ruleConfigurable_Container EOF )
            // InternalVariability.g:4509:2: iv_ruleConfigurable_Container= ruleConfigurable_Container EOF
            {
             newCompositeNode(grammarAccess.getConfigurable_ContainerRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfigurable_Container=ruleConfigurable_Container();

            state._fsp--;

             current =iv_ruleConfigurable_Container; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfigurable_Container"


    // $ANTLR start "ruleConfigurable_Container"
    // InternalVariability.g:4515:1: ruleConfigurable_Container returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configurable-Container {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURABLE-ELEMENT:' ( (lv_configurable_element_11_0= RULE_STRING ) ) ( (lv_internal_binding_12_0= ruleInternal_Binding ) ) ( (lv_private_content_13_0= rulePrivate_Content ) )* ( (lv_variation_group_14_0= ruleVariation_Group ) )* ( (lv_feature_15_0= ruleFeature ) )* otherlv_16= '}' ) ;
    public final EObject ruleConfigurable_Container() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_configurable_element_11_0=null;
        Token otherlv_16=null;
        EObject lv_internal_binding_12_0 = null;

        EObject lv_private_content_13_0 = null;

        EObject lv_variation_group_14_0 = null;

        EObject lv_feature_15_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:4521:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configurable-Container {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURABLE-ELEMENT:' ( (lv_configurable_element_11_0= RULE_STRING ) ) ( (lv_internal_binding_12_0= ruleInternal_Binding ) ) ( (lv_private_content_13_0= rulePrivate_Content ) )* ( (lv_variation_group_14_0= ruleVariation_Group ) )* ( (lv_feature_15_0= ruleFeature ) )* otherlv_16= '}' ) )
            // InternalVariability.g:4522:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configurable-Container {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURABLE-ELEMENT:' ( (lv_configurable_element_11_0= RULE_STRING ) ) ( (lv_internal_binding_12_0= ruleInternal_Binding ) ) ( (lv_private_content_13_0= rulePrivate_Content ) )* ( (lv_variation_group_14_0= ruleVariation_Group ) )* ( (lv_feature_15_0= ruleFeature ) )* otherlv_16= '}' )
            {
            // InternalVariability.g:4522:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configurable-Container {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURABLE-ELEMENT:' ( (lv_configurable_element_11_0= RULE_STRING ) ) ( (lv_internal_binding_12_0= ruleInternal_Binding ) ) ( (lv_private_content_13_0= rulePrivate_Content ) )* ( (lv_variation_group_14_0= ruleVariation_Group ) )* ( (lv_feature_15_0= ruleFeature ) )* otherlv_16= '}' )
            // InternalVariability.g:4523:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Configurable-Container {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'CONFIGURABLE-ELEMENT:' ( (lv_configurable_element_11_0= RULE_STRING ) ) ( (lv_internal_binding_12_0= ruleInternal_Binding ) ) ( (lv_private_content_13_0= rulePrivate_Content ) )* ( (lv_variation_group_14_0= ruleVariation_Group ) )* ( (lv_feature_15_0= ruleFeature ) )* otherlv_16= '}'
            {
            // InternalVariability.g:4523:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:4524:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:4524:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:4525:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_71); 

            					newLeafNode(lv_define_0_0, grammarAccess.getConfigurable_ContainerAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,73,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getConfigurable_ContainerAccess().getConfigurableContainerKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getConfigurable_ContainerAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:4549:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:4550:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:4550:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:4551:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getConfigurable_ContainerAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getConfigurable_ContainerAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:4571:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:4572:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:4572:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:4573:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getConfigurable_ContainerAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getConfigurable_ContainerAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4593:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4594:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4594:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4595:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getConfigurable_ContainerAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getConfigurable_ContainerAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4615:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4616:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4616:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:4617:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_72); 

            					newLeafNode(lv_name_9_0, grammarAccess.getConfigurable_ContainerAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,74,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getConfigurable_ContainerAccess().getCONFIGURABLEELEMENTKeyword_10());
            		
            // InternalVariability.g:4637:3: ( (lv_configurable_element_11_0= RULE_STRING ) )
            // InternalVariability.g:4638:4: (lv_configurable_element_11_0= RULE_STRING )
            {
            // InternalVariability.g:4638:4: (lv_configurable_element_11_0= RULE_STRING )
            // InternalVariability.g:4639:5: lv_configurable_element_11_0= RULE_STRING
            {
            lv_configurable_element_11_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

            					newLeafNode(lv_configurable_element_11_0, grammarAccess.getConfigurable_ContainerAccess().getConfigurable_elementSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConfigurable_ContainerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"configurable_element",
            						lv_configurable_element_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:4655:3: ( (lv_internal_binding_12_0= ruleInternal_Binding ) )
            // InternalVariability.g:4656:4: (lv_internal_binding_12_0= ruleInternal_Binding )
            {
            // InternalVariability.g:4656:4: (lv_internal_binding_12_0= ruleInternal_Binding )
            // InternalVariability.g:4657:5: lv_internal_binding_12_0= ruleInternal_Binding
            {

            					newCompositeNode(grammarAccess.getConfigurable_ContainerAccess().getInternal_bindingInternal_BindingParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_10);
            lv_internal_binding_12_0=ruleInternal_Binding();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConfigurable_ContainerRule());
            					}
            					add(
            						current,
            						"internal_binding",
            						lv_internal_binding_12_0,
            						"org.xtext.example.variability.Variability.Internal_Binding");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalVariability.g:4674:3: ( (lv_private_content_13_0= rulePrivate_Content ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==RULE_ID) ) {
                    int LA33_1 = input.LA(2);

                    if ( (LA33_1==76) ) {
                        alt33=1;
                    }


                }


                switch (alt33) {
            	case 1 :
            	    // InternalVariability.g:4675:4: (lv_private_content_13_0= rulePrivate_Content )
            	    {
            	    // InternalVariability.g:4675:4: (lv_private_content_13_0= rulePrivate_Content )
            	    // InternalVariability.g:4676:5: lv_private_content_13_0= rulePrivate_Content
            	    {

            	    					newCompositeNode(grammarAccess.getConfigurable_ContainerAccess().getPrivate_contentPrivate_ContentParserRuleCall_13_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_private_content_13_0=rulePrivate_Content();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConfigurable_ContainerRule());
            	    					}
            	    					add(
            	    						current,
            	    						"private_content",
            	    						lv_private_content_13_0,
            	    						"org.xtext.example.variability.Variability.Private_Content");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            // InternalVariability.g:4693:3: ( (lv_variation_group_14_0= ruleVariation_Group ) )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( (LA34_0==RULE_ID) ) {
                    int LA34_1 = input.LA(2);

                    if ( (LA34_1==78) ) {
                        alt34=1;
                    }


                }


                switch (alt34) {
            	case 1 :
            	    // InternalVariability.g:4694:4: (lv_variation_group_14_0= ruleVariation_Group )
            	    {
            	    // InternalVariability.g:4694:4: (lv_variation_group_14_0= ruleVariation_Group )
            	    // InternalVariability.g:4695:5: lv_variation_group_14_0= ruleVariation_Group
            	    {

            	    					newCompositeNode(grammarAccess.getConfigurable_ContainerAccess().getVariation_groupVariation_GroupParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_variation_group_14_0=ruleVariation_Group();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConfigurable_ContainerRule());
            	    					}
            	    					add(
            	    						current,
            	    						"variation_group",
            	    						lv_variation_group_14_0,
            	    						"org.xtext.example.variability.Variability.Variation_Group");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);

            // InternalVariability.g:4712:3: ( (lv_feature_15_0= ruleFeature ) )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( (LA35_0==RULE_ID) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // InternalVariability.g:4713:4: (lv_feature_15_0= ruleFeature )
            	    {
            	    // InternalVariability.g:4713:4: (lv_feature_15_0= ruleFeature )
            	    // InternalVariability.g:4714:5: lv_feature_15_0= ruleFeature
            	    {

            	    					newCompositeNode(grammarAccess.getConfigurable_ContainerAccess().getFeatureFeatureParserRuleCall_15_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_feature_15_0=ruleFeature();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConfigurable_ContainerRule());
            	    					}
            	    					add(
            	    						current,
            	    						"feature",
            	    						lv_feature_15_0,
            	    						"org.xtext.example.variability.Variability.Feature");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getConfigurable_ContainerAccess().getRightCurlyBracketKeyword_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfigurable_Container"


    // $ANTLR start "entryRuleInternal_Binding"
    // InternalVariability.g:4739:1: entryRuleInternal_Binding returns [EObject current=null] : iv_ruleInternal_Binding= ruleInternal_Binding EOF ;
    public final EObject entryRuleInternal_Binding() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInternal_Binding = null;


        try {
            // InternalVariability.g:4739:57: (iv_ruleInternal_Binding= ruleInternal_Binding EOF )
            // InternalVariability.g:4740:2: iv_ruleInternal_Binding= ruleInternal_Binding EOF
            {
             newCompositeNode(grammarAccess.getInternal_BindingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInternal_Binding=ruleInternal_Binding();

            state._fsp--;

             current =iv_ruleInternal_Binding; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInternal_Binding"


    // $ANTLR start "ruleInternal_Binding"
    // InternalVariability.g:4746:1: ruleInternal_Binding returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Internal-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_root_entry_10_0= ruleEntry ) )* otherlv_11= '}' ) ;
    public final EObject ruleInternal_Binding() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_11=null;
        EObject lv_root_entry_10_0 = null;



        	enterRule();

        try {
            // InternalVariability.g:4752:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Internal-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_root_entry_10_0= ruleEntry ) )* otherlv_11= '}' ) )
            // InternalVariability.g:4753:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Internal-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_root_entry_10_0= ruleEntry ) )* otherlv_11= '}' )
            {
            // InternalVariability.g:4753:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Internal-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_root_entry_10_0= ruleEntry ) )* otherlv_11= '}' )
            // InternalVariability.g:4754:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Internal-Binding {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) ( (lv_root_entry_10_0= ruleEntry ) )* otherlv_11= '}'
            {
            // InternalVariability.g:4754:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:4755:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:4755:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:4756:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_73); 

            					newLeafNode(lv_define_0_0, grammarAccess.getInternal_BindingAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternal_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,75,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getInternal_BindingAccess().getInternalBindingKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getInternal_BindingAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:4780:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:4781:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:4781:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:4782:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getInternal_BindingAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternal_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getInternal_BindingAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:4802:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:4803:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:4803:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:4804:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getInternal_BindingAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternal_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getInternal_BindingAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4824:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4825:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4825:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4826:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getInternal_BindingAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternal_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getInternal_BindingAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4846:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4847:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4847:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:4848:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_name_9_0, grammarAccess.getInternal_BindingAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInternal_BindingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:4864:3: ( (lv_root_entry_10_0= ruleEntry ) )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==RULE_ID) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalVariability.g:4865:4: (lv_root_entry_10_0= ruleEntry )
            	    {
            	    // InternalVariability.g:4865:4: (lv_root_entry_10_0= ruleEntry )
            	    // InternalVariability.g:4866:5: lv_root_entry_10_0= ruleEntry
            	    {

            	    					newCompositeNode(grammarAccess.getInternal_BindingAccess().getRoot_entryEntryParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_root_entry_10_0=ruleEntry();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getInternal_BindingRule());
            	    					}
            	    					add(
            	    						current,
            	    						"root_entry",
            	    						lv_root_entry_10_0,
            	    						"org.xtext.example.variability.Variability.Entry");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

            otherlv_11=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getInternal_BindingAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInternal_Binding"


    // $ANTLR start "entryRulePrivate_Content"
    // InternalVariability.g:4891:1: entryRulePrivate_Content returns [EObject current=null] : iv_rulePrivate_Content= rulePrivate_Content EOF ;
    public final EObject entryRulePrivate_Content() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrivate_Content = null;


        try {
            // InternalVariability.g:4891:56: (iv_rulePrivate_Content= rulePrivate_Content EOF )
            // InternalVariability.g:4892:2: iv_rulePrivate_Content= rulePrivate_Content EOF
            {
             newCompositeNode(grammarAccess.getPrivate_ContentRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrivate_Content=rulePrivate_Content();

            state._fsp--;

             current =iv_rulePrivate_Content; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrivate_Content"


    // $ANTLR start "rulePrivate_Content"
    // InternalVariability.g:4898:1: rulePrivate_Content returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Private-Content {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'PRIVATE-ELEMENT:' ( (lv_private_element_11_0= RULE_STRING ) ) otherlv_12= '}' ) ;
    public final EObject rulePrivate_Content() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_private_element_11_0=null;
        Token otherlv_12=null;


        	enterRule();

        try {
            // InternalVariability.g:4904:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Private-Content {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'PRIVATE-ELEMENT:' ( (lv_private_element_11_0= RULE_STRING ) ) otherlv_12= '}' ) )
            // InternalVariability.g:4905:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Private-Content {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'PRIVATE-ELEMENT:' ( (lv_private_element_11_0= RULE_STRING ) ) otherlv_12= '}' )
            {
            // InternalVariability.g:4905:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Private-Content {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'PRIVATE-ELEMENT:' ( (lv_private_element_11_0= RULE_STRING ) ) otherlv_12= '}' )
            // InternalVariability.g:4906:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Private-Content {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) otherlv_10= 'PRIVATE-ELEMENT:' ( (lv_private_element_11_0= RULE_STRING ) ) otherlv_12= '}'
            {
            // InternalVariability.g:4906:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:4907:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:4907:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:4908:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_74); 

            					newLeafNode(lv_define_0_0, grammarAccess.getPrivate_ContentAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,76,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getPrivate_ContentAccess().getPrivateContentKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getPrivate_ContentAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:4932:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:4933:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:4933:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:4934:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getPrivate_ContentAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getPrivate_ContentAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:4954:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:4955:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:4955:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:4956:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getPrivate_ContentAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getPrivate_ContentAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:4976:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:4977:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:4977:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:4978:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getPrivate_ContentAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getPrivate_ContentAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:4998:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:4999:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:4999:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:5000:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_75); 

            					newLeafNode(lv_name_9_0, grammarAccess.getPrivate_ContentAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,77,FOLLOW_6); 

            			newLeafNode(otherlv_10, grammarAccess.getPrivate_ContentAccess().getPRIVATEELEMENTKeyword_10());
            		
            // InternalVariability.g:5020:3: ( (lv_private_element_11_0= RULE_STRING ) )
            // InternalVariability.g:5021:4: (lv_private_element_11_0= RULE_STRING )
            {
            // InternalVariability.g:5021:4: (lv_private_element_11_0= RULE_STRING )
            // InternalVariability.g:5022:5: lv_private_element_11_0= RULE_STRING
            {
            lv_private_element_11_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            					newLeafNode(lv_private_element_11_0, grammarAccess.getPrivate_ContentAccess().getPrivate_elementSTRINGTerminalRuleCall_11_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrivate_ContentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"private_element",
            						lv_private_element_11_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_12=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getPrivate_ContentAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrivate_Content"


    // $ANTLR start "entryRuleVariation_Group"
    // InternalVariability.g:5046:1: entryRuleVariation_Group returns [EObject current=null] : iv_ruleVariation_Group= ruleVariation_Group EOF ;
    public final EObject entryRuleVariation_Group() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariation_Group = null;


        try {
            // InternalVariability.g:5046:56: (iv_ruleVariation_Group= ruleVariation_Group EOF )
            // InternalVariability.g:5047:2: iv_ruleVariation_Group= ruleVariation_Group EOF
            {
             newCompositeNode(grammarAccess.getVariation_GroupRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariation_Group=ruleVariation_Group();

            state._fsp--;

             current =iv_ruleVariation_Group; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariation_Group"


    // $ANTLR start "ruleVariation_Group"
    // InternalVariability.g:5053:1: ruleVariation_Group returns [EObject current=null] : ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variation-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) ) (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) ) (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) ) otherlv_16= '}' ) ;
    public final EObject ruleVariation_Group() throws RecognitionException {
        EObject current = null;

        Token lv_define_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_uuid_3_0=null;
        Token otherlv_4=null;
        Token lv_shortname_5_0=null;
        Token otherlv_6=null;
        Token lv_category_7_0=null;
        Token otherlv_8=null;
        Token lv_name_9_0=null;
        Token otherlv_10=null;
        Token lv_constraint_11_0=null;
        Token otherlv_12=null;
        Token lv_kind_13_0=null;
        Token otherlv_14=null;
        Token lv_variable_element_15_0=null;
        Token otherlv_16=null;


        	enterRule();

        try {
            // InternalVariability.g:5059:2: ( ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variation-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) ) (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) ) (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) ) otherlv_16= '}' ) )
            // InternalVariability.g:5060:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variation-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) ) (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) ) (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) ) otherlv_16= '}' )
            {
            // InternalVariability.g:5060:2: ( ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variation-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) ) (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) ) (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) ) otherlv_16= '}' )
            // InternalVariability.g:5061:3: ( (lv_define_0_0= RULE_ID ) ) otherlv_1= 'Variation-Group {' otherlv_2= 'UUID:' ( (lv_uuid_3_0= RULE_STRING ) ) otherlv_4= 'SHORT-NAME:' ( (lv_shortname_5_0= RULE_STRING ) ) otherlv_6= 'CATEGORY:' ( (lv_category_7_0= RULE_STRING ) ) otherlv_8= 'NAME:' ( (lv_name_9_0= RULE_STRING ) ) (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) ) (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) ) (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) ) otherlv_16= '}'
            {
            // InternalVariability.g:5061:3: ( (lv_define_0_0= RULE_ID ) )
            // InternalVariability.g:5062:4: (lv_define_0_0= RULE_ID )
            {
            // InternalVariability.g:5062:4: (lv_define_0_0= RULE_ID )
            // InternalVariability.g:5063:5: lv_define_0_0= RULE_ID
            {
            lv_define_0_0=(Token)match(input,RULE_ID,FOLLOW_76); 

            					newLeafNode(lv_define_0_0, grammarAccess.getVariation_GroupAccess().getDefineIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariation_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"define",
            						lv_define_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,78,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getVariation_GroupAccess().getVariationGroupKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getVariation_GroupAccess().getUUIDKeyword_2());
            		
            // InternalVariability.g:5087:3: ( (lv_uuid_3_0= RULE_STRING ) )
            // InternalVariability.g:5088:4: (lv_uuid_3_0= RULE_STRING )
            {
            // InternalVariability.g:5088:4: (lv_uuid_3_0= RULE_STRING )
            // InternalVariability.g:5089:5: lv_uuid_3_0= RULE_STRING
            {
            lv_uuid_3_0=(Token)match(input,RULE_STRING,FOLLOW_7); 

            					newLeafNode(lv_uuid_3_0, grammarAccess.getVariation_GroupAccess().getUuidSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariation_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"uuid",
            						lv_uuid_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getVariation_GroupAccess().getSHORTNAMEKeyword_4());
            		
            // InternalVariability.g:5109:3: ( (lv_shortname_5_0= RULE_STRING ) )
            // InternalVariability.g:5110:4: (lv_shortname_5_0= RULE_STRING )
            {
            // InternalVariability.g:5110:4: (lv_shortname_5_0= RULE_STRING )
            // InternalVariability.g:5111:5: lv_shortname_5_0= RULE_STRING
            {
            lv_shortname_5_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

            					newLeafNode(lv_shortname_5_0, grammarAccess.getVariation_GroupAccess().getShortnameSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariation_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"shortname",
            						lv_shortname_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getVariation_GroupAccess().getCATEGORYKeyword_6());
            		
            // InternalVariability.g:5131:3: ( (lv_category_7_0= RULE_STRING ) )
            // InternalVariability.g:5132:4: (lv_category_7_0= RULE_STRING )
            {
            // InternalVariability.g:5132:4: (lv_category_7_0= RULE_STRING )
            // InternalVariability.g:5133:5: lv_category_7_0= RULE_STRING
            {
            lv_category_7_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_category_7_0, grammarAccess.getVariation_GroupAccess().getCategorySTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariation_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"category",
            						lv_category_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_8, grammarAccess.getVariation_GroupAccess().getNAMEKeyword_8());
            		
            // InternalVariability.g:5153:3: ( (lv_name_9_0= RULE_STRING ) )
            // InternalVariability.g:5154:4: (lv_name_9_0= RULE_STRING )
            {
            // InternalVariability.g:5154:4: (lv_name_9_0= RULE_STRING )
            // InternalVariability.g:5155:5: lv_name_9_0= RULE_STRING
            {
            lv_name_9_0=(Token)match(input,RULE_STRING,FOLLOW_77); 

            					newLeafNode(lv_name_9_0, grammarAccess.getVariation_GroupAccess().getNameSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariation_GroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalVariability.g:5171:3: (otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) ) )
            // InternalVariability.g:5172:4: otherlv_10= 'CONSTRAINT:' ( (lv_constraint_11_0= RULE_STRING ) )
            {
            otherlv_10=(Token)match(input,79,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getVariation_GroupAccess().getCONSTRAINTKeyword_10_0());
            			
            // InternalVariability.g:5176:4: ( (lv_constraint_11_0= RULE_STRING ) )
            // InternalVariability.g:5177:5: (lv_constraint_11_0= RULE_STRING )
            {
            // InternalVariability.g:5177:5: (lv_constraint_11_0= RULE_STRING )
            // InternalVariability.g:5178:6: lv_constraint_11_0= RULE_STRING
            {
            lv_constraint_11_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

            						newLeafNode(lv_constraint_11_0, grammarAccess.getVariation_GroupAccess().getConstraintSTRINGTerminalRuleCall_10_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVariation_GroupRule());
            						}
            						setWithLastConsumed(
            							current,
            							"constraint",
            							lv_constraint_11_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:5195:3: (otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) ) )
            // InternalVariability.g:5196:4: otherlv_12= 'KIND:' ( (lv_kind_13_0= RULE_STRING ) )
            {
            otherlv_12=(Token)match(input,43,FOLLOW_6); 

            				newLeafNode(otherlv_12, grammarAccess.getVariation_GroupAccess().getKINDKeyword_11_0());
            			
            // InternalVariability.g:5200:4: ( (lv_kind_13_0= RULE_STRING ) )
            // InternalVariability.g:5201:5: (lv_kind_13_0= RULE_STRING )
            {
            // InternalVariability.g:5201:5: (lv_kind_13_0= RULE_STRING )
            // InternalVariability.g:5202:6: lv_kind_13_0= RULE_STRING
            {
            lv_kind_13_0=(Token)match(input,RULE_STRING,FOLLOW_78); 

            						newLeafNode(lv_kind_13_0, grammarAccess.getVariation_GroupAccess().getKindSTRINGTerminalRuleCall_11_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVariation_GroupRule());
            						}
            						setWithLastConsumed(
            							current,
            							"kind",
            							lv_kind_13_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalVariability.g:5219:3: (otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) ) )
            // InternalVariability.g:5220:4: otherlv_14= 'VARIABLE-ELEMENT:' ( (lv_variable_element_15_0= RULE_STRING ) )
            {
            otherlv_14=(Token)match(input,80,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getVariation_GroupAccess().getVARIABLEELEMENTKeyword_12_0());
            			
            // InternalVariability.g:5224:4: ( (lv_variable_element_15_0= RULE_STRING ) )
            // InternalVariability.g:5225:5: (lv_variable_element_15_0= RULE_STRING )
            {
            // InternalVariability.g:5225:5: (lv_variable_element_15_0= RULE_STRING )
            // InternalVariability.g:5226:6: lv_variable_element_15_0= RULE_STRING
            {
            lv_variable_element_15_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

            						newLeafNode(lv_variable_element_15_0, grammarAccess.getVariation_GroupAccess().getVariable_elementSTRINGTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getVariation_GroupRule());
            						}
            						setWithLastConsumed(
            							current,
            							"variable_element",
            							lv_variable_element_15_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getVariation_GroupAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariation_Group"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000210010L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000020000000010L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000010000L,0x0000000000000002L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});

}